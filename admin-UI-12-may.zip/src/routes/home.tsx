import { getUserId } from "../services/session.server";
import { useNavigate } from "react-router";
import type * as Route from "./+types.home";
import { useEffect } from "react";


export default function Index({}: Route.ComponentProps) {
  const navigate = useNavigate();
  useEffect(() => {
      const userId = getUserId();
      if (userId) {
        navigate("/gfrdetails")
      } else {
        navigate("/login")
      }
    });
}
