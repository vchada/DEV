import type * as Route from "./+types.login";
import { createUserSession, getUserId } from "../services/session.server";
import geico_img from "../../public/geico.png";
import { useEffect, useState } from "react";
import { loginAPI } from "../services/api";
import { useNavigate } from "react-router";

export const meta: Function = () => {
  return [
    { title: "New React Router App" },
    { name: "description", content: "Welcome to React Router!" },
  ];
};


export default function Login({ actionData }: Route.ComponentProps) {
  const style = {
    color: '#00a6ff'
  }

  const navigate = useNavigate();

  useEffect(() => {
		const userId = getUserId();
    if (userId) {
      navigate("/")
    }
	});

  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const closeBanner = () => {
    setSuccessMsg('');
    setErrorMsg('');
  };

  const handleChange = (e: any) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({ ...prevState, [name]: value }));
  };

  const [formData, setFormData] = useState({
    userId: '',
    password: '',
  });

  const onSubmit = async () => {
    const userId = formData.userId;
    const password = formData.password;

    // Check the user's credentials
    if (userId !== "test@mail.com" || password !== "password") {
      return setErrorMsg("Invalid userId or password");
    }

    const payload = {userId, password};
    // loginAPI
    //   .post('/', payload).then((res) => {
    //   if (res) {

        setSuccessMsg('Your response saved successfully.');

        // Create a session
        createUserSession({
          userId: userId,
          userName: 'res.data.userName'
        })
        redirect('/')

    //   }
    // })
    // .catch(() => {
    //   setErrorMsg('There is some issue. Please try again.');
    // });
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
        <h2 className="text-2xl font-bold mb-6 text-center" style={style}>GFR Admin Console</h2>
        <div className="w-full inline-flex">
          <div className="w-1/4">
            <img
              src={geico_img}
              alt="React Router"
              className="block w-full dark:hidden h-full"
            />
          </div>
          <div className="w-3/4 px-4">
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">
                  User Id
                </label>
                <input
                  type="userId"
                  id="userId"
                  value={formData.userId}                  
                  onChange={handleChange}
                  name="userId"
                  className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  placeholder="Enter user id"
                />
              </div>
              <div className="mb-6">
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="password">
                  Password
                </label>
                <input
                  type="password"
                  id="password"
                  value={formData.password}
                  name="password"
                  className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline"
                  placeholder="Enter your password"
                  onChange={handleChange}
                />
              </div>

              {successMsg && (
                <div className="success-banner">
                  {successMsg}{' '}
                  <a onClick={closeBanner} className="close">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      className="bi bi-x-lg"
                      viewBox="0 0 16 16"
                    >
                      <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8z" />
                    </svg>
                  </a>
                </div>
              )}

              {errorMsg && (
                <div className="error-banner">
                  {errorMsg}{' '}
                  <a onClick={closeBanner} className="close">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      className="bi bi-x-lg"
                      viewBox="0 0 16 16"
                    >
                      <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8z" />
                    </svg>
                  </a>
                </div>
              )}

              <div className="flex">
                <button
                  onClick={onSubmit}
                  className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline ml-auto"
                >
                  Sign In
                </button>
              </div>
            {actionData?.error ? (
              <div className="flex flex-row">
                <p className="text-red-600 mt-4 ">{actionData?.error}</p>
              </div>
            ) : null}
          </div>          
        </div>
      </div>
    </div>
  );
}
