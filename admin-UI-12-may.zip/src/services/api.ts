import axios from 'axios';

export const api = axios.create({
  baseURL: window.VITE_BASE_URL
});

// export const statePriorityAPI = axios.create({
//   baseURL: window.VITE_BASE_URL_STATE_PRIORITY
// });

// export const hoursOfOperationAPI = axios.create({
//   baseURL: window.VITE_BASE_URL_HOURS_OF_OPERATION
// });

export const feedbackAPI = axios.create({
  baseURL: window.VITE_BASE_URL_FEEDBACK
});

export const loginAPI = axios.create({
  baseURL: window.VITE_BASE_URL_LOGIN
});

export const fetchGfrDetail = axios.create({
  baseURL: window.VITE_BASE_URL_FETCH_GFR_DETAIL
});

export const addGfrDetail = axios.create({
  baseURL: window.VITE_BASE_URL_ADD_GFR_DETAIL
});

export const updateGfrDetail = axios.create({
  baseURL: window.VITE_BASE_URL_UPDATE_GFR_DETAIL
});

export const fetchGfrPhoneMapping = axios.create({
  baseURL: window.VITE_BASE_URL_FETCH_GFR_PHONE_MAPPING
});

export const addGfrPhoneMapping = axios.create({
  baseURL: window.VITE_BASE_URL_ADD_GFR_PHONE_MAPPING
});

export const updateGfrPhoneMapping = axios.create({
  baseURL: window.VITE_BASE_URL_UPDATE_GFR_PHONE_MAPPING
});

export const fetchGfrOfficeHours = axios.create({
  baseURL: window.VITE_BASE_URL_FETCH_GFR_OFFICE_HOURS
});

export const addGfrOfficeHours = axios.create({
  baseURL: window.VITE_BASE_URL_ADD_GFR_OFFICE_HOURS
});

export const updateGfrOfficeHours = axios.create({
  baseURL: window.VITE_BASE_URL_UPDATE_GFR_OFFICE_HOURS
});

export const fetchGfrOfficeHourScheduler = axios.create({
  baseURL: window.VITE_BASE_URL_FETCH_GFR_OFFICE_HOUR_SCHEDULER
});

export const addGfrOfficeHourScheduler = axios.create({
  baseURL: window.VITE_BASE_URL_ADD_GFR_OFFICE_HOUR_SCHEDULER
});

export const updateGfrOfficeHourScheduler = axios.create({
  baseURL: window.VITE_BASE_URL_UPDATE_GFR_OFFICE_HOUR_SCHEDULER
});
