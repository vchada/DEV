import { useMemo, useState } from 'react';
import {
  MRT_EditActionButtons,
  MaterialReactTable,
  type MRT_ColumnDef,
  type MRT_TableOptions,
  useMaterialReactTable,
} from 'material-react-table';
import {
  Box,
  Button,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  QueryClient,
  QueryClientProvider,
  useMutation,
  useQuery,
  useQueryClient,
} from '@tanstack/react-query';
import { type GfrOfficeHourScheduler, gfrOfficeHourSchedulerDummydata } from './gfrOfficeHourSchedulerTableDummyData';
import EditIcon from '@mui/icons-material/Edit';
import { fetchGfrDetail } from '../../services/api';

const Example = (name: string) => {
  const [validationErrors, setValidationErrors] = useState<
    Record<string, string | undefined>
  >({});

  const columns = useMemo<MRT_ColumnDef<GfrOfficeHourScheduler>[]>(
    () => [
      {
        accessorKey: 'gea',
        header: 'gea',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        }
      },
      {
        accessorKey: 'close_hours_new',
        header: 'close_hours_new',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        }
      },
      {
        accessorKey: 'open_hours_old',
        header: 'open_hours_old',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        }
      },
      {
        accessorKey: 'gea_request_id',
        header: 'gea_request_id',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        }
      },
      {
        accessorKey: 'close_hours_old',
        header: 'close_hours_old',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        }
      },
      {
        accessorKey: 'table_name',
        header: 'table_name',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        }
      },
      {
        accessorKey: 'comments',
        header: 'comments',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        }
      },
      {
        accessorKey: 'full_day',
        header: 'full_day',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        }
      },
      {
        accessorKey: 'req_created_dt_tm',
        header: 'req_created_dt_tm',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        }
      },
      {
        accessorKey: 'expiry_date',
        header: 'expiry_date',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        }
      },
      {
        accessorKey: 'req_initiated_user',
        header: 'req_initiated_user',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        }
      },
      {
        accessorKey: 'open_hours_new',
        header: 'open_hours_new',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        }
      },
      {
        accessorKey: 'request_status',
        header: 'request_status',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        }
      },
      {
        accessorKey: 'effective_date',
        header: 'effective_date',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        }
      }
    ],
    [validationErrors],
  );

  //call CREATE hook
  const { mutateAsync: createUser, isPending: isCreatingUser } = useCreateUser();
  //call READ hook
  const {
    data: fetchedUsers = [],
    isError: isLoadingUsersError,
    isFetching: isFetchingUsers,
    isLoading: isLoadingUsers,
  } = useGetUsers();
  //call UPDATE hook
  const { mutateAsync: updateUser, isPending: isUpdatingUser } = useUpdateUser();

  //CREATE action
  const handleCreateUser: MRT_TableOptions<GfrOfficeHourScheduler>['onCreatingRowSave'] = async ({
    values,
    table,
  }) => {
    const newValidationErrors = validateUser(values);
    if (Object.values(newValidationErrors).some((error) => error)) {
      setValidationErrors(newValidationErrors);
      return;
    }
    setValidationErrors({});
    await createUser(values);
    table.setCreatingRow(null); //exit creating mode
  };

  //UPDATE action
  const handleSaveUser: MRT_TableOptions<GfrOfficeHourScheduler>['onEditingRowSave'] = async ({
    values,
    table,
  }) => {
    const newValidationErrors = validateUser(values);
    if (Object.values(newValidationErrors).some((error) => error)) {
      setValidationErrors(newValidationErrors);
      return;
    }
    setValidationErrors({});
    await updateUser(values);
    table.setEditingRow(null); //exit editing mode
  };

  const table = useMaterialReactTable({
    columns,
    data: fetchedUsers,
    createDisplayMode: 'modal', //default ('row', and 'custom' are also available)
    editDisplayMode: 'modal', //default ('row', 'cell', 'table', and 'custom' are also available)
    enableEditing: true,
    getRowId: (row) => row.gea,
    muiToolbarAlertBannerProps: isLoadingUsersError
      ? {
          color: 'error',
          children: 'Error loading data',
        }
      : undefined,
    muiTableContainerProps: {
      sx: {
        minHeight: '500px',
      },
    },
    onCreatingRowCancel: () => setValidationErrors({}),
    onCreatingRowSave: handleCreateUser,
    onEditingRowCancel: () => setValidationErrors({}),
    onEditingRowSave: handleSaveUser,
    //optionally customize modal content
    renderCreateRowDialogContent: ({ table, row, internalEditComponents }) => (
      <>
        <DialogTitle variant="h5">Create New User</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {internalEditComponents} {/* or render custom edit components here */}
        </DialogContent>
        <DialogActions>
          <MRT_EditActionButtons variant="text" table={table} row={row} />
        </DialogActions>
      </>
    ),
    //optionally customize modal content
    renderEditRowDialogContent: ({ table, row, internalEditComponents }) => (
      <>
        <DialogTitle variant="h5">Edit User</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {internalEditComponents} {/* or render custom edit components here */}
        </DialogContent>
        <DialogActions>
          <MRT_EditActionButtons variant="text" table={table} row={row} />
        </DialogActions>
      </>
    ),
    renderRowActions: ({ row, table }) => (
      <Box sx={{ display: 'flex', gap: '1rem' }}>
        <Tooltip title="Edit">
          <IconButton onClick={() => table.setEditingRow(row)}>
            <EditIcon />
          </IconButton>
        </Tooltip>
      </Box>
    ),
    renderTopToolbarCustomActions: ({ table }) => (
      <Button
        variant="contained"
        onClick={() => {
          table.setCreatingRow(true); //simplest way to open the create row modal with no default values
          //or you can pass in a row object to set default values with the `createRow` helper function
          // table.setCreatingRow(
          //   createRow(table, {
          //     //optionally pass in default values for the new row, useful for nested data or other complex scenarios
          //   }),
          // );
        }}
      >
        Create New User
      </Button>
    ),
    state: {
      isLoading: isLoadingUsers,
      isSaving: isCreatingUser || isUpdatingUser,
      showAlertBanner: isLoadingUsersError,
      showProgressBars: isFetchingUsers,
    },
    positionActionsColumn: 'last',
  });

  return <MaterialReactTable table={table} />;
};

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div style={{ margin: '0 100px' }}>
        <Example />
      </div>
    </QueryClientProvider>
  );
}

const validateRequired = (value: string) => !!value.length;
const validateEmail = (email: string) =>
  !!email.length &&
  email
    .toLowerCase()
    .match(
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
    );

function validateUser(user: GfrOfficeHourScheduler) {
  return {
    // firstName: !validateRequired(user.firstName) ? 'First Name is Required' : '',
    // lastName: !validateRequired(user.lastName) ? 'Last Name is Required' : '',
    // email: !validateEmail(user.email) ? 'Incorrect Email Format' : '',
  };
}

//CREATE hook (post new user to api)
function useCreateUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (user: GfrOfficeHourScheduler) => {
      //send api update request here
      await new Promise((resolve) => setTimeout(resolve, 1000)); //fake api call
      return Promise.resolve();
    },
    //client side optimistic update
    onMutate: (newUserInfo: GfrOfficeHourScheduler) => {
      queryClient.setQueryData(
        ['users'],
        (prevUsers: any) =>
          [
            ...prevUsers,
            {
              ...newUserInfo,
              id: (Math.random() + 1).toString(36).substring(7),
            },
          ] as GfrOfficeHourScheduler[],
      );
    },
    // onSettled: () => queryClient.invalidateQueries({ queryKey: ['users'] }), //refetch users after mutation, disabled for demo
  });
}

//READ hook (get users from api)
function useGetUsers() {
  return useQuery<any[]>({
    queryKey: ['users'],
    queryFn: async () => {
      //send api request here
      let response: any;
      await fetchGfrDetail.get('/').then((res: any) => {
        response = res.data;
      });
      return Promise.resolve(gfrOfficeHourSchedulerDummydata);
    },
    refetchOnWindowFocus: false,
  });
}

//UPDATE hook (put user in api)
function useUpdateUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (user: GfrOfficeHourScheduler) => {
      //send api update request here
      await new Promise((resolve) => setTimeout(resolve, 1000)); //fake api call
      return Promise.resolve();
    },
    //client side optimistic update
    onMutate: (newUserInfo: GfrOfficeHourScheduler) => {
      queryClient.setQueryData(['users'], (prevUsers: any) =>
        prevUsers?.map((prevUser: GfrOfficeHourScheduler) =>
          prevUser.gea === newUserInfo.gea ? newUserInfo : prevUser,
        ),
      );
    },
    // onSettled: () => queryClient.invalidateQueries({ queryKey: ['users'] }), //refetch users after mutation, disabled for demo
  });
}
