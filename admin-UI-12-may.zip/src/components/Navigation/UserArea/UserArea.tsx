import { ContainerUserArea } from './styled';
import { Button, FormControl, InputLabel, Menu, MenuItem, NativeSelect } from '@mui/material';
import { type MouseEvent, useContext, useEffect, useState } from 'react';
import { HiUserCircle } from 'react-icons/hi';
import { UserInfoContext } from '../../../context/UserInfoContext';
import { useLocation, useNavigate } from 'react-router';
import { Link } from 'react-router-dom';

export const UserArea = () => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  const [selectedTable, setSelectedTable] = useState<any>(null);
  const open = Boolean(anchorEl);
  const handleClick = (event: MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const userInfo = useContext(UserInfoContext);

  const location = useLocation();

  useEffect(() => {
    setSelectedTable(location.pathname ? location.pathname.replace('/', '') : null)
  }, [location]);

  const navigate = useNavigate();

  const handleChange = (event: any) => {
    if(event.target.value !== 'Select Table') {
      setSelectedTable(event.target.value)
      navigate("/" + event.target.value)
    }
  }


  const handleLogout = () => {
    sessionStorage.clear();
    localStorage.clear();
    navigate('/')
  }

  return (
    <ContainerUserArea>
      <div>
        <div className='mx-4'>
          <FormControl className='table-select'>
            <InputLabel variant="standard" htmlFor="uncontrolled-native">
              Table
            </InputLabel>
            <NativeSelect
              defaultValue={selectedTable}
              value={selectedTable}
              inputProps={{
                name: 'table',
                id: 'uncontrolled-native',
              }}
              onChange={handleChange}
            >
              <option>Select Table</option>
              <option value={'gfrDetails'}>GFR Details</option>
              <option value={'gfrPhoneMapping'}>GFR Phone Mapping</option>
              <option value={'gfrOfficeHours'}>GFR Office Hours</option>
              <option value={'gfrOfficeHourScheduler'}>GFR Office Hour Scheduler</option>
            </NativeSelect>
          </FormControl>
        </div>

        <div className='userInfo'>
          <Button
            id="basic-button"
            aria-controls={open ? 'basic-menu' : undefined}
            aria-haspopup="true"
            aria-expanded={open ? 'true' : undefined}
            onClick={handleClick}
          >
            <HiUserCircle />
            {/* <span>{'userInfo.name'}</span> */}
            <span>{'user name'}</span>
          </Button>
          <Menu
            id="basic-menu"
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            MenuListProps={{
              'aria-labelledby': 'basic-button',
            }}
          >
          <MenuItem>
            {/* <Form action="/logout" method="post"> */}
              <button onClick={handleLogout} className="no-border rounded py-1">
                Logout
              </button>
            {/* </Form> */}
          </MenuItem>
            <MenuItem onClick={handleClose}><Link className="" to="/feedback">
            Feedback
          </Link></MenuItem>
          </Menu>
        </div>
      </div>
      
    </ContainerUserArea>
  );
};
