import LogoImg from '../../../assets/imgs/logo.png';

export const BrandArea = () => {
  return (
    // <div className="brand_area">
      <img src={LogoImg} alt="logo" width={'120px'} height={'23px'} style={{'display': 'flex', 'alignContent': 'flex-end'}}/>
    // </div>
  );
};
