import { type FilterTagProps } from "../Toolbar/Toolbar";
import CloseIcon from "../Icons/CloseIcon";

interface FilterMenuTagProps {
  filterTag: FilterTagProps;
  handleRemoveFilterTag: (filterTag: any) => void;
}

const FilterMenuTag: React.FC<FilterMenuTagProps> = ({ filterTag, handleRemoveFilterTag }) => {

  return (
    <div className="flex flex-row justify-items-center px-1 py-1">
      <div className="flex flex-row bg-custom-primary-blue items-center content-center rounded-s" >
        <p className="text-xs text-white px-2">
          {filterTag.columnName}: {filterTag.filterValue}
        </p>
      </div>
      <div className='flex flex-row items-center content-center overflow-hidden rounded-e' onClick={() => handleRemoveFilterTag(filterTag)}>
        <CloseIcon size={28} />
      </div>
    </div>
  );
};

export default FilterMenuTag;
