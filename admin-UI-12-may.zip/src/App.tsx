import 'react-toastify/dist/ReactToastify.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { injectStyle } from "react-toastify/dist/inject-style";

import Home from "./routes/home"
import Feedback from "./routes/feedback";
import Gfrcellhours from "./routes/gfrPhoneMapping"
import Gfrdetails from "./routes/gfrdetails";
import GfrOfficeHours from "./routes/gfrOfficeHours";
import GfrOfficeHourScheduler from "./routes/gfrOfficeHourScheduler";
import Login from "./routes/login"


function App() {

  injectStyle();


  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/feedback" element={<Feedback />} />
          <Route path="/gfrPhoneMapping" element={<Gfrcellhours />} />
          <Route path="/gfrDetails" element={<Gfrdetails />} />
          <Route path="/gfrOfficeHours" element={<GfrOfficeHours />} />
          <Route path="/gfrOfficeHourScheduler" element={<GfrOfficeHourScheduler />} />
          <Route path="/login" element={<Login />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;

