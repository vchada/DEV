/** @type {import("./Types/xlsx")} */
declare global
{
  interface Window
  {
    VITE_BASE_URL: string;
    // VITE_BASE_URL_STATE_PRIORITY: string;
    // VITE_BASE_URL_HOURS_OF_OPERATION: string;
    VITE_BASE_URL_FEEDBACK: string;
    VITE_BASE_URL_LOGIN: string;
    
    VITE_BASE_URL_FETCH_GFR_DETAIL: string;
    VITE_BASE_URL_ADD_GFR_DETAIL: string;
    VITE_BASE_URL_UPDATE_GFR_DETAIL: string;
    VITE_BASE_URL_FETCH_GFR_PHONE_MAPPING: string;
    VITE_BASE_URL_ADD_GFR_PHONE_MAPPING: string;
    VITE_BASE_URL_UPDATE_GFR_PHONE_MAPPING: string;
    VITE_BASE_URL_FETCH_GFR_OFFICE_HOURS: string;
    VITE_BASE_URL_ADD_GFR_OFFICE_HOURS: string;
    VITE_BASE_URL_UPDATE_GFR_OFFICE_HOURS: string;
    VITE_BASE_URL_FETCH_GFR_OFFICE_HOUR_SCHEDULER: string;
    VITE_BASE_URL_ADD_GFR_OFFICE_HOUR_SCHEDULER: string;
    VITE_BASE_URL_UPDATE_GFR_OFFICE_HOUR_SCHEDULER: string;



    VITE_ENV: string;
    // VITE_CCP_REGION: string;
    // VITE_CCP_URL: string;
    // VITE_CCP_LOGIN_URL: string;
    XLSX: xlsx;
  }
}

export {};
