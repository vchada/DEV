import { ReactNode, createContext, useState } from 'react';
import { CallTypeId, CallTypeIdStatePriority } from '../../pages/Queues/StatePriority/Types/Types'

interface QueuesProps {
    children: ReactNode;
}


type ModifiedStatePriorityRows = {
    key: string;
    obj: CallTypeIdStatePriority;
}





interface QueueProps {
    modifiedRows: ModifiedStatePriorityRows[];
    setModifiedRows: (rows: ModifiedStatePriorityRows[]) => void;
    selectedCallTypeIds: any[];
    setSelectedCallTypeIds: (rows: any[]) => void;
    callTypeIds: CallTypeId[];
    setCallTypeIds: (ids: CallTypeId[]) => void;
    loadingData: boolean;
    setLoadingData: (state: boolean) => void;
    dataDialog: {
        dialogEditPrompt: boolean;
        setDialogEditPrompt: (state: boolean) => void;
        dialogAddCallTypeId: boolean;
        setDialogAddCallTypeId: (state: boolean) => void;
        dialogImport: boolean;
        setDialogImport: (state: boolean) => void;
        dialogDelete: boolean;
        setDialogDelete: (state: boolean) => void;
        dialogViewEditHOO: boolean;
        setDialogViewEditHOO: (state: boolean) => void;
        dialogAddHOO: boolean;
        setDialogAddHOO: (state: boolean) => void;
        dialogAddClosedPeriodHOO: boolean;
        setDialogAddClosedPeriodHOO: (state: boolean) => void;
        dialogDeleteHOO: boolean;
        setDialogDeleteHOO: (state: boolean) => void;
        dialogStatePriorityExport: boolean;
        setDialogStatePriorityExport: (state: boolean) => void;
        exportDialog: boolean;
        setExportDialog: (state: boolean) => void;
    };


        
    //Hours of Operation Variables
    hoursOfOperationList: any[];
    setHoursOfOperationList: (hoursOfOperation: any[]) => void;
    currentHOORow: any;
    setCurrentHOORow: (row: any) => void;
    editCurrentHours: any;
    setEditCurrentHours: (row: any) => void;
    currentEditName: string;
    setCurrentEditName: (name: string) => void;
    viewListIndex: any;
    setViewListIndex: (index: any) => void;
    closedPeriodIndex: any;
    setClosedPeriodIndex: (index: any) => void;
    selectedHOORows: any[];
    setSelectedHOORows: (rows: any[]) => void;
    selectedSubType: string;
    setSelectedSubType: (name: string) => void;
    originalDataStructure: Map<string, any>;
    setOriginalDataStructure: (map: any) => void;
    currentTableQueues: Set<string>;
    setCurrentTableQueues: (currentTableQueues: Set<string>) => void;
}

export const QueuesContext = createContext({} as QueueProps);

export const QueuesProvider = ({ children }: QueuesProps) => {
    //State Priority context variables
    const [callTypeIds, setCallTypeIds] = useState<CallTypeId[]>([]);
    const [modifiedRows, setModifiedRows] = useState<ModifiedStatePriorityRows[]>([]);
    const [dialogEditPrompt, setDialogEditPrompt] = useState<boolean>(false);
    const [dialogAddCallTypeId, setDialogAddCallTypeId] = useState<boolean>(false);
    const [dialogImport, setDialogImport] = useState<boolean>(false);
    const [dialogDelete, setDialogDelete] = useState<boolean>(false);
    const [loadingData, setLoadingData] = useState<boolean>(true);
    const [selectedCallTypeIds, setSelectedCallTypeIds] = useState<any[]>([]);

    //Hours of Operation context variables
    const [hoursOfOperationList, setHoursOfOperationList] = useState<any[]>([]);
    const [dialogViewEditHOO, setDialogViewEditHOO] = useState<boolean>(false);
    const [dialogAddHOO, setDialogAddHOO] = useState<boolean>(false);
    const [currentHOORow, setCurrentHOORow] = useState<any>();
    const [editCurrentHours, setEditCurrentHours] = useState<any>();
    const [currentEditName, setCurrentEditName] = useState<string>('');
    const [viewListIndex, setViewListIndex] = useState<any>();
    const [closedPeriodIndex, setClosedPeriodIndex] = useState<any>();
    const [selectedHOORows, setSelectedHOORows] = useState<any[]>([]); 
    const [dialogDeleteHOO, setDialogDeleteHOO] = useState<boolean>(false);
    const [dialogAddClosedPeriodHOO, setDialogAddClosedPeriodHOO] = useState<boolean>(false);
    const [selectedSubType, setSelectedSubType] = useState<string>('All');
    const [originalDataStructure, setOriginalDataStructure] = useState<any>(new Map())
    const [currentTableQueues, setCurrentTableQueues] = useState<any>(new Set()); 
    const [dialogStatePriorityExport, setDialogStatePriorityExport] = useState<boolean>(false);
    const [exportDialog, setExportDialog] = useState<boolean>(false);

    const dataDialog = {
        dialogEditPrompt,
        setDialogEditPrompt,
        dialogAddCallTypeId,
        setDialogAddCallTypeId,
        dialogImport,
        setDialogImport,
        dialogDelete,
        setDialogDelete,
        dialogViewEditHOO,
        setDialogViewEditHOO,
        dialogAddHOO,
        setDialogAddHOO,
        dialogAddClosedPeriodHOO,
        setDialogAddClosedPeriodHOO,
        dialogDeleteHOO,
        setDialogDeleteHOO,
        dialogStatePriorityExport,
        setDialogStatePriorityExport,
        exportDialog,
        setExportDialog
    };

    return (
        <QueuesContext.Provider
            value={{
                modifiedRows,
                setModifiedRows,
                dataDialog,
                loadingData,
                setLoadingData,
                callTypeIds,
                setCallTypeIds,
                selectedCallTypeIds,
                setSelectedCallTypeIds,
                hoursOfOperationList,
                setHoursOfOperationList,
                currentHOORow,
                setCurrentHOORow,
                editCurrentHours,
                setEditCurrentHours,
                currentEditName,
                setCurrentEditName,
                viewListIndex,
                setViewListIndex,
                closedPeriodIndex,
                setClosedPeriodIndex,
                selectedHOORows,
                setSelectedHOORows,
                selectedSubType,
                setSelectedSubType,
                originalDataStructure,
                setOriginalDataStructure,
                currentTableQueues,
                setCurrentTableQueues,
                
            }}
        >
            {children}
        </QueuesContext.Provider>
    );
};
