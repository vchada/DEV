import { ReactNode, createContext, useEffect, useState } from 'react';

interface HistoryProps {
  children: ReactNode;
}

interface ItemHistoryProps {
  user: string;
  updateTime: string;
  'itemId#collection_key': string;
  currentMessage: string;
  previousMessage: string;
  hasRestore: boolean;
}

interface HistoryPromptProps {
  filteredHistories: [ItemHistoryProps] | any;
  setListHistoryPrompts: (list: [] | any) => void;
  optionsIdCollections: string[];
  dataFilters: {
    filterHistories: string;
    setFilterHistories: (itemId: string) => void;
  };
  dataSelected: {
    itemHistorySelected: ItemHistoryProps | null;
    setItemHistorySelected: (itemHistorySelected: ItemHistoryProps | null) => void;
  };
  dataDialog: {
    dialogHistoryRollback: boolean;
    setDialogHistoryRollback: (state: boolean) => void;
  };
}

export const HistoryContext = createContext({} as HistoryPromptProps);

export const HistoryProvider = ({ children }: HistoryProps) => {
  const [listHistoryPrompts, setListHistoryPrompts] = useState<ItemHistoryProps[]>([]);
  const [filterHistories, setFilterHistories] = useState<string>('0');
  const [filteredHistories, setFilteredHistories] = useState<ItemHistoryProps[]>([]);
  const [optionsIdCollections, setOptionsIdCollections] = useState<string[]>([]);
  const [itemHistorySelected, setItemHistorySelected] = useState<ItemHistoryProps | null>(
    null,
  );
  const [dialogHistoryRollback, setDialogHistoryRollback] = useState<boolean>(false);

  useEffect(() => {
    if (listHistoryPrompts.length > 0) {
      const mappedOptionsItemId = listHistoryPrompts.map(
        (item) => item['itemId#collection_key'],
      );
      setOptionsIdCollections([...new Set(mappedOptionsItemId)]);
      if (filterHistories !== '0') {
        const filteredHistoriesCollections = listHistoryPrompts.filter((item) => {
          return (
            item['itemId#collection_key'] === filterHistories &&
            item['itemId#collection_key']
          );
        });
        return setFilteredHistories(filteredHistoriesCollections);
      }
      return setFilteredHistories(listHistoryPrompts);
    }
  }, [listHistoryPrompts, filterHistories, filteredHistories]);

  const dataFilters = {
    filterHistories,
    setFilterHistories,
  };

  const dataSelected = {
    itemHistorySelected,
    setItemHistorySelected,
  };

  const dataDialog = {
    dialogHistoryRollback,
    setDialogHistoryRollback,
  };

  return (
    <HistoryContext.Provider
      value={{
        filteredHistories,
        setListHistoryPrompts,
        optionsIdCollections,
        dataFilters,
        dataSelected,
        dataDialog,
      }}
    >
      {children}
    </HistoryContext.Provider>
  );
};
