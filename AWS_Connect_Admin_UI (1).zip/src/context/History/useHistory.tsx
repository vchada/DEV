import { useContext } from 'react';
import { HistoryContext } from './HistoryContext';

export const useHistory = () => {
  const context = useContext(HistoryContext);
  return context;
};
