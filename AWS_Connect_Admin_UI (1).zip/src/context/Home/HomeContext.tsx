import { ReactNode, createContext, useEffect, useState } from 'react';

interface HomeProps {
  children: ReactNode;
}

interface ItemListProps {
  item_id: string;
  collection_key: string;
  language_code: string;
  item_content: string;
  contact_flow_name: string;
  item_type: string;
}

interface ListPromptProps {
  filteredPrompts: [ItemListProps] | any;
  setListPromptsHome: (list: [] | any) => void;
  dataFilters: {
    filterItemId: string;
    setFilterItemId: (itemId: string) => void;
    filterCollectionId: string;
    setFilterCollectionId: (itemId: string) => void;
  };
  dataOptions: {
    optionsItemId: string[];
    optionsCollections: string[];
  };
  dataDialog: {
    dialogEditPrompt: boolean;
    setDialogEditPrompt: (state: boolean) => void;
  };
  dataSelected: {
    selectedItemPrompt: ItemListProps | null;
    setSelectedItemPrompt: (selectedItemPrompt: ItemListProps | null) => void;
  };
}

export const HomeContext = createContext({} as ListPromptProps);

export const HomeProvider = ({ children }: HomeProps) => {
  const [listPromptsHome, setListPromptsHome] = useState<ItemListProps[]>([]);
  const [filteredPrompts, setFilteredPrompts] = useState<ItemListProps[]>([]);
  const [selectedItemPrompt, setSelectedItemPrompt] = useState<ItemListProps | null>(
    null,
  );
  const [filterItemId, setFilterItemId] = useState<string>('0');
  const [filterCollectionId, setFilterCollectionId] = useState<string>('0');
  const [optionsItemId, setOptionsItemId] = useState<string[]>([]);
  const [optionsCollections, setOptionsCollections] = useState<string[]>([]);
  const [dialogEditPrompt, setDialogEditPrompt] = useState<boolean>(false);

  useEffect(() => {
    setFilterCollectionId('0');
  }, [filterItemId]);

  useEffect(() => {
    if (listPromptsHome.length > 0) {
      const mappedOptionsItemId = listPromptsHome.map((item) => item.item_id);
      const filteredOptionsCollections = listPromptsHome.filter((item) => {
        return item.item_id === filterItemId && item.collection_key;
      });

      const noFilterOptionsCollections = listPromptsHome.map(
        (item) => item.collection_key,
      );

      const mappedOptionsCollections = filteredOptionsCollections.map(
        (item) => item.collection_key,
      );

      setOptionsItemId([...new Set(mappedOptionsItemId)]);
      setOptionsCollections(
        mappedOptionsCollections.length === 0
          ? [...new Set(noFilterOptionsCollections)]
          : [...new Set(mappedOptionsCollections)],
      );
    }
  }, [listPromptsHome, filterItemId]);

  const dataFilters = {
    filterItemId,
    setFilterItemId,
    filterCollectionId,
    setFilterCollectionId,
  };

  const dataOptions = {
    optionsItemId,
    optionsCollections,
  };

  const dataDialog = {
    dialogEditPrompt,
    setDialogEditPrompt,
  };

  const dataSelected = {
    selectedItemPrompt,
    setSelectedItemPrompt,
  };

  const dataRenderPrompts = (
    listPromptsHome: ItemListProps[],
    filteredItem: string,
    filterCollectionId: string,
  ) => {
    if (filteredItem !== '0') {
      const filteredLisById = listPromptsHome.filter(
        (item: any) => item.item_id === filteredItem,
      );

      if (filterCollectionId !== '0' && filteredLisById.length !== 0) {
        const filteredLisByCollection = filteredLisById.filter(
          (item: any) => item.collection_key === filterCollectionId,
        );
        return filteredLisByCollection;
      }
      return filteredLisById;
    }
    const listByCollection = listPromptsHome.filter(
      (item: any) => item.collection_key === filterCollectionId,
    );

    return listByCollection.length === 0 ? listPromptsHome : listByCollection;
  };

  useEffect(() => {
    setFilteredPrompts(
      dataRenderPrompts(listPromptsHome, filterItemId, filterCollectionId),
    );
  }, [listPromptsHome, filterItemId, filterCollectionId]);

  return (
    <HomeContext.Provider
      value={{
        filteredPrompts,
        setListPromptsHome,
        dataFilters,
        dataOptions,
        dataDialog,
        dataSelected,
      }}
    >
      {children}
    </HomeContext.Provider>
  );
};
