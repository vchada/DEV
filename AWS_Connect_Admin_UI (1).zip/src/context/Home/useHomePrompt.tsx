import { useContext } from 'react';
import { HomeContext } from './HomeContext';

export const useHomePrompt = () => {
  const context = useContext(HomeContext);
  return context;
};
