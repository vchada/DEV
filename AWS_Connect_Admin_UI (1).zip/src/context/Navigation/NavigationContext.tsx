import { ReactNode, createContext, useState } from 'react';

interface NavigationProps {
  children: ReactNode;
}

interface NavigationContext {
  controlStage: ControlStageProps;
}

interface ControlStageProps {
  currentStage: number;
  toStage: (stage: number) => void;
}

export const NavigationContext = createContext({} as NavigationContext);

export const NavigationProvider = ({ children }: NavigationProps) => {
  const [currentStage, setCurrentStage] = useState<number>(0);

  const controlStage: ControlStageProps = {
    currentStage: currentStage,
    toStage: (stage: number) => setCurrentStage(stage),
  };

  return (
    <NavigationContext.Provider value={{ controlStage }}>
      {children}
    </NavigationContext.Provider>
  );
};
