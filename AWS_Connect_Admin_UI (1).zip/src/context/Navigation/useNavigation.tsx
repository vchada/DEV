import { useContext } from 'react';
import { NavigationContext } from './NavigationContext';

export const useNavigation = () => {
  const context = useContext(NavigationContext);
  return context;
};
