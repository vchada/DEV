import { ReactNode, createContext, useState } from 'react';

interface HOONavigationProps {
  children: ReactNode;
}

interface HOONavigationContext {
  controlStage: ControlStageProps;
}

interface ControlStageProps {
  currentStage: number;
  toStage: (stage: number) => void;
}

export const HOONavigationContext = createContext({} as HOONavigationContext);

export const HOONavigationProvider = ({ children }: HOONavigationProps) => {
  const [currentStage, setCurrentStage] = useState<number>(0);

  const controlStage: ControlStageProps = {
    currentStage: currentStage,
    toStage: (stage: number) => setCurrentStage(stage),
  };

  return (
    <HOONavigationContext.Provider value={{ controlStage }}>
      {children}
    </HOONavigationContext.Provider>
  );
};
