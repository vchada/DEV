import { useContext } from 'react';
import { HOONavigationContext } from './HOONavigationContext';

export const useHOONavigation = () => {
  const context = useContext(HOONavigationContext);
  return context;
};
