import { ReactNode, createContext, useState } from 'react';
import { User } from '../../pages/UserManagement/User';

interface UserManagementProps {
  children: ReactNode;
}



interface ListPromptProps {
  selectedUsers: [User] | any;
  setSelectedUsers: (users: User[]) => void;
  setUsersUserManagement: (list: [] | any) => void;
  listOfUsersUM: User[];
  agentHierarchy: any[];
  setAgentHierarchy: (hierarchy: any[]) => void;
  dataFilters: {
    filterItemId: string;
    setFilterItemId: (itemId: string) => void;
    filterCollectionId: string;
    setFilterCollectionId: (itemId: string) => void;
  };
  dataDialog: {
    dialogEditPrompt: boolean;
    setDialogEditPrompt: (state: boolean) => void;
  };
  dataSelected: {
    selectedItemPrompt: User | null;
    setSelectedItemPrompt: (selectedItemPrompt: User | null) => void;
  };
}

export const UserManagementContext = createContext({} as ListPromptProps);

export const UserManagementProvider = ({ children }: UserManagementProps) => {
  const [listOfUsersUM, setUsersUserManagement] = useState<User[]>([]);
  const [agentHierarchy, setAgentHierarchy] = useState<any[]>([]);
  const [selectedUsers, setSelectedUsers] = useState<User[]>([]);
  const [selectedItemPrompt, setSelectedItemPrompt] = useState<User | null>(
    null,
  );
  const [filterItemId, setFilterItemId] = useState<string>('0');
  const [filterCollectionId, setFilterCollectionId] = useState<string>('0');
  // const [optionsItemId, setOptionsItemId] = useState<string[]>([]);
  // const [optionsCollections, setOptionsCollections] = useState<string[]>([]);
  const [dialogEditPrompt, setDialogEditPrompt] = useState<boolean>(false);

  // useEffect(() => {
  //   setFilterCollectionId('0');
  // }, [filterItemId]);

  // useEffect(() => {
  //   if (listOfUsersUM.length > 0) {
  //     const mappedOptionsItemId = listOfUsersUM.map((item) => item.identifier);
  //     const filteredOptionsCollections = listOfUsersUM.filter((item) => {
  //       return item.identifier === filterItemId && item.tags;
  //     });

  //     const noFilterOptionsCollections = listOfUsersUM.map(
  //       (item) => item.tags,
  //     );

  //     const mappedOptionsCollections = filteredOptionsCollections.map(
  //       (item) => item.tags,
  //     );

  //     setOptionsItemId([...new Set(mappedOptionsItemId)]);
  //     setOptionsCollections(
  //       mappedOptionsCollections.length === 0
  //         ? [...new Set(noFilterOptionsCollections)]
  //         : [...new Set(mappedOptionsCollections)],
  //     );
  //   }
  // }, [listOfUsersUM, filterItemId]);

  const dataFilters = {
    filterItemId,
    setFilterItemId,
    filterCollectionId,
    setFilterCollectionId,
  };

  // const dataOptions = {
  //   optionsItemId,
  //   optionsCollections,
  // };

  const dataDialog = {
    dialogEditPrompt,
    setDialogEditPrompt,
  };

  const dataSelected = {
    selectedItemPrompt,
    setSelectedItemPrompt,
  };

  // const dataRenderPrompts = (
  //   listPromptsUserManagement: User[],
  //   filteredItem: string,
  //   filterCollectionId: string,
  // ) => {
  //   if (filteredItem !== '0') {
  //     const filteredLisById = listPromptsUserManagement.filter(
  //       (item: any) => item.item_id === filteredItem,
  //     );

  //     if (filterCollectionId !== '0' && filteredLisById.length !== 0) {
  //       const filteredLisByCollection = filteredLisById.filter(
  //         (item: any) => item.collection_key === filterCollectionId,
  //       );
  //       return filteredLisByCollection;
  //     }
  //     return filteredLisById;
  //   }
  //   const listByCollection = listPromptsUserManagement.filter(
  //     (item: any) => item.collection_key === filterCollectionId,
  //   );

  //   return listByCollection.length === 0 ? listPromptsUserManagement : listByCollection;
  // };

  // useEffect(() => {
  //   setFilteredPrompts(
  //     dataRenderPrompts(listOfUsersUM, filterItemId, filterCollectionId),
  //   );
  // }, [listOfUsersUM, filterItemId, filterCollectionId]);

  return (
    <UserManagementContext.Provider
      value={{
        selectedUsers,
        setSelectedUsers,
        setUsersUserManagement,
        listOfUsersUM,
        dataFilters,
        dataDialog,
        dataSelected,
        agentHierarchy,
        setAgentHierarchy
      }}
    >
      {children}
    </UserManagementContext.Provider>
  );
};
