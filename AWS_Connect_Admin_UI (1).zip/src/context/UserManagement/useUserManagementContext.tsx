import { useContext } from 'react';
import { UserManagementContext } from './UserManagementContext';

export const useUserManagementContext = () => {
  const context = useContext(UserManagementContext);
  return context;
};
