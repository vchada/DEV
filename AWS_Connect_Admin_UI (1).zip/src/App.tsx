import { QueryClientProvider } from 'react-query';
import { ToastContainer } from 'react-toastify';
import { RenderPages } from './pages/RenderPages/RenderPages';
import { queryClient } from './services/queryClient';
import { NavigationProvider } from './context/Navigation/NavigationContext';
import { HomeProvider } from './context/Home/HomeContext';
import { HistoryProvider } from './context/History/HistoryContext';

import 'react-toastify/dist/ReactToastify.css';
import { UserManagementProvider } from './context/UserManagement/UserManagementContext';
import { QueuesProvider } from './context/Queues/QueuesContext';
import { useState, useRef, useEffect } from 'react';
import "amazon-connect-streams";
import { UserInfoContext } from './context/UserInfoContext';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { Feedback } from './pages/Feedback/Feedback';
import { HOONavigationProvider } from './context/HOONavigationContext/HOONavigationContext';
import { injectStyle } from "react-toastify/dist/inject-style";

export const XLSX = window.XLSX;

function App() {
  const [isUserLoggedIn, setIsUserLoggedIn] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  injectStyle();


  const ccpRef: any = useRef();

  console.debug("isUserLoggedIn", isUserLoggedIn);

  useEffect(() => {
    try {
      if (typeof window === "undefined") throw new Error("window missing");
      if (typeof window.connect === "undefined")
        throw new Error("global connect missing");
      console.log("init start");
      window.connect.core.initCCP(ccpRef.current, {
        // ccpUrl: 'https://vchada.my.connect.aws/ccp-v2/softphone',
        ccpUrl: window.VITE_CCP_URL,
        region: window.VITE_CCP_REGION,
        loginPopup: true,
        loginUrl: window.VITE_CCP_LOGIN_URL,
        loginPopupAutoClose: true,
        softphone: {
          allowFramedSoftphone: true,
        },
        pageOptions: {
          enableAudioDeviceSettings: true,
          enablePhoneTypeSettings: true,
        },
      });
      console.log("init end");

      window.connect.agent((agent) => {
        if (agent) {
          setIsUserLoggedIn(true)
          setName(agent.getName())
          setEmail(agent.getConfiguration().username)

          setTimeout(() => {
            document.getElementById("connectframe")?.remove();
            // ccpRef.remove();
            window.connect.core.terminate();
          }, 5000);
        }
      })

    } catch (e) {
      console.error(e);
    }

  }, []);

  return (
    <div>
      <div
        id="connectframe"
        ref={ccpRef}
        style={{ width: "0", height: "0" }}
      />
      <QueryClientProvider client={queryClient}>
        {isUserLoggedIn &&
          <NavigationProvider>
            <HomeProvider>
              <HistoryProvider>
                <UserManagementProvider>
                  <QueuesProvider>
                    <HOONavigationProvider>
                      <UserInfoContext.Provider value={{ name: name, email: email }}>
                        <ToastContainer position="top-right" draggable />
                        <BrowserRouter>
                          <Routes>
                            <Route path="/" element={<RenderPages />} />
                            <Route path="/feedback" element={<Feedback />} />
                          </Routes>
                        </BrowserRouter>
                      </UserInfoContext.Provider>
                    </HOONavigationProvider>
                  </QueuesProvider>
                </UserManagementProvider>
              </HistoryProvider>
            </HomeProvider>
          </NavigationProvider>
        }
      </QueryClientProvider>

    </div>
  );
}

export default App;

