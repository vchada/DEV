import { hoursOfOperationAPI } from '../api';


// interface dataUpdateProps {
//   method: string;
//   user: string;
//   data: any;
// }

export async function uploadGLSFile(formData: FormData) {
  try {
    const { data } = await hoursOfOperationAPI.post('/api/v1/gls-upload', formData);
    return data;
  } catch (err: any) {
    return new Error(err?.response?.data?.message);
  }
}

export async function getPreSignedURL() {
  try {
    const { data } = await hoursOfOperationAPI.get('/api/v1/gls-upload');
    return data;
  } catch (err: any) {
    return new Error(err?.response?.data?.message);
  }
}