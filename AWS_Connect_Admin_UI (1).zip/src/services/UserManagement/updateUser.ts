import { User } from '../../pages/UserManagement/User';
import { api } from '../api';

type PayLoadProps = {
  updatedData: {
    secProfiles: any,
    routeProfiles: any,
    phone: string,
    acw: number,
    users: User[]
  },
};

interface dataUpdateProps {
  method: string;
  user: string;
  dataUpdate: {
    payload: PayLoadProps | undefined
  };
}

export async function updateUsers(dataUpdatePrompt: dataUpdateProps) {
  try {
    const { data } = await api.post('geico-user-management', dataUpdatePrompt);
    return data;
  } catch (err: any) {
    throw new Error(err?.response?.data?.message);
  }
}