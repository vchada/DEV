import { api } from '../api';

export async function getAgentHierarchy() {
  try {
    const { data } = await api.post('geico-user-management', {
      method: 'LIST_AGENT_HIERARCHY',
    });
    return data;
  } catch (err: any) {
    throw new Error(err?.response?.data?.message);
  }
}
