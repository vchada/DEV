import { api } from '../api';

export async function getUsers() {
  try {
    const { data } = await api.post('geico-user-management', {
      method: 'LIST_USERS',
    });
    return data;
  } catch (err: any) {
    throw new Error(err?.response?.data?.message);
  }
}
