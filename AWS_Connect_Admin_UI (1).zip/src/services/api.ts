import axios from 'axios';

export const api = axios.create({
  baseURL: window.VITE_BASE_URL
});

export const statePriorityAPI = axios.create({
  baseURL: window.VITE_BASE_URL_STATE_PRIORITY
});

export const hoursOfOperationAPI = axios.create({
  baseURL: window.VITE_BASE_URL_HOURS_OF_OPERATION
});

export const feedbackAPI = axios.create({
  baseURL: window.VITE_BASE_URL_FEEDBACK
});
