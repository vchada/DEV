import { api } from '../..//api';


interface dataDeleteProps {
  method: string;
  user: string;
  payload: any[]
}

export async function deleteCallTypeIds(dataAddCallTypeId: dataDeleteProps) {
  try {
    const { data } = await api.post('geico-user-management', dataAddCallTypeId);
    return data;
  } catch (err: any) {
    throw new Error(err?.response?.data?.message);
  }
}