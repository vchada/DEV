import { statePriorityAPI } from '../../api';

export async function getStatePriority() {
  try {
    const { data } = await statePriorityAPI.get(`${window.VITE_BASE_URL_STATE_PRIORITY}/api/v1/state-priorities`);
    return data;
  } catch (err: any) {
    console.log('Error: ', err)
    return new Error(err?.response?.data?.message);
  }
}
