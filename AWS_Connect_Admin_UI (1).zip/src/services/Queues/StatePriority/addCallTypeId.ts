import { api } from '../../api';


interface dataAddProps {
  method: string;
  user: string;
  payload: any[]
}

export async function addCallTypeId(dataAddCallTypeId: dataAddProps) {
  try {
    const { data } = await api.post('geico-user-management', dataAddCallTypeId);
    return data;
  } catch (err: any) {
    throw new Error(err?.response?.data?.message);
  }
}