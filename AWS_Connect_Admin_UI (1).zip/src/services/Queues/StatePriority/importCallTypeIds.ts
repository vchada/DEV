import axios from 'axios';
import { statePriorityAPI } from '../../api';


interface dataImportProps {
    name:string;
    loginId: string;
    payload: any[]

}

export async function importCallTypeIds(dataImportCallTypeId: dataImportProps) {
    try {
        axios.all([
            await statePriorityAPI.put('/api/v1/state-priorities', dataImportCallTypeId)
        ])
            .then(axios.spread((putResponse) => {
                return putResponse;
            }));

    } catch (err: any) {
        throw new Error(err?.response?.data?.message);
    }
}