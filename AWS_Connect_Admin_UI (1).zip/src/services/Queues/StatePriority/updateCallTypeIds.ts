import { statePriorityAPI } from '../../api';


interface dataUpdateProps {
  name: string;
  loginId: string;
  payload: any[];
}

export async function updateCallTypeIds(dataUpdatePrompt: dataUpdateProps) {
  try {
    const { data } = await statePriorityAPI.put('/api/v1/state-priorities', dataUpdatePrompt);
    return data;
  } catch (err: any) {
    throw new Error(err?.response?.data?.message);
  }
}