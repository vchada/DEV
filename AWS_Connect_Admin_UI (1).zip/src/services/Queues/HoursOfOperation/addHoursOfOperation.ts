import axios from 'axios';
import { hoursOfOperationAPI } from '../../api';


interface dataUpdateProps {
  loginId: string;
  name: string;
  payload: any;
}

export async function addHoursOfOperation(dataUpdatePrompt: dataUpdateProps) {
  try {
    if (dataUpdatePrompt.payload.newQueues.length > 0 && dataUpdatePrompt.payload.existingQueues.length > 0) {
      axios.all([
        await hoursOfOperationAPI.post('/api/v1/custom-hours-of-operations', {name: dataUpdatePrompt.name, loginId: dataUpdatePrompt.loginId, data: dataUpdatePrompt.payload.newQueues}),
        await hoursOfOperationAPI.patch('/api/v1/custom-hours-of-operations', {
          name: dataUpdatePrompt.name,
          loginId: dataUpdatePrompt.loginId,
          payload: dataUpdatePrompt.payload.existingQueues
        }),
      ])
        .then(axios.spread((postResponse, putResponse) => {
          return {
            postResponse: postResponse,
            putResponse: putResponse
          };
        }));
    } else if (dataUpdatePrompt.payload.newQueues.length > 0 && dataUpdatePrompt.payload.existingQueues.length == 0) {
      const { data } = await hoursOfOperationAPI.post('/api/v1/custom-hours-of-operations', {name: dataUpdatePrompt.name, loginId: dataUpdatePrompt.loginId, payload: dataUpdatePrompt.payload.newQueues});
      return data;
    }
    else {
      const { data } = await hoursOfOperationAPI.patch('/api/v1/custom-hours-of-operations', {
        name: dataUpdatePrompt.name,
        loginId: dataUpdatePrompt.loginId,
        payload: dataUpdatePrompt.payload.existingQueues
      });
      return data;
    }


  } catch (err: any) {
    console.log('Error: ', err)
    throw new Error(err?.response?.data?.message);
  }
}