import { hoursOfOperationAPI } from '../../api';

export async function getHoursOfOperation(determinator: string) {
  try {
    const { data } = await hoursOfOperationAPI.get('/api/v1/custom-hours-of-operations/' + determinator);
    return data;
  } catch (err: any) {
    console.log('Error: ', err)
    return new Error(err?.response?.data?.message);
  }
}

export async function getAllHoursOfOperation() {
  console.log(`${window.VITE_BASE_URL_HOURS_OF_OPERATION}`);

  try {
    const { data } = await hoursOfOperationAPI.get(`${window.VITE_BASE_URL_HOURS_OF_OPERATION}/api/v1/custom-hours-of-operations/All`);
    return data;
  } catch (err: any) {
    console.log('Error: ', err)
    return new Error(err?.response?.data?.message);
  }
}

export async function getFederalHoursOfOperation() {
  try {
    const { data } = await hoursOfOperationAPI.get(`${window.VITE_BASE_URL_HOURS_OF_OPERATION}/api/v1/custom-hours-of-operations/Federal`);
    return data;
  } catch (err: any) {
    console.log('Error: ', err)
    return new Error(err?.response?.data?.message);
  }
}

export async function getStateHoursOfOperation() {
  try {
    const { data } = await hoursOfOperationAPI.get(`${window.VITE_BASE_URL_HOURS_OF_OPERATION}/api/v1/custom-hours-of-operations/State`);
    return data;
  } catch (err: any) {
    console.log('Error: ', err)
    return new Error(err?.response?.data?.message);
  }
}

export async function getAdhocHoursOfOperation() {
  try {
    const { data } = await hoursOfOperationAPI.get(`${window.VITE_BASE_URL_HOURS_OF_OPERATION}/api/v1/custom-hours-of-operations/Adhoc`);
    return data;
  } catch (err: any) {
    console.log('Error: ', err)
    return new Error(err?.response?.data?.message);
  }
}
