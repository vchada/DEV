import { hoursOfOperationAPI } from '../../api';


interface dataUpdateProps {
  loginId: string;
  name: string
  payload: any;
}

export async function updateHoursOfOperation(dataUpdatePrompt: dataUpdateProps) {
  try {
    const { data } = await hoursOfOperationAPI.patch('/api/v1/custom-hours-of-operations', dataUpdatePrompt);
    return data;
  } catch (err: any) {
    throw new Error(err?.response?.data?.message);
  }
}