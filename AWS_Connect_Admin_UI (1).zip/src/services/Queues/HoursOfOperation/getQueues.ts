import { hoursOfOperationAPI } from '../../api';

export async function getQueues() {
  try {
    const { data } = await hoursOfOperationAPI.get('/api/v1/queues');
    return data;
  } catch (err: any) {
    console.log('Error: ', err)
    return new Error(err?.response?.data?.message);
  }
}