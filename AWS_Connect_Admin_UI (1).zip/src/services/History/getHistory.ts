import { api } from '../api';

export async function getHistories() {
  try {
    const { data } = await api.post('geico-prompts', {
      method: 'LIST_HISTORY',
    });
    return data;
  } catch (err: any) {
    throw new Error(err?.response?.data?.message);
  }
}
