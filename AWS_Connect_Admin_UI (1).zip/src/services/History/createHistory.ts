interface dataCreatedHistProps {
  method: string;
  user: string;
  dataUpdate: {
    itemId?: string;
    collection_key?: string;
    currentMessage?: string;
    previousMessage?: string;
  };
}

export async function createHistory(dataCreatedHist: dataCreatedHistProps) {
  try {
    return new Promise((resolve) => {
      setTimeout(() => resolve(dataCreatedHist), 1500);
    });
  } catch (err: any) {
    throw new Error(err?.response?.data?.message);
  }
}
