import { api } from '../api';

interface dataUpdateProps {
  method: string;
  user: string;
  dataUpdate: {
    item_id: string;
    collection_key?: string;
    newPrompt: string;
    previousPrompt?: string;
  };
}

export async function updatePrompts(dataUpdatePrompt: dataUpdateProps) {
  try {
    const { data } = await api.post('geico-prompts', dataUpdatePrompt);
    return data;
  } catch (err: any) {
    throw new Error(err?.response?.data?.message);
  }
}
