import { api } from '../api';

export async function getPrompts() {
  try {
    const { data } = await api.post('geico-prompts', {
      method: 'LIST_PROMPTS',
    });
    return data;
  } catch (err: any) {
    throw new Error(err?.response?.data?.message);
  }
}
