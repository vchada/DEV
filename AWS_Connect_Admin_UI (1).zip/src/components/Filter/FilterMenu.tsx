import { Menu, MenuProps, Paper, Stack } from "@mui/material";
import { MRT_RowData, MRT_TableInstance } from "material-react-table";
import FilterMenuItem from "./FilterMenuItem";
import FilterIcon from "../Icons/FilterIcon";
import { useEffect, useState } from "react";

interface FilterMenuProps<TData extends MRT_RowData> extends Partial<MenuProps> {
	table: MRT_TableInstance<TData>;
}

const FilterMenu = <TData extends MRT_RowData>({
	table
}: FilterMenuProps<TData>) => {
	const [filterAnchorEl, setFilterAnchorEl] = useState<HTMLElement | null>(null);
	const [showFilterDropdown, setShowFilterDropdown] = useState<boolean>(false);
	const [isClicked, setIsClicked] = useState<boolean>(false);
	const [filterIconColor, setFilterIconColor] = useState<string>('#005CCC');

	useEffect(() => {
		isClicked ? setFilterIconColor('#005CCC') : setFilterIconColor('#616161');
	}, [isClicked]);

	const handleFilterIconClick = (e: React.MouseEvent<HTMLElement>) => {
		showFilterDropdown ? setFilterAnchorEl(null) : setFilterAnchorEl(e.currentTarget);
		setShowFilterDropdown(!showFilterDropdown);
		setIsClicked(showFilterDropdown);
	};

	const handleFilterMenuClose = () => {
		setFilterAnchorEl(null);
		setShowFilterDropdown(false);
		setIsClicked(false);
	}

	return (
		<div>
			<div className='flex flex-row cursor-pointer items-center' onClick={handleFilterIconClick}>
				<FilterIcon size={24} color={filterIconColor} />
				<p className='text-base p-1'>Filter</p>
			</div>
			<Menu
				anchorEl={filterAnchorEl}
				open={Boolean(filterAnchorEl)}
				onClose={handleFilterMenuClose}
				MenuListProps={{ sx: { py: 0 } }}
			>
				<Paper>
					<Stack p="4px" gap="4px">
						{
							table.getLeafHeaders().map((header) =>
								header.column.getCanFilter() &&
								<FilterMenuItem key={header.id} header={header} table={table} />
							)
						}
					</Stack>
				</Paper>
			</Menu>
		</div>
	);
};

export default FilterMenu;
