import { Menu, MenuItem } from '@mui/material';
import React, { useState } from 'react'
import ImportButton from '../Buttons/ImportButton';
import ShowHideColumnsButton from '../Buttons/ShowHideColumnButton';
import ToggleDensityButton from '../Buttons/ToggleDensityButton';
import { MRT_TableInstance } from 'material-react-table';
import ExportButton from '../Buttons/ExportButton';
import GearIcon from '../Icons/GearIcon';

interface GearMenuProps {
	table: MRT_TableInstance<any>;
	context: any;
	importEnabled: boolean;
}

const GearMenu: React.FC<GearMenuProps> = ({ table, context, importEnabled }) => {

	const anchorOriginValues = { horizontal: 'right' as const, vertical: 'bottom' as const };
	const transformOriginValues = { horizontal: 'right' as const, vertical: 'top' as const };
	const [gearAnchorEl, setGearAnchorEl] = useState<HTMLElement | null>(null);

	const handleGearIconClick = (e: any) => {
		gearAnchorEl ? setGearAnchorEl(null) : setGearAnchorEl(e.currentTarget);
	};

	const handleGearMenuClose = () => {
		setGearAnchorEl(null);
	}

	return (
		<div>
			<div className='cursor-pointer p-1' onClick={handleGearIconClick}>
				<GearIcon />
			</div>
			<Menu
				anchorEl={gearAnchorEl}
				anchorOrigin={anchorOriginValues}
				transformOrigin={transformOriginValues}
				open={Boolean(gearAnchorEl)}
				onClose={handleGearMenuClose}
				MenuListProps={{ sx: { py: 0 } }}
			>
				<MenuItem divider={true} sx={{ padding: 0 }} >
					<ToggleDensityButton table={table} title='Table Density' />
				</MenuItem>
				<MenuItem divider={true} sx={{ padding: 0 }} >
					<ShowHideColumnsButton table={table} title='Show/Hide Columns' />
				</MenuItem>
				{importEnabled && <MenuItem divider={true} sx={{ padding: 0 }} >
					<ImportButton title='Import Entries' setGearAnchorEl={setGearAnchorEl} setOpen={context.dataDialog.setDialogImport} />
				</MenuItem>}
				<MenuItem divider={true} sx={{ padding: 0 }} >
					<ExportButton title='Export Entries' setGearAnchorEl={setGearAnchorEl} setOpen={context.dataDialog.setExportDialog}/>
				</MenuItem>
			</Menu>
		</div>
	);
};

export default GearMenu;
