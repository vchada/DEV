import { ContainerUserArea } from './styled';
import { Button, Menu, MenuItem } from '@mui/material';
import { MouseEvent, useContext, useState } from 'react';
import { HiUserCircle } from 'react-icons/hi';
import { UserInfoContext } from '../../../context/UserInfoContext';
import { Link } from 'react-router-dom';

export const UserArea = () => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const handleClick = (event: MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const userInfo = useContext(UserInfoContext);

  return (
    <ContainerUserArea>
      <div>
        <Button
          id="basic-button"
          aria-controls={open ? 'basic-menu' : undefined}
          aria-haspopup="true"
          aria-expanded={open ? 'true' : undefined}
          onClick={handleClick}
        >
          <HiUserCircle />
          <span>{userInfo.name}</span>
        </Button>
        <Menu
          id="basic-menu"
          anchorEl={anchorEl}
          open={open}
          onClose={handleClose}
          MenuListProps={{
            'aria-labelledby': 'basic-button',
          }}
        >
          <MenuItem onClick={handleClose}>Logout</MenuItem>
          <MenuItem onClick={handleClose}><Link className="" to="/feedback">
          Feedback
        </Link></MenuItem>
        </Menu>
      </div>
    </ContainerUserArea>
  );
};
