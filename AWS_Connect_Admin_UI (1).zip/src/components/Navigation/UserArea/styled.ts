import styled from 'styled-components';

export const ContainerUserArea = styled.div`
  padding-right: 4px;
  button {
    gap: 0.4rem;
    align-items: center;
    span {
      color: var(--blue-500);
      text-transform: capitalize;
      line-height: 0;
      font-size: 0.8rem;
    }

    svg {
      font-size: 1.4rem;
      color: var(--blue-500);
    }
  }

  @media (max-width: 550px) {
    display: none;
  }
`;
