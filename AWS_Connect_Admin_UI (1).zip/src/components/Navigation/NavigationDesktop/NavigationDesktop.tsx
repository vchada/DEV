import { SyntheticEvent } from 'react';
import { Tab, Tabs } from '@mui/material';
import { DataItemsProps, NavigationDesktopProps } from '../header';
import { useNavigation } from '../../../context/Navigation/useNavigation';

export const NavigationDesktop = ({ dataItems }: NavigationDesktopProps) => {
  const { controlStage } = useNavigation();
  const handleChange = (event: SyntheticEvent, newValue: number) => {
    event && controlStage.toStage(newValue);
  };

  return (
    <>
      <Tabs
        className="navDesk"
        value={controlStage.currentStage}
        onChange={handleChange}
        aria-label="navigation tabs"
        style={{'marginLeft': '50px'}}
      >
        {dataItems &&
          dataItems.map((itemNav: DataItemsProps) => (
            <Tab value={itemNav.value} label={itemNav.nameItem} key={itemNav.value} style={{'fontWeight' : '650'}} />
          ))}
      </Tabs>
    </>
  );
};
