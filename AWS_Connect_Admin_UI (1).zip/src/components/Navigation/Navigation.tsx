import { Link } from 'react-router-dom';
import { BrandArea } from './BrandArea/BrandArea';
import { UserArea } from './UserArea/UserArea';
import { ContainerNavigation } from './styled';


export const Navigation = () => {
  return (
    <ContainerNavigation style={{'marginBottom': '25px'}}>
      <div className="content_nav">
        <div style={{'display': 'flex', 'alignContent': 'center', 'alignItems': 'center'}}>
        <Link className="nav-link link-danger" to="/">          
          <BrandArea />
        </Link>
        <h1 className='text-[var(--blue-500)] ml-[10px] font-[Montserrat] font-[650] text-[20px]'> | Admin Portal</h1>
        </div>
        <UserArea />
      </div>
    </ContainerNavigation>
  );
};
