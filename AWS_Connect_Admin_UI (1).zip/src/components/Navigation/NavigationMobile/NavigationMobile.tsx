import { RxHamburgerMenu } from 'react-icons/rx';
import { Button } from '@mui/material';
import { DataItemsProps, NavigationMobileProps } from '../header';
import { ContainerMobileNavigator, WindowNavigation } from './styled';
import LogoImg from '../../../assets/imgs/logo.png';
import { useState } from 'react';
import { useNavigation } from '../../../context/Navigation/useNavigation';

export const NavigationMobile = ({ dataItems }: NavigationMobileProps) => {
  const { controlStage } = useNavigation();
  const [navOpen, setNavOpen] = useState(false);

  const handleNavView = () => {
    setNavOpen(!navOpen);
  };

  const handleToggle = () => {
    handleNavView();
  };

  const handleChange = (newValue: number) => {
    controlStage.toStage(newValue);
    setNavOpen(false);
  };

  return (
    <>
      <ContainerMobileNavigator>
        <RxHamburgerMenu
          onClick={handleToggle}
          className={navOpen ? 'rotate-icon-menu' : undefined}
        />
      </ContainerMobileNavigator>
      <WindowNavigation $statenav={navOpen} onClick={handleToggle}>
        <div
          className="contentNav"
          onClick={(event) => {
            event.stopPropagation();
          }}
        >
          <div className="logoMob">
            <img src={LogoImg} alt="logo" width={'120px'} height={'23px'} />
          </div>
          <div className="itemsNavMob">
            {dataItems &&
              dataItems.map((itemNav: DataItemsProps) => {
                return (
                  <Button
                    className={
                      controlStage.currentStage === itemNav.value ? 'active' : undefined
                    }
                    key={itemNav.value}
                    onClick={() => handleChange(itemNav.value)}
                  >
                    {itemNav.icon}
                    {itemNav.nameItem}
                  </Button>
                );
              })}
          </div>
        </div>
      </WindowNavigation>
    </>
  );
};
