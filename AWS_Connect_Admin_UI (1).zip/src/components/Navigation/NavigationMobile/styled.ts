import styled, { css } from 'styled-components';

interface WindowNavigationProps {
  $statenav: boolean;
}

export const ContainerMobileNavigator = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 2px;
  border-radius: 4px;

  .rotate-icon-menu {
    transform: rotate(90deg);
  }

  svg {
    font-size: 1.4rem;
    color: var(--blue-500);
  }

  @media (min-width: 550px) {
    display: none;
  }
`;

export const WindowNavigation = styled.div<WindowNavigationProps>`
  height: 100vh;
  left: 0;
  right: 0;
  top: 0px;
  bottom: 0;
  position: absolute;
  z-index: 20;
  background-color: #000000a8;

  ${(props) =>
    props.$statenav
      ? css`
          opacity: 1;
        `
      : css`
          display: none;
          opacity: 0;
        `}

  .contentNav {
    width: 280px;
    height: 100%;
    background-color: var(--gray-50);
    display: flex;
    justify-content: flex-start;
    align-items: center;
    flex-direction: column;
    overflow: auto;

    padding: 2rem 1rem;
    gap: 2rem;
    animation: slideIn 0.2s ease-in-out;

    @keyframes slideIn {
      from {
        transform: translateX(-100%);
      }

      to {
        transform: translateX(0);
      }
    }

    .logoMob {
      width: 100%;
      display: flex;
      justify-content: flex-start;
      align-items: center;
    }

    .itemsNavMob {
      width: 100%;
      display: flex;
      justify-content: flex-start;
      align-items: flex-start;
      flex-direction: column;
      gap: 0.2rem;

      .active {
        background-color: var(--blue-500);
        color: var(--gray600);

        svg {
          color: var(--gray600);
        }
      }

      button {
        svg {
          font-size: 1.1rem;
          color: var(--blue-500);
        }
        background-color: transparent;
        gap: 1rem;
        color: var(--blue-500);
        width: 100%;
        justify-content: flex-start;
        padding: 0.8rem !important;
      }
    }
  }
`;
