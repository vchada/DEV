import { SyntheticEvent } from 'react';
import { Tab, Tabs } from '@mui/material';
import { DataItemsProps, NavigationDesktopProps } from '../Navigation/header';
import { useHOONavigation } from '../../context/HOONavigationContext/useNavigation';

export const HOONavigation = ({ dataItems }: NavigationDesktopProps) => {
  const { controlStage } = useHOONavigation();
  const handleChange = (event: SyntheticEvent, newValue: number) => {
    event && controlStage.toStage(newValue);
  };

  return (
    <>
      <Tabs
        className="navDesk mb-[10px]"
        value={controlStage.currentStage}
        onChange={handleChange}
        aria-label="navigation tabs"
      >
        {dataItems &&
          dataItems.map((itemNav: DataItemsProps) => (
            <Tab value={itemNav.value} label={itemNav.nameItem} key={itemNav.value} style={{'fontWeight' : '650'}} />
          ))}
      </Tabs>
    </>
  );
};