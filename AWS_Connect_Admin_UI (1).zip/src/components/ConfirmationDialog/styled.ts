import styled from 'styled-components';

export const ConfirmationUpdateContent = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  padding: 32px;

  p {
    font-size: 1rem;
    color: var(--gray-600);
    font-weight: 500;
    line-height: 1.5rem;
  }
`;

export const FooterConfirmation = styled.footer`
  width: 100%;
  display: flex;
  justify-content: CENTER;
  align-items: center;
  gap: 0.75rem;
  padding-top: 1rem;

  .btn-history {
    background-color: var(--gray-400);

    &:hover {
      background-color: var(--gray-400);
      opacity: 0.8;
    }
  }

  div {
    button {
      letter-spacing: 0.8px;
      line-height: 1.25;
      padding: 8px 10px;
      font-weight: 600;


      &:disabled {
        background-color: var(--gray-100);
      }
    }
  }
`;
