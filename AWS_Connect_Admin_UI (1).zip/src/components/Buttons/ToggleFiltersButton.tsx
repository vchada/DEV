import React from "react";
import { MRT_TableInstance } from "material-react-table";
import { Tooltip } from "@mui/material";
import ToggleDensityIcon from "../Icons/ToggleDensityIcon";

interface ToggleFiltersButtonProps {
	table: MRT_TableInstance<any>;
}

const ToggleFiltersButton: React.FC<ToggleFiltersButtonProps> = ({ table }) => {
	const {
		getState,
		options: {
			localization,
		},
		setShowColumnFilters
	} = table;

	const { showColumnFilters } = getState();

	const handleToggleShowFilters = () => {
        setShowColumnFilters(!showColumnFilters);
	}

	return (
		<div className="flex justify-start content-between p-2">
			<Tooltip title={localization.showHideFilters}>
				<button className="" type='button' onClick={handleToggleShowFilters} >
					<span className="flex flex-row">
						<ToggleDensityIcon />
						<p className="pl-1 text-base">Toggle Density</p>
					</span>
				</button>
			</Tooltip>
		</div>
	);
}

export default ToggleFiltersButton;
