import React from "react";
import { MRT_TableInstance } from "material-react-table";
import { Tooltip } from "@mui/material";
import ToggleDensityIcon from "../Icons/ToggleDensityIcon";
import GearMenuIcon from "../Icons/GearMenuIcons";

interface ToggleDensityButtonProps {
	table: MRT_TableInstance<any>;
	title?: string;
}

const ToggleDensityButton: React.FC<ToggleDensityButtonProps> = ({ table, title }) => {
	const {
		getState,
		setDensity
	} = table;

	const { density } = getState();

	const handleToggleDensePadding = () => {
		const nextDensity =
			density === 'comfortable'
				? 'compact'
				: density === 'compact'
					? 'spacious'
					: 'comfortable';

		setDensity(nextDensity);
	}

	return (
		<>
			<button className="flex flex-grow px-4 py-2" type='button' onClick={handleToggleDensePadding}>
				<div className="flex justify-start content-center p-2">
					<Tooltip title={title}>
						<span className="flex flex-row contents-center">
							<GearMenuIcon>
								<ToggleDensityIcon />
							</GearMenuIcon>
							<p className="text-base content-center">{title}</p>
						</span>
					</Tooltip>
				</div>
			</button>
		</>
	);
}

export default ToggleDensityButton;
