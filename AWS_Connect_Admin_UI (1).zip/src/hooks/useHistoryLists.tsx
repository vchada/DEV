import { useMutation, useQuery } from 'react-query';
import { getHistories } from '../services/History/getHistory';
import { errorToast, successToast } from '../components/Toast/Toast';
import { useHistory } from '../context/History/useHistory';
import { updatePrompts } from '../services/Prompt/updatePrompt';

interface DataUpdateProps {
  user: string;
  updateTime: string;
  'itemId#collection_key': string;
  currentPrompt: string;
  previousMessage: string;
  hasRestore: boolean;
}

interface dataUpdateRequestProps {
  item_id: string;
  collection_key: string;
  newPrompt: string;
  previousPrompt: string;
}

interface dataCreatedHistProps {
  method: string;
  user: string;
  dataUpdate: dataUpdateRequestProps;
}

export const useHistoryLists = () => {
  const { setListHistoryPrompts, dataDialog } = useHistory();
  const { isLoading: loadingHistoriesList, refetch } = useQuery(
    'list_history_prompt',
    async () => {
      return await getHistories();
    },
    {
      enabled: !dataDialog.dialogHistoryRollback,
      onSuccess: (data) => setListHistoryPrompts(data),
      onError: () => errorToast('Error receiving list'),
    },
  );

  const separatePropsRollback = (item: string) => {
    const separateString = item?.split('#');
    const [id, collection] = separateString;
    return {
      itemId: id,
      collection_key: collection,
    };
  };

  const handleRollbackPrompt = (dataItem: DataUpdateProps | any) => {
    const { itemId, collection_key } = separatePropsRollback(
      dataItem['itemId#collection_key'],
    );

    const dataUpdate = {
      method: 'UPDATE_PROMPTS',
      user: 'USER TEST',
      dataUpdate: {
        item_id: itemId,
        collection_key: collection_key,
        newPrompt: dataItem?.previousMessage,
        previousPrompt: dataItem?.currentPrompt,
      },
    };

    mutateRollbackPrompt(dataUpdate);
  };

  const { mutate: mutateRollbackPrompt, isLoading: loadingRollbackPrompt } = useMutation({
    mutationFn: async (dataCreate: dataCreatedHistProps) => {
      return await updatePrompts(dataCreate);
    },

    onSuccess: () => {
      successToast('Success rollback item');
      dataDialog.setDialogHistoryRollback(false);
      refetch();
    },
    onError: (): any => {
      errorToast('Error rollback item');
      dataDialog.setDialogHistoryRollback(false);
    },
  });

  return { loadingHistoriesList, handleRollbackPrompt, loadingRollbackPrompt };
};
