import { useMutation, useQuery } from 'react-query';
import { useHomePrompt } from '../context/Home/useHomePrompt';
import { errorToast } from '../components/Toast/Toast';
import { updatePrompts } from '../services/Prompt/updatePrompt';
import { getPrompts } from '../services/Prompt/getPrompts';
import { getAgentHierarchy } from '../services/UserManagement/getAgentHierarchy';
import { useUserManagementContext } from '../context/UserManagement/useUserManagementContext';
interface dataUpdateProps {
  method: string;
  user: string;
  dataUpdate: {
    item_id: string;
    collection_key: string;
    newPrompt: string;
    previousPrompt: string;
  };
}

export const useHomeLists = () => {
  const { setListPromptsHome, dataSelected } = useHomePrompt();
  const { setAgentHierarchy } = useUserManagementContext();


  const { isLoading: loadingHomePromptsList } = useQuery(

    'List_Prompts',
    async () => {
      return await getPrompts();
    },
    {
      enabled: dataSelected.selectedItemPrompt === null,
      onSuccess: (data) => {
        setListPromptsHome(data);
      },
      onError: () => errorToast('Error receiving prompt list'),
    },
  );

  const {isLoading: loadingUserList} = useQuery(
    'List_Agent_Hierarchy',
    async () => {
      return await getAgentHierarchy();
    },
    {
      enabled: true,
      onSuccess: (data) => setAgentHierarchy(data),
      onError: () => errorToast('Error receiving user list'),
    },
  );

  const { mutate: mutateUpdatePrompt, isLoading: loadingUpdatePrompt } = useMutation({
    mutationFn: async (dataCreateSchedule: dataUpdateProps) => {
      return await updatePrompts(dataCreateSchedule);
    },
  });

  return {
    loadingHomePromptsList,
    loadingUserList,
    loadingUpdatePrompt,
    mutateUpdatePrompt,
  };
};
