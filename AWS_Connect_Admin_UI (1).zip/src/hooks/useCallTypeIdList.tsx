import { useMutation } from 'react-query';
import { CallTypeId } from '../pages/Queues/StatePriority/Types/Types';
import { addCallTypeId } from '../services/Queues/StatePriority/addCallTypeId';
import { deleteCallTypeIds } from '../services/Queues/StatePriority/deleteCallTypeIds';
import { importCallTypeIds } from '../services/Queues/StatePriority/importCallTypeIds';
import { updateCallTypeIds } from '../services/Queues/StatePriority/updateCallTypeIds';



interface dataUpdateProps {
  name: string;
  loginId: string;
  payload: any[];
}

interface dataAddProps {
  method: string;
  user: string;
  payload: CallTypeId[]
}

interface dataImportProps {
  // modified: {
  //     method: string;
  //     user: string;
  //     data: any[]
  // },
  // new: {
  //     method: string;
  //     user: string;
  //     data: any[]
  // }
  name: string;
  loginId: string;
  payload: any[]

}

interface dataDeleteProps {
  method: string;
  user: string;
  payload: any[]
}

export const useCallTypeIdLists = () => {

  const { mutate: mutateUpdateCallTypeIds } = useMutation({
    mutationFn: async (dataUpdateSchedule: dataUpdateProps) => {
      return await updateCallTypeIds(dataUpdateSchedule);
    },
  });

  const { mutate: mutateAddCallTypeId } = useMutation({
    mutationFn: async (dataUpdateSchedule: dataAddProps) => {
      return await addCallTypeId(dataUpdateSchedule);
    },
  });

  const { mutate: mutateImportCallTypeIds } = useMutation({
    mutationFn: async (dataUpdateSchedule: dataImportProps) => {
      return await importCallTypeIds(dataUpdateSchedule);
    },
  });

  const { mutate: mutateDeleteCallTypeIds } = useMutation({
    mutationFn: async (dataUpdateSchedule: dataDeleteProps) => {
      return await deleteCallTypeIds(dataUpdateSchedule);
    },
  });




  return {
    mutateUpdateCallTypeIds,
    mutateAddCallTypeId,
    mutateImportCallTypeIds,
    mutateDeleteCallTypeIds
  };
};
