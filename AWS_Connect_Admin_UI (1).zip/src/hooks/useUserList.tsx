import { useMutation, useQuery } from 'react-query';
import { errorToast } from '../components/Toast/Toast';
// import { updatePrompts } from '../services/Prompt/updatePrompt';
import { useUserManagementContext } from '../context/UserManagement/useUserManagementContext';
import { User } from '../pages/UserManagement/User';
import { getUsers } from '../services/UserManagement/getUsers';
import { updateUsers } from '../services/UserManagement/updateUser';

type PayLoadProps = {
  updatedData: {
    secProfiles: any,
    routeProfiles: any,
    phone: string,
    acw: number,
    users: User[]
  }

};

interface dataUpdateProps {
  method: string;
  user: string;
  dataUpdate: {
    payload: PayLoadProps | undefined
  };
}

export const useUserLists = () => {
  const { setUsersUserManagement } = useUserManagementContext();

  const { isLoading: loadingUserList } = useQuery(
    'List_Users',
     () => {
      return getUsers();
    },
    {
      enabled: true,
      // enabled: listOfUsersUM.length == 0,
      onSuccess: (data) => setUsersUserManagement(data),
      onError: () => errorToast('Error receiving list'),
    },
  );


  const { mutate: mutateUpdateUser } = useMutation({
    mutationFn: async (dataUpdateSchedule: dataUpdateProps) => {
      return await updateUsers(dataUpdateSchedule);
    },
  });
  



  return {
    loadingUserList,
    mutateUpdateUser
  };
};
