// globalStyles.js
import { createGlobalStyle } from 'styled-components';

export const GlobalStyle = createGlobalStyle`
:root {
  --white: #FFFFFF;
  --black: #141414;
  --blue-100: #dcdced;
  --blue-200: #b8bbdb;
  --blue-300: #959ac9;
  --blue-400: #717bb7;
  --blue-450: #005CCC;
  --blue-500: #005290;
  --blue-600: #0F4293;
  --blue-700: #141a31;
  --gray-50: #F0F4FB;
  --gray-100: #e0e0e0;
  --gray-200: #6c6c6c;
  --gray-300: #525252;
  --gray-400: #444444;
  --gray-500: rgb(34, 34, 34);;
  --green-500: #46da44;
  --red: #b6091a;  
}

*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Roboto', sans-serif;

    ::-moz-selection { /* Code for Firefox */
}

::selection {
  color: #ffffff;
  background: #474747;
}

   &::-webkit-scrollbar {
    width: 8px;
  }

  &::-webkit-scrollbar-track {
    background-color: transparent;
  }

  &::-webkit-scrollbar:horizontal{
  height: 4px;
}

  &::-webkit-scrollbar-thumb {
    background-color: var(--gray-100);
    border-radius: 8px;
    border: 2px solid var(--gray-100);
  }

  &::-webkit-scrollbar-corner {
    background-color: transparent;
  } 
}
  body {
    width: 100vw;
    height: 100vh;
    margin: 0;
    padding: 0;
    font-family: 'Roboto', sans-serif;
  }

  h1, h2, h3{
    font-family: 'Roboto', Sans-Serif;
    font-weight: 500;
  }


  span, p, input, label,button{
    font-family: 'Roboto', Sans-Serif;
    font-weight: 400;
  }

  button{
    cursor: pointer;
    outline: none;
  }

  select, option, input{
    outline: none;
  }

  a{
  text-decoration: none;
  color: inherit;
  } 
  
  @media(max-width: 1080px){
  html{
    font-size: 93.75%;
  }
}
  @media(max-width: 720px){
    html{
      font-size: 87.5%;
    }
  }

input:-webkit-autofill,
input:-webkit-autofill:hover,
input:-webkit-autofill:focus,
textarea:-webkit-autofill,
textarea:-webkit-autofill:hover,
textarea:-webkit-autofill:focus,
select:-webkit-autofill,
select:-webkit-autofill:hover,
select:-webkit-autofill:focus {
  -webkit-box-shadow: 0 0 0px 1000px transparent inset;
  transition: background-color 5000s ease-in-out 0s;
}
`;
