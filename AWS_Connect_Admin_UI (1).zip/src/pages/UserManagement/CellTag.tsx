import { useCallback } from "react";
// import { styled } from "styled-components";
// import { useUserManagementContext } from "../../context/UserManagement/useUserManagementContext";
import { User } from "./User";

type CellTagProps = {
    context: any;
    children: any;
}

export const CellTag = ({context, children}: CellTagProps) => {

    const { dataDialog, dataSelected } = context;


  const { setDialogEditPrompt } = dataDialog;


  const openDialog = () => {
    setDialogEditPrompt(true);
  };
//   const closeDialog = () => {
//     setDialogEditPrompt(false);
//   };

    const handleEdit = useCallback(
        (dataEdit: User) => {
            dataSelected.setSelectedItemPrompt(dataEdit)
            openDialog();
        },
        [openDialog],
    );
    
    
      
    
   return <p style={{color: 'blue', cursor: 'pointer'}} onClick={() => handleEdit(children.row.original)}>
        {children.getValue()}
    </p>

    
        
}