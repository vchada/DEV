import { useState, ChangeEvent, FormEvent } from 'react';
import { ContentFormUpdate, FooterDialog } from './styled';
import { Button, Stack } from '@mui/material';
import { InputComponent } from '../../../../../../components/InputComponent';
// import { errorToast } from '../../../../../../components/Toast';
// import { useUserManagementContext } from '../../../../../../context/UserManagement/useUserManagementContext';
import { User } from '../../../../User';
import Select from 'react-select';
// import React from 'react';

type PayLoadProps = {
  updatedData: {
    secProfiles: any,
    routeProfiles: any,
    phone: string,
    acw: number,
    users: User[]
  },
};

interface UpdateUserProps {
  // itemPrompt: {
  //   itemPrompt: string;
  //   setItemPrompt: (item: string) => void;
  // };
  userMgmtContext: any;
  selectedUsers: User[];
  setPayload: (payload: PayLoadProps) => void;
  errorPrompt: {
    errorPrompt: boolean;
    setErrorPrompt: (state: boolean) => void;
  };
  changeStage: () => void;
}



type SecurityProfileProps = {
  Id: string;
  Name: string;
}

type RoutingProfileProps = {
  Id: string;
  Name: string;
}

// type PhoneTypeProps = {
//   Id: string;
//   Name: string;
// }

export const UpdateUser = ({
  setPayload,
  userMgmtContext,
  selectedUsers,
  errorPrompt,
  changeStage,
}: UpdateUserProps) => {
  const { dataDialog } = userMgmtContext;

  // let multipeSelections = selectedUsers.length > 1 ? false: true;

  const routingProfileOptions: RoutingProfileProps[] = [
  {
    Id: "",
    Name: "-"
  },
  {
    Id: "eb9bb698-3bf3-4219-b74f-5c04b115d759",
    Name: "gw-spec-sls-b-r-dv1-rp"
  },
  {
    Id: "ef47e231-a882-4781-97b9-b39d6da02ec7",
    Name: "gw-moat-sls-bndl-hom-dv1-rp"
  },
  {
    Id: "216fdb6c-23db-410c-9c64-b0eb6a48304d",
    Name: "gw-sales-rb-c-a-rs-dv1-rp"
  },
  {
    Id: "fd828cbd-5827-403b-ba70-557b29d1fabb",
    Name: "gw-moat-sls-bnd-grn-dv1-rp"
  },
  {
    Id: "81d5a183-75f3-4179-bde5-b04b4c03f839",
    Name: "Basic Routing Profile"
  },
]

const securityProfileOptions: SecurityProfileProps[] = [
  {
    Id: "4834225a-eda6-4eb9-b753-5d9160b3c6ec",
    Name: "Admin"
  },
  {
    Id: "bc4efe46-3481-4c35-ac99-757fa21b0453",
    Name: "Agent"
  },
]

const phoneTypeOptions = [{label: 'SOFT_PHONE', value: 'SOFT_PHONE'}, {label: 'DESK_PHONE', value: 'DESK_PHONE'}]



  const closeDialog = () => dataDialog.setDialogEditPrompt(false);

  // const [hasPromptRegex, setHasPromptRegex] = useState(false);
  const [securityProfilesRender, setSecurityProfilesRender] = useState<SecurityProfileProps[]>(selectedUsers.length == 1 ? [...selectedUsers[0].security_profiles] : []);
  const [routingProfileRender, setRoutingProfileRender] = useState(selectedUsers.length == 1 ? {Id: selectedUsers[0].routing_profile.Id, Name: selectedUsers[0].routing_profile.Name} : {Id: '', Name: ''});
  const [phoneTypeRender, setPhoneTypeRender] = useState<string>(selectedUsers.length == 1 ? selectedUsers[0].phone_config.PhoneType : '');
  const [acwRender, setACWRender] = useState(selectedUsers.length == 1 ? selectedUsers[0].phone_config.AfterContactWorkTimeLimit : 0);
  // console.log("initialization...");
  // console.log('securityProfilesRender', securityProfilesRender)
  // console.log('routingProfileRender', routingProfileRender)
  // console.log('phoneTypeRender', phoneTypeRender)
  // console.log('acwRender', acwRender)

  // useEffect(() => {
  //   if (errorPrompt && phoneTypeRender.length > 0) {
  //     errorPrompt.setErrorPrompt(false);
  //   }
  // }, [errorPrompt]);

  // useEffect(() => {
  //   if (selectedUsers.length == 1) {
  //     // console.log("1 User")

  //     console.log('selectedUsers[0]: ', selectedUsers[0])
  //     // setSecurityProfilesRender([...selectedUsers[0].security_profiles]);
  //     // setRoutingProfileRender({Id: selectedUsers[0].routing_profile.Id, Name: selectedUsers[0].routing_profile.Name})

  //     // setPhoneTypeRender(selectedUsers[0].phone_config.PhoneType);
  //     // console.log('phoneTypeRenderer: ', selectedUsers[0].phone_config.PhoneType)
  //     // setACWRender(selectedUsers[0].phone_config.AfterContactWorkTimeLimit)
  //     // console.log('Function: ', selectedUsers[0].security_profiles.map((profile: SecurityProfileProps) => {
  //     //   return {label: profile.Name, value: profile.Id}
  //     // }))
  //     // const result = selectedUsers[0].security_profiles.map((profile: SecurityProfileProps) => {
  //     //   return {label: profile.Name, value: profile.Id}
  //     // });
  //     // setCurrentSecurityProfiles(result)
      
  //   } else {
  //     setSecurityProfilesRender([]);
  //     // setRoutingProfileRender({})

  //     setPhoneTypeRender('');
  //     setACWRender(0)
  //     console.log('Phone Type Multiple selections: ', phoneTypeRender);
  //   }
  // }, []);

  const handleRoutingProfileSelect = (e: any) => {
    // console.log(e);
    const found: any = routingProfileOptions.find(obj => obj.Name === e.Name);
    setRoutingProfileRender({Id: found.Id, Name: found.Name});

  };

  const handleSecurityProfileSelect = (e: any) => {
    // console.log(e);
    setSecurityProfilesRender(e);
  };

  const handlePhoneTypeSelect = (e: any) => {
    // console.log(e);
    const found: any = phoneTypeOptions.find(obj => obj.value === e.value);
    setPhoneTypeRender(found.value);
  };

  const handleUpdateItem = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // if (phoneTypeRender === '') {
    //   errorPrompt.setErrorPrompt(true);
    //   return errorToast('Field cannot be empty');
    // }

    // if (!itemPrompt.itemPrompt) {
    //   errorPrompt.setErrorPrompt(true);
    //   return;
    // }

    // if (!hasPromptRegex) {
    //   itemPrompt.setItemPrompt(phoneTypeRender);
    // }

    // const addSpeakCodeString = `<sp${securityProfilesRender}</speak>`;

    // itemPrompt.setItemPrompt(addSpeakCodeString);
    const payload = {
      updatedData: {
        secProfiles: securityProfilesRender,
        routeProfiles: routingProfileRender,
        phone: phoneTypeRender,
        acw: acwRender,
        users: selectedUsers
      },
      
    }
    setPayload(payload);
    changeStage();
  };

  return (
    <ContentFormUpdate onSubmit={handleUpdateItem}>
      <label htmlFor="securityProfileId">Security Profile(s)</label>
      <Select id='securityProfileId' placeholder={'Choose Security Profiles...'} maxMenuHeight={200} options={securityProfileOptions} getOptionLabel={(option: any)=>option.Name} getOptionValue={(option: any)=>option.Id} isMulti={true} defaultValue={securityProfilesRender} onChange={handleSecurityProfileSelect}></Select>
      
      <br />
      
      <label id='routingProfileId' htmlFor="routingProfileId">Routing Profile</label>
      <Select id='routingProfileId' maxMenuHeight={100} options={routingProfileOptions} getOptionLabel={(option)=>option.Name} getOptionValue={(option)=>option.Id} value={routingProfileRender} onChange={handleRoutingProfileSelect}></Select>

      <br />

      <label htmlFor="phoneTypeId">Phone Type</label>
      <Select id='phoneTypeId' maxMenuHeight={100} options={phoneTypeOptions}  onChange={handlePhoneTypeSelect} defaultValue={{label: phoneTypeRender, value: phoneTypeRender}}></Select>
      
      <br />
      <br />
      <br />
      <br />

      <InputComponent
        label={'Ater Contact Work (ACW) Timeout'}
        fullWidth
        multiline
        rows={1}
        value={acwRender}
        onChange={(e: ChangeEvent<HTMLInputElement>) => setACWRender(Number(e.target.value))}
        error={errorPrompt.errorPrompt}
        helperText={
          errorPrompt.errorPrompt || acwRender === null
            ? 'ACW is required'
            : ' '
        }
      />

      
      <FooterDialog>
        <Stack spacing={1} direction={'row'}>
          <Button variant="contained" color="warning" onClick={closeDialog}>
            Cancel
          </Button>
          <Button
            variant="contained"
            color="primary"
            type="submit"
            // disabled={promptRender.length === 0}
          >
            Update
          </Button>
        </Stack>
      </FooterDialog>
    </ContentFormUpdate>
  );
};
