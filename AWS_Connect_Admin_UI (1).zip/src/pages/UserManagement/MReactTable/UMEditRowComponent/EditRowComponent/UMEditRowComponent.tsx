import { useState } from 'react';
import { MdEdit } from 'react-icons/md';

import { ContainerEditRow, ContentDialog, HeaderDialog } from './styled';
import { UpdateUser } from './UMUpdateUser/UMUpdateUser';
import { ConfirmationUpdate } from './UMConfirmationUpdate/UMConfirmationUpdate';
// import { LoadingComponent } from '../../../../../components/LoadingComponent';
import { successToast, errorToast } from '../../../../../components/Toast/Toast';
// import { useHomeLists } from '../../../../../hooks/useHomeLists';
// import { useUserManagementContext } from '../../../../../context/UserManagement/useUserManagementContext';
import { User } from '../../../User';
import { useUserLists } from '../../../../../hooks/useUserList';

interface dataUpdateProps {
  method: string;
  user: string;
  dataUpdate: {
    payload: PayLoadProps | undefined
  };
}


type PayLoadProps = {
  updatedData: {
    secProfiles: any,
    routeProfiles: any,
    phone: string,
    acw: number,
    users: User[]
  }

};

export const UMEditRowComponent = ({userMgmtContext}: any) => {
  const { dataDialog, dataSelected, selectedUsers } = userMgmtContext;
  const { mutateUpdateUser } = useUserLists();
  const [stageRenderEditPrompt, setStageRenderEditPrompt] = useState<number>(0);
  const [payload, setPayload] = useState<PayLoadProps>();
  const [errorPrompt, setErrorPrompt] = useState<boolean>(false);


  // useEffect(() => {
  //   setItemPrompt(dataSelected?.selectedItemPrompt?.resource_name ?? '');
  // }, [dataSelected]);

  const handleUpdateItem = async () => {
    const dataUpdate: dataUpdateProps = {
      method: 'UPDATE_USER',
      user: 'USER TEST',
      dataUpdate: {
        payload: payload,
      },
    };

    return await mutateUpdateUser(dataUpdate, {
      onSuccess: () => {
        successToast('success updating prompt');
        dataSelected.setSelectedItemPrompt(null);
        dataDialog.setDialogEditPrompt(false);
      },
      onError: (): any => {
        setStageRenderEditPrompt(0);
        return errorToast('Error updating item');
      },
    });
  };

  const flowStates = [
    <UpdateUser
      setPayload={setPayload}
      selectedUsers={selectedUsers}
      userMgmtContext={userMgmtContext}
      // itemPrompt={{ itemPrompt, setItemPrompt }}
      errorPrompt={{ errorPrompt, setErrorPrompt }}
      changeStage={() => setStageRenderEditPrompt(1)}
    />,
    <ConfirmationUpdate
      handleUpdate={() => handleUpdateItem()}
      hasError={errorPrompt || selectedUsers.length === 0}
      changeStage={() => setStageRenderEditPrompt(0)}
    />,
  ];

  return (
    <ContainerEditRow>
      <HeaderDialog>
        <MdEdit />
        {/* <h1>Edit Prompt</h1> */}
        {selectedUsers.length == 1 ? <h1>Edit {selectedUsers[0].resource_name}</h1> : <h1>Bulk Edit</h1>}
      </HeaderDialog>
      {/* {loadingUpdatePrompt && <LoadingComponent />} */}
      <ContentDialog>{flowStates[stageRenderEditPrompt]}</ContentDialog>
    </ContainerEditRow>
  );
};
