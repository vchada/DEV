import { useMemo } from 'react';
import {
  MaterialReactTable,
  type MRT_ColumnDef,
} from 'material-react-table';
import '../UserManagement'
import { CellTag } from '../CellTag';
import { SecProfCellTag } from '../SecProfCellTag';
import { User } from '../User'
// import { useUserLists } from '../../../hooks/useUserList';
import { Button } from '@mui/material';
export const MReactTable = ({ userMgmtContext }: any) => {

  const { dataDialog, agentHierarchy } = userMgmtContext;
  const { setDialogEditPrompt } = dataDialog;

  const openDialog = () => {
    setDialogEditPrompt(true);
  };

  const handleEdit = (dataEdit: User[]) => {
    if (dataEdit.length == 0) return;
    openDialog();
  };


  const data: User[] =
    userMgmtContext.listOfUsersUM.map((item: User) => {

      const user: User = {
        identifier: item.identifier,
        CreatedAt: item.CreatedAt,
        UpdatedAt: item.UpdatedAt,
        identity_info: item.identity_info,
        manually_updated: item.manually_updated,
        phone_config: item.phone_config,
        resource_name: item.resource_name,
        routing_profile: item.routing_profile,
        security_profiles: item.security_profiles,
        tags: item.tags,
        supervisor: ''
      }

      if (user.routing_profile === undefined) {
        user.routing_profile = {
          Id: '',
          Name: '-'
        }
      }
      const found: any = agentHierarchy.find((obj: { EmployeeId: string; }) => obj.EmployeeId == user.resource_name);
      if (found) {
        user.supervisor = found.SupervisorName;
      }





      return user;

      // return {
      //   identifier: item.identifier,
      //   CreatedAt: item.CreatedAt,
      //   UpdatedAt: item.UpdatedAt,
      //   identity_info: item.identity_info,
      //   manually_updated: item.manually_updated,
      //   phone_config: item.phone_config,
      //   resource_name: item.resource_name,
      //   routing_profile: item.routing_profile,
      //   security_profiles: item.security_profiles,
      //   tags: item.tags
      // }


    });


  // const handleEdit = useCallback(
  //     (dataEdit: ItemListProps) => {
  //         // console.log(dataEdit)
  //     //   dataSelected.setSelectedItemPrompt(dataEdit);
  //       openDialog();
  //     },
  //     [openDialog],
  // );


  const columns = useMemo<MRT_ColumnDef<User>[]>(
    () => [
      {
        accessorKey: 'resource_name',
        header: 'Login',
        Cell: ({ cell }) => (
          //     // <a onClick={() => handleEdit(cell.row.original)}>
          //     //     {cell.getValue()}
          //     // </a>
          <CellTag context={userMgmtContext}>{cell}</CellTag>
        ),
      },
      {
        accessorKey: 'routing_profile.Name',
        //   accessorFn: (row) => {
        //     if(row.routing_profile?.Name == undefined){
        //       row.routing_profile.Name = '-'
        //     }
        // },
        header: 'Routing Profile',
        // id: 'routing_profile'
        // Cell: ({ row }) => row.original.routing_profile.Name ?? '-'
      },
      {
        accessorKey: 'security_profiles',
        header: 'Security Profiles',
        Cell: ({ cell }) => (
          // <a onClick={() => handleEdit(cell.row.original)}>
          //     {cell.getValue()}
          // </a>
          <SecProfCellTag key={cell.row.original.identifier} context={userMgmtContext}>{cell}</SecProfCellTag>
        ),
      },
      {
        accessorKey: 'phone_config.AfterContactWorkTimeLimit',
        header: 'ACW Timeout',
      },
      {
        accessorKey: 'phone_config.PhoneType',
        header: 'Phone Type',
      },
      {
        accessorKey: 'supervisor',
        header: 'Supervisor',
      },
    ],
    [],
  );


  // const table = useMaterialReactTable({
  //   columns: columns,
  //   data: data,
  // enableStickyHeader: true,
  // enableBatchRowSelection: true,
  // columnFilterDisplayMode: 'popover',
  // muiTableContainerProps: { sx: { maxHeight: '650px' } },
  // enableRowSelection: true,
  // onRowSelectionChange: setRowSelection,
  // state: {rowSelection},
  // getRowId: (row => {return row.identifier}),
  // renderTopToolbarCustomActions: (() => 
  // <Button onClick= {() => {console.log(rowSelection)}}>
  //   {'Edit Selected Row(s)'}
  // </Button>)
  // });






  return <MaterialReactTable
    enableRowSelection
    enableBatchRowSelection
    // state={{rowSelection}}
    // onRowSelectionChange={setRowSelection}
    // getRowId={(row) => row.identifier}
    columns={columns}
    data={data}
    columnFilterDisplayMode='popover'
    enableStickyHeader={true}
    muiTableContainerProps={{ sx: { maxHeight: '650px' } }}
    renderTopToolbarCustomActions={({ table }) => (
      <Button onClick={() => {
        const users: User[] = [];
        table.getSelectedRowModel().rows.forEach((row) => {
          users.push(row.original);
        });
        userMgmtContext.setSelectedUsers(users);
        handleEdit(users);
      }}>
        {'Edit Selected Row(s)'}
      </Button>
    )}
    initialState={{ density: 'compact' }}
    // onColumnFiltersChange = {(filters) => {
    //   console.log('onFilterChange', filters);
    // }}
    selectAllMode='all'
  />



};

