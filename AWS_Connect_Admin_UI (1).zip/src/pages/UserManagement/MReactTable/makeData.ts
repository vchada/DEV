export type Person = {
  id: number;
  firstName: string;
  lastName: string;
  gender: string;
  age: number;
};

export const data = [
  {
    id: 1,
    firstName: 'Hugh',
    lastName: 'Mungus',
    gender: 'Male',
    age: 42,
  },
  {
    id: 2,
    firstName: 'Leroy',
    lastName: 'Jenkins',
    gender: 'Male',
    age: 51,
  },
  {
    id: 3,
    firstName: 'Candice',
    lastName: 'Nutella',
    gender: 'Female',
    age: 27,
  },
  {
    id: 4,
    firstName: 'Micah',
    lastName: 'Johnson',
    gender: 'Other',
    age: 32,
  },
  {
    id: 6,
    firstName: 'Micah',
    lastName: 'Johnson',
    gender: 'Other',
    age: 32,
  },
  {
    id: 7,
    firstName: 'Micah',
    lastName: 'Johnson',
    gender: 'Other',
    age: 32,
  },
  {
    id: 8,
    firstName: 'Micah',
    lastName: 'Johnson',
    gender: 'Other',
    age: 32,
  },
  {
    id: 9,
    firstName: 'Micah',
    lastName: 'Johnson',
    gender: 'Other',
    age: 32,
  },
  {
    id: 10,
    firstName: 'Micah',
    lastName: 'Johnson',
    gender: 'Other',
    age: 32,
  },
  {
    id: 11,
    firstName: 'Micah',
    lastName: 'Johnson',
    gender: 'Other',
    age: 32,
  },
  {
    id: 12,
    firstName: 'Micah',
    lastName: 'Johnson',
    gender: 'Other',
    age: 32,
  },
  {
    id: 13,
    firstName: 'Micah',
    lastName: 'Johnson',
    gender: 'Other',
    age: 32,
  },
];


// export const getData = () =>  {
//   interface ItemListProps {
//     item_id: string;
//     collection_key: string;
//     language_code: string;
//     item_content: string;
//     contact_flow_name: string;
//     item_type: string;
//   }
//   let counter = 1;
//   const context = useContext(HomeContext);
//    const data : ItemListProps[] = [
//     context.filteredPrompts.map((item: ItemListProps) => {
            
//       return {id: counter++, col1: item.collection_key, col2: item.contact_flow_name, col3: item.item_content, col4: item.item_id, col5: item.item_type, col6: item.language_code}
//     })
//   ];