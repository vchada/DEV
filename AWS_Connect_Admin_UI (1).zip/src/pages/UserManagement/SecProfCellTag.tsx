
type SecProfCellTagProps = {
	context: any;
	children: any;
}

export const SecProfCellTag = ({ children }: SecProfCellTagProps) => {

	let counter = 1;

	const combined = children.row.original.security_profiles.map((profile: any) => {
		return <p key={children.row.original.identifier + counter++} style={{ margin: 5 }}>{profile.Name}</p>
	})
	return <>{combined}</>
}