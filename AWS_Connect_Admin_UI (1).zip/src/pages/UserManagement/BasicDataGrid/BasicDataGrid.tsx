import { DataGrid, GridColDef, GridRowsProp, GridToolbar } from '@mui/x-data-grid';
import { useContext } from 'react';
import { HomeContext } from '../../../context/Home/HomeContext';


export const BasicExampleDataGrid = () => {
    interface ItemListProps {
        item_id: string;
        collection_key: string;
        language_code: string;
        item_content: string;
        contact_flow_name: string;
        item_type: string;
      }

    const context = useContext(HomeContext);

    const columns: GridColDef[] = [
        { field: 'col1', headerName: 'Collection Key', width: 150 },
        { field: 'col2', headerName: 'Contact Flow Name', width: 150 },
        { field: 'col3', headerName: 'Item Content', width: 150 },
        { field: 'col4', headerName: 'Item ID', width: 150 },
        { field: 'col5', headerName: 'Item Type', width: 150 },
        { field: 'col6', headerName: 'Language Code', width: 150 },
        ];
    let counter = 1;
    const rows: GridRowsProp = 
        context.filteredPrompts.map((item: ItemListProps) => {
            
            return {id: counter++, col1: item.collection_key, col2: item.contact_flow_name, col3: item.item_content, col4: item.item_id, col5: item.item_type, col6: item.language_code}
          })
    ;




  return (
    <div style={{ height: 800, width: '100%' }}>
      <DataGrid rows={rows} columns = {columns} slots={{ toolbar: GridToolbar }} />
    </div>
  );
}