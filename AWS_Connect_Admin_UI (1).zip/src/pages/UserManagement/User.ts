type SecurityProfileProps = {
    Id: string;
    Name: string;
}



export interface User {
    CreatedAt: string;
    UpdatedAt: string;
    identifier: string;
    identity_info: {
        SecondaryEmail: string;
    };
    manually_updated: boolean;
    phone_config: {
        AfterContactWorkTimeLimit: number;
        AutoAccept: boolean;
        PhoneType: string;
    };
    resource_name: string;
    routing_profile: {
        Id?: any;
        Name?: any;
    };
    security_profiles: SecurityProfileProps[]
    tags: any;
    supervisor: string;
}