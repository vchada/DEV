import {ContainerUserManagement } from './styled';
// import { PanelFilter } from './PanelFilter';
// import { TablePrompts } from './TablePrompts';
// import { DialogComponent } from '../../components/DialogComponent';
// import { EditRowComponent } from './EditRowComponent';
// import { useHomePrompt } from '../../context/Home/useHomePrompt';
// import { BasicExampleDataGrid } from './BasicDataGrid';
import { MReactTable } from './MReactTable/UMReactTable';
import { DialogComponent } from '../../components/DialogComponent/DialogComponent';
// import { PanelFilter } from './PanelFilter';
// import { TablePrompts } from './TablePrompts';
import { UMEditRowComponent } from './MReactTable/UMEditRowComponent/EditRowComponent/UMEditRowComponent';
import { useUserManagementContext } from '../../context/UserManagement/useUserManagementContext';
import { useUserLists } from '../../hooks/useUserList';
// import { useHomeLists } from '../../hooks/useHomeLists';

export const UserManagement = () => {

  useUserLists();
  
  const context = useUserManagementContext();

  const { dialogEditPrompt } = context.dataDialog;

  

  // const closeDialog = () => {
  //   setDialogEditPrompt(false);
  // };

  // const openDialog = () => {
  //   setDialogEditPrompt(true);
  // };

  return (
    <ContainerUserManagement initial={{opacity: 0}} animate={{opacity: 1}}>
      <MReactTable userMgmtContext={context} />
      <DialogComponent open={dialogEditPrompt} >
        <UMEditRowComponent userMgmtContext={context}/>
      </DialogComponent>
    </ContainerUserManagement>

  );
};
