import { Home } from '../Home/Home';
import { Navigation } from '../../components/Navigation/Navigation';
import { History } from '../History/History';
import { ContainerRenderPages } from './styled';
import { useNavigation } from '../../context/Navigation/useNavigation';
import { StatePriority } from '../Queues/StatePriority/StatePriority'
import { MdHistory, MdQueue } from 'react-icons/md';
import { NavigationDesktop } from '../../components/Navigation/NavigationDesktop/NavigationDesktop';
import { NavigationMobile } from '../../components/Navigation/NavigationMobile/NavigationMobile';
import { StateProficiency } from '../Queues/StateProficiency/StateProficiency';
import { HoursOfOperation } from '../Queues/HoursOfOperation/HoursOfOperation';

export const RenderPages = () => {
  const { controlStage } = useNavigation();

  const flowRender = [<StatePriority />, <HoursOfOperation/>,  <StateProficiency />, <History />, <Home /> ];

  const dataItems = [
    
    
    {
      nameItem: 'State Priority',
      icon: <MdQueue />,
      value: 0,
    },
    {
      nameItem: 'Hours of Operation',
      icon: <MdQueue />,
      value: 1,
    },
    {
      nameItem: 'Proficiency Upload',
      icon: <MdQueue />,
      value: 2,
    },
    {
      nameItem: 'History',
      icon: <MdHistory />,
      value: 3,
    },
  ];

  return (
    <ContainerRenderPages>
      <Navigation/>
      <NavigationDesktop dataItems={dataItems} />
      <NavigationMobile dataItems={dataItems} />
      {flowRender[controlStage.currentStage]}
    </ContainerRenderPages>
  );
};
