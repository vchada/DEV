import styled from 'styled-components';
import {motion} from 'framer-motion'

export const ContainerHome = styled(motion.div)`
  width: 100%;
  height: calc(100vh - 100px);
  min-height: 420px;
  padding: 1rem 1rem;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 2rem;

  table {
    border-collapse: collapse;
    thead {
      tr {
        th {
          min-width: 200px;
          &:nth-child(1) {
            min-width: 200px;
          }
          
          &:nth-child(4) {
            min-width: 320px;
          }

          &:nth-child(5) {
            min-width: 200px;
          }

          &:nth-child(6) {
            min-width: 100px;
          }

          &:nth-child(7) {
            min-width: 60px;
          }
        }
      }
    }
    tbody {
      tr {
        td {
          min-width: 120px;
          &:nth-child(1) {
            min-width: 200px;
          }
          &:nth-child(2) {
            min-width: 120px;
          }

          &:nth-child(4) {
            min-width: 300px;
          }

          &:nth-child(7) {
            min-width: 60px;
          }
        }
      }
    }
  }
`;
