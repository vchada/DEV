import { ContainerHome } from './styled';
// import { PanelFilter } from './PanelFilter';
import { TablePrompts } from './TablePrompts/TablePrompts';
import { DialogComponent } from '../../components/DialogComponent/DialogComponent';
import { EditRowComponent } from './EditRowComponent/EditRowComponent';
import { useHomePrompt } from '../../context/Home/useHomePrompt';

export const Home = () => {
  const { dataDialog } = useHomePrompt();
  const { dialogEditPrompt, setDialogEditPrompt } = dataDialog;

  // const closeDialog = () => {
  //   setDialogEditPrompt(false);
  // };

  const openDialog = () => {
    setDialogEditPrompt(true);
  };

  return (
    <ContainerHome initial={{opacity: 0}} animate={{opacity: 1}}>
      {/* <PanelFilter /> */}
      <TablePrompts openDialog={openDialog} />
      <DialogComponent open={dialogEditPrompt}>
        <EditRowComponent />
      </DialogComponent>
    </ContainerHome>
  );
};
