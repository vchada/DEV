import { useCallback, useMemo } from 'react';
import { Button } from '@mui/material';
import * as Icons from '../../../components/Icons/Icons';

import { ContentCopy } from './styled';
import { successToast } from '../../../components/Toast/Toast';
import { useHomeLists } from '../../../hooks/useHomeLists';
import { useHomePrompt } from '../../../context/Home/useHomePrompt';
import { MaterialReactTable, MRT_ColumnDef, useMaterialReactTable } from 'material-react-table';
import { LoadingComponent } from '../../../components/LoadingComponent/LoadingComponent';

interface TablePromptsProps {
  openDialog: () => void;
}
interface dataEditProps {
  item_id: string;
  collection_key: string;
  language_code: string;
  item_content: string;
  contact_flow_name: string;
  item_type: string;
}

export const TablePrompts = ({ openDialog }: TablePromptsProps) => {
  const { dataSelected, filteredPrompts } = useHomePrompt();
  const { loadingHomePromptsList, loadingUserList } = useHomeLists();

  const handleEdit = useCallback(
    (dataEdit: dataEditProps) => {
      dataSelected.setSelectedItemPrompt(dataEdit);
      openDialog();
    },
    [openDialog, dataSelected],
  );
  const handleCopy = (text: string) => {
    if (!navigator.clipboard || !text) {
      return;
    }
    navigator.clipboard.writeText(text);
    successToast('Text copied to clipboard');
  };

  const validatePrompt = (dataString: string) => {
    if (dataString) {
      const newString = dataString.replace(/<\/?speak>/g, '');
      return newString.substring(0, 40);
    }
    return '';
  };

  const checkILanguageCode = (dataType: any) => {
    return dataType
  }

  const columns = useMemo<MRT_ColumnDef<any>[]>(
    () => [
      {
        header: 'Item ID',
        accessorKey: 'item_id',
        Cell: ({ row }) => row.original.item_id ?? '-',
        muiFilterTextFieldProps: {
          id: 'itemId', onMouseDown: () => {
          }
        }
      },
      {
        header: 'Collection key',
        accessorKey: 'collection_key',
        Cell: ({ row }) => row.original.collection_key ?? '-'
      },
      {
        header: 'Language code',
        accessorKey: 'language_code',
        Cell: ({ row }) => row.original.language_code ? checkILanguageCode(row.original.language_code) : '-'
      },
      {
        header: 'Prompt',
        accessorKey: 'item_content',
        Cell: ({ row }) => (
          <ContentCopy title={row.original.item_content}>
            {validatePrompt(row?.original?.item_content ?? '-')}
            <Button
              aria-label="copy text"
              onClick={() => {
                handleCopy(row?.original?.item_content ?? '-');
              }}
            >
            </Button>
          </ContentCopy>
        ),
      },
      {
        header: 'Contact flow name',
        accessorKey: 'contact_flow_name',
        Cell: ({ row }) => row.original.contact_flow_name ?? '-'
      },
      {
        header: 'Item type',
        accessorKey: 'item_type',
        Cell: ({ row }) => row.original.item_type ?? '-'
      },
      {
        header: 'Actions',
        // accessorKey: '',
        id: 'actions',
        Cell: ({ row }) => (
          <div className="editTable">
            <Button
              onClick={() => handleEdit(row.original)}
              aria-label="Edit Button"
              title={row.original}
            >
              <Icons.EditIcon />
            </Button>
          </div>
        ),
      },
    ],
    [handleEdit],
  );

  const table = useMaterialReactTable({
    columns: columns,
    data: filteredPrompts,
    muiPaginationProps: {
      rowsPerPageOptions: [{ value: 10, label: '10' }, { value: 20, label: '20' }, { value: 50, label: '50' }, { value: 100, label: '100' }, { value: filteredPrompts.length, label: 'All' }],
    },
    autoResetPageIndex: false,
    enableDensityToggle: true,
    columnFilterDisplayMode: 'subheader',
    // muiFilterTextFieldProps = {{
    //   sx: { width: '100%' },
    //   variant: 'outlined',
    // }}
    enableStickyHeader: true,
    muiTableContainerProps: { sx: { height: '600px' } },

    initialState: { density: 'comfortable', pagination: { pageIndex: 0, pageSize: 20, } },
    enableFullScreenToggle: false,
    muiTablePaperProps: {
      elevation: 0,
    },

  })


  return (
    <>
      {(loadingHomePromptsList || loadingUserList) && <LoadingComponent />}
      <MaterialReactTable table={table} />
    </>
  );
  
};
