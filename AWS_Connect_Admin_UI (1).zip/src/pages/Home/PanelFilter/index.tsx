import { MenuItem } from '@mui/material';

import { PanelFilterData } from './styled';
import { SelectComponent } from '../../../components/SelectComponent/SelectComponent';
import { useHomePrompt } from '../../../context/Home/useHomePrompt';
import { ChangeEvent } from 'react';

export const PanelFilter = () => {
  const { dataFilters, dataOptions } = useHomePrompt();

  const { filterCollectionId, filterItemId, setFilterCollectionId, setFilterItemId } =
    dataFilters;

  const { optionsItemId, optionsCollections } = dataOptions;

  return (
    <PanelFilterData>
      <SelectComponent
        labelSelect={'Filter Item ID'}
        aria-label={'Filter Item ID'}
        value={filterItemId}
        onChange={(event: ChangeEvent<HTMLSelectElement>) =>
          setFilterItemId(event.target.value)
        }
      >
        <MenuItem value={'0'}>Select All</MenuItem>
        {optionsItemId.map((item: string, index: number) => (
          <MenuItem key={index} value={item}>
            {item}
          </MenuItem>
        ))}
      </SelectComponent>

      <SelectComponent
        labelSelect={'Filter Collection'}
        aria-label={'Filter Collection'}
        value={filterCollectionId}
        onChange={(event: ChangeEvent<HTMLSelectElement>) =>
          setFilterCollectionId(event.target.value)
        }
      >
        <MenuItem value={'0'}>Select all</MenuItem>
        {optionsCollections.map((item: string, index: number) => (
          <MenuItem key={index} value={item}>
            {item}
          </MenuItem>
        ))}
      </SelectComponent>
    </PanelFilterData>
  );
};
