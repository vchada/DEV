import { useState, useEffect, ChangeEvent, FormEvent } from 'react';
import { ContentFormUpdate, FooterDialog } from './styled';
import { Button, Stack } from '@mui/material';
import { errorToast } from '../../../../components/Toast/Toast';
import { InputComponent } from '../../../../components/InputComponent';
import { useHomePrompt } from '../../../../context/Home/useHomePrompt';

interface UpdatePromptProps {
  itemPrompt: {
    itemPrompt: string;
    setItemPrompt: (item: string) => void;
  };
  errorPrompt: {
    errorPrompt: boolean;
    setErrorPrompt: (state: boolean) => void;
  };
  changeStage: () => void;
}

export const UpdatePrompt = ({
  itemPrompt,
  errorPrompt,
  changeStage,
}: UpdatePromptProps) => {
  const { dataDialog } = useHomePrompt();

  const closeDialog = () => dataDialog.setDialogEditPrompt(false);

  const [hasPromptRegex, setHasPromptRegex] = useState(false);
  const [promptRender, setPromptRender] = useState('');

  useEffect(() => {
    if (errorPrompt && promptRender.length > 0) {
      errorPrompt.setErrorPrompt(false);
    }
  }, [promptRender, errorPrompt]);

  useEffect(() => {
    if (itemPrompt.itemPrompt) {
      const regexPrompt = /<\/?speak>/g;
      const hasRegex = regexPrompt.test(itemPrompt.itemPrompt);
      if (!hasRegex) {
        return setPromptRender(itemPrompt.itemPrompt);
      }
      setHasPromptRegex(true);
      const newString = itemPrompt.itemPrompt.replace(regexPrompt, '');
      setPromptRender(newString);
    }
  }, [itemPrompt, errorPrompt]);

  const handleUpdateItem = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (promptRender === '') {
      errorPrompt.setErrorPrompt(true);
      return errorToast('Field cannot be empty');
    }

    if (!itemPrompt.itemPrompt) {
      errorPrompt.setErrorPrompt(true);
      return;
    }

    if (!hasPromptRegex) {
      itemPrompt.setItemPrompt(promptRender);
    }

    const addSpeakCodeString = `<speak>${promptRender}</speak>`;

    itemPrompt.setItemPrompt(addSpeakCodeString);
    changeStage();
  };

  return (
    <ContentFormUpdate onSubmit={handleUpdateItem}>
      <InputComponent
        label={'Prompt Edit'}
        fullWidth
        multiline
        rows={6}
        value={promptRender}
        onChange={(e: ChangeEvent<HTMLInputElement>) => setPromptRender(e.target.value)}
        error={errorPrompt.errorPrompt}
        helperText={
          errorPrompt.errorPrompt || promptRender.length === 0
            ? 'Prompt is required'
            : ' '
        }
      />
      <FooterDialog>
        <Stack spacing={1} direction={'row'}>
          <Button variant="contained" color="warning" onClick={closeDialog}>
            Cancel
          </Button>
          <Button
            variant="contained"
            color="primary"
            type="submit"
            disabled={promptRender.length === 0}
          >
            Update
          </Button>
        </Stack>
      </FooterDialog>
    </ContentFormUpdate>
  );
};
