import { Button, Stack } from '@mui/material';
import { ConfirmationUpdateContent, FooterConfirmation } from './styled';

interface ConfirmationProps {
  hasError: boolean;
  handleUpdate: () => void;
  changeStage: () => void;
}

export const ConfirmationUpdate = ({
  hasError,
  handleUpdate,
  changeStage,
}: ConfirmationProps) => {
  const handleUpdateRow = () => {
    handleUpdate();
    return;
  };

  return (
    <ConfirmationUpdateContent>
      <p>
        Are you sure? <br /> This will change the prompt in production.
      </p>

      <FooterConfirmation>
        <Stack spacing={1} direction={'row'} justifyContent={'flex-end'}>
          <Button variant="contained" color="warning" onClick={changeStage}>
            Cancel
          </Button>
          <Button
            variant="contained"
            type="button"
            onClick={handleUpdateRow}
            disabled={hasError}
          >
            Confirm
          </Button>
        </Stack>
      </FooterConfirmation>
    </ConfirmationUpdateContent>
  );
};
