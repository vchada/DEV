import styled from 'styled-components';

export const ContainerEditRow = styled.div`
  min-width: 600px;
  padding: 2rem;
  display: flex;
  flex-direction: column;
  gap: 2rem;
`;

export const HeaderDialog = styled.header`
  width: 100%;
  height: 3rem;
  display: flex;
  justify-content: flex-start;
  gap: 0.75rem;
  align-items: center;
  h1 {
    font-size: 1.2rem;
    color: var(--black200);
    margin-bottom: 0;
  }
  svg {
    font-size: 1.2rem;
    color: var(--black200);
  }
`;

export const ContentDialog = styled.main``;

export const FormUpdate = styled.form`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

export const FooterDialog = styled.footer`
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 0.75rem;

  .btn-history {
    background-color: var(--gray-400);

    &:hover {
      background-color: var(--gray-400);
      opacity: 0.8;
    }
  }

  div {
    button {
      &:last-child {
        background-color: var(--blue-500);
      }

      &:disabled {
        background-color: var(--gray-100);
      }
    }
  }
`;
