import { useEffect, useState } from 'react';
import { MdEdit } from 'react-icons/md';

import { ContainerEditRow, ContentDialog, HeaderDialog } from './styled';
import { UpdatePrompt } from './UpdatePrompt/UpdatePrompt';
import { ConfirmationUpdate } from './ConfirmationUpdate/ConfirmationUpdate';
import { LoadingComponent } from '../../../components/LoadingComponent/LoadingComponent';
import { useHomePrompt } from '../../../context/Home/useHomePrompt';
import { useHomeLists } from '../../../hooks/useHomeLists';
import { errorToast, successToast } from '../../../components/Toast/Toast';

export const EditRowComponent = () => {
  const { dataDialog, dataSelected } = useHomePrompt();
  const { loadingUpdatePrompt, mutateUpdatePrompt } = useHomeLists();
  const [stageRenderEditPrompt, setStageRenderEditPrompt] = useState<number>(0);
  const [itemPrompt, setItemPrompt] = useState<string>('');
  const [errorPrompt, setErrorPrompt] = useState<boolean>(false);

  const selectedItem = dataSelected.selectedItemPrompt;

  useEffect(() => {
    setItemPrompt(dataSelected?.selectedItemPrompt?.item_content ?? '');
  }, [dataSelected]);

  const handleUpdateItem = async () => {
    const dataUpdate = {
      method: 'UPDATE_PROMPTS',
      user: 'USER TEST',
      dataUpdate: {
        item_id: selectedItem?.item_id ?? '',
        collection_key: selectedItem?.collection_key ?? '',
        newPrompt: itemPrompt,
        previousPrompt: selectedItem?.item_content ?? '',
      },
    };

    return await mutateUpdatePrompt(dataUpdate, {
      onSuccess: () => {
        successToast('success updating prompt');
        dataSelected.setSelectedItemPrompt(null);
        dataDialog.setDialogEditPrompt(false);
      },
      onError: (): any => {
        setStageRenderEditPrompt(0);
        return errorToast('Error updating item');
      },
    });
  };

  const flowStates = [
    <UpdatePrompt
      itemPrompt={{ itemPrompt, setItemPrompt }}
      errorPrompt={{ errorPrompt, setErrorPrompt }}
      changeStage={() => setStageRenderEditPrompt(1)}
    />,
    <ConfirmationUpdate
      handleUpdate={() => handleUpdateItem()}
      hasError={errorPrompt || itemPrompt.length === 0}
      changeStage={() => setStageRenderEditPrompt(0)}
    />,
  ];

  return (
    <ContainerEditRow>
      <HeaderDialog>
        <MdEdit />
        <h1>Edit Prompt</h1>
      </HeaderDialog>
      {loadingUpdatePrompt && <LoadingComponent />}
      <ContentDialog>{flowStates[stageRenderEditPrompt]}</ContentDialog>
    </ContainerEditRow>
  );
};
