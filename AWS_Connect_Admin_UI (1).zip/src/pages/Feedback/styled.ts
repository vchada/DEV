import styled from 'styled-components';
import {motion} from 'framer-motion'

export const FeedbackContainer = styled(motion.div)`
  
  .selected-feedback-type {
        background: #8e8e93;
    color: white;
    border-radius: 4px;
  }

  .success-banner {
      background: #5ee65e75;
      padding: 10px;
      margin-top: 12px;
      border-radius: 4px;
      border-left: 4px Solid green;
    }

    .error-banner {
      background: #e6635e75;
      padding: 10px;
      margin-top: 12px;
      border-radius: 4px;
      border-left: 4px Solid red;
    }

    .close {
    float: right;
    }
`;
