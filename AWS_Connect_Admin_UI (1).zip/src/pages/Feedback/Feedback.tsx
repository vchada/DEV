import { useContext, useState } from 'react';
import { InputComponent } from '../../components/InputComponent';
import { Navigation } from '../../components/Navigation/Navigation';
import { FeedbackContainer } from './styled';
import { Button } from '@mui/material';
import { feedbackAPI } from '../../services/api';
import validator from 'validator';
import { UserInfoContext } from '../../context/UserInfoContext';
import { v4 as uuid } from 'uuid'


export const Feedback = () => {
  const [formData, setFormData] = useState({
    feedbackType: '',
    name: '',
    email: '',
    summary: '',
    feedback: '',
    username: '',
    id: ''
  });

  const userContext = useContext(UserInfoContext);

  const handleChange = (e: any) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({ ...prevState, [name]: value }));
  };

  const handleFeedbackTypeSelection = (value: string) => {
    setFormData((prevState) => ({ ...prevState, ['feedbackType']: value }));
  };

  const onSubmit = () => {
    if (validator.isEmail(formData.email)) {
      setEmailError('');
      formData.username = userContext.email;
      formData.id = uuid();
      const payload = formData;
      feedbackAPI
        .post('/', payload)
        .then((res) => {
          if (res) {
            setSuccessMsg('Your response saved successfully.');

            setTimeout(() => {
              setSuccessMsg('');
            }, 5000);

            onReset();
          }
        })
        .catch(() => {
          setErrorMsg('There is some issue. Please try again.');
        });
    } else {
      setEmailError('Please enter valid email address.');
    }
  };

  const onReset = () => {
    setFormData({
      feedbackType: '',
      name: '',
      email: '',
      summary: '',
      feedback: '',
      username: userContext.email,
      id : ''
    });
  };

  const [emailError, setEmailError] = useState('');

  const handleEmailChange = (e: any) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({ ...prevState, [name]: value }));
    setEmailError('');
  };

  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const closeBanner = () => {
    setSuccessMsg('');
    setErrorMsg('');
  };

  return (
    <FeedbackContainer initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <Navigation />
      <div style={{ width: '100%', padding: '10px 20%' }}>
        <div>
          <h1 style={{fontSize: '36px'}}>Feedback</h1>
          <h6 style={{ marginTop: '8px' }}>
            We value your thoughts, any kind of feedback is appreciated.
          </h6>
        </div>

        {successMsg && (
          <div className="success-banner">
            {successMsg}{' '}
            <a onClick={closeBanner} className="close">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                fill="currentColor"
                className="bi bi-x-lg"
                viewBox="0 0 16 16"
              >
                <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8z" />
              </svg>
            </a>
          </div>
        )}

        {errorMsg && (
          <div className="error-banner">
            {errorMsg}{' '}
            <a onClick={closeBanner} className="close">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                fill="currentColor"
                className="bi bi-x-lg"
                viewBox="0 0 16 16"
              >
                <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8z" />
              </svg>
            </a>
          </div>
        )}

        <div style={{ marginTop: '16px' }}>
          <label>
            Select Feedback Type<span style={{ color: 'red' }}>*</span>
          </label>
          <div style={{ display: 'inline-flex', width: '100%', margin: '20px 0' }}>
            <a
              
              style={{ width: '100%', textAlign: 'center', padding: '10px 0', lineHeight: '36px' }}
              onClick={() => handleFeedbackTypeSelection('IDEA')}
              className={formData.feedbackType === 'IDEA' ? 'selected-feedback-type' : ''}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                style={{ display: 'inline' }}
                width="16"
                height="16"
                fill="currentColor"
                className="bi bi-lightbulb-fill"
                viewBox="0 0 16 16"
              >
                <path d="M2 6a6 6 0 1 1 10.174 4.31c-.203.196-.359.4-.453.619l-.762 1.769A.5.5 0 0 1 10.5 13h-5a.5.5 0 0 1-.46-.302l-.761-1.77a2 2 0 0 0-.453-.618A5.98 5.98 0 0 1 2 6m3 8.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1l-.224.447a1 1 0 0 1-.894.553H6.618a1 1 0 0 1-.894-.553L5.5 15a.5.5 0 0 1-.5-.5" />
              </svg>{' '}
              Idea
            </a>
            <a
              
              style={{ width: '100%', textAlign: 'center', padding: '10px 0', lineHeight: '36px' }}
              onClick={() => handleFeedbackTypeSelection('QUESTION')}
              className={
                formData.feedbackType === 'QUESTION' ? 'selected-feedback-type' : ''
              }
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                style={{ display: 'inline' }}
                width="16"
                height="16"
                fill="currentColor"
                className="bi bi-question-circle-fill"
                viewBox="0 0 16 16"
              >
                <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0M5.496 6.033h.825c.138 0 .248-.113.266-.25.09-.656.54-1.134 1.342-1.134.686 0 1.314.343 1.314 1.168 0 .635-.374.927-.965 1.371-.673.489-1.206 1.06-1.168 1.987l.003.217a.25.25 0 0 0 .25.246h.811a.25.25 0 0 0 .25-.25v-.105c0-.718.273-.927 1.01-1.486.609-.463 1.244-.977 1.244-2.056 0-1.511-1.276-2.241-2.673-2.241-1.267 0-2.655.59-2.75 2.286a.237.237 0 0 0 .241.247m2.325 6.443c.61 0 1.029-.394 1.029-.927 0-.552-.42-.94-1.029-.94-.584 0-1.009.388-1.009.94 0 .533.425.927 1.01.927z" />
              </svg>{' '}
              Question
            </a>
            <a
              
              style={{ width: '100%', textAlign: 'center', padding: '10px 0', lineHeight: '36px' }}
              onClick={() => handleFeedbackTypeSelection('PROBLEM')}
              className={
                formData.feedbackType === 'PROBLEM' ? 'selected-feedback-type' : ''
              }
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                style={{ display: 'inline' }}
                width="16"
                height="16"
                fill="currentColor"
                className="bi bi-info-circle-fill"
                viewBox="0 0 16 16"
              >
                <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16m.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2" />
              </svg>{' '}
              Problem
            </a>
            <a
              
              style={{ width: '100%', textAlign: 'center', padding: '10px 0', lineHeight: '36px' }}
              onClick={() => handleFeedbackTypeSelection('PRAISE')}
              className={
                formData.feedbackType === 'PRAISE' ? 'selected-feedback-type' : ''
              }
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                style={{ display: 'inline' }}
                width="16"
                height="16"
                fill="currentColor"
                className="bi bi-heart-fill"
                viewBox="0 0 16 16"
              >
                <path
                  fillRule="evenodd"
                  d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314"
                />
              </svg>{' '}
              Praise
            </a>
          </div>
        </div>

        <div style={{ marginTop: '8px' }}>
          <label htmlFor="name">
            Name<span style={{ color: 'red' }}>*</span>
          </label>
          <InputComponent
            fullWidth
            placeholder={''}
            style={{ width: '100%' }}
            name="name"
            value={formData.name}
            onChange={handleChange}
          ></InputComponent>
        </div>
        <div style={{ marginTop: '8px' }}>
          <label htmlFor="email">
            Email<span style={{ color: 'red' }}>*</span>
          </label>
          <InputComponent
            fullWidth
            placeholder={''}
            style={{ width: '100%' }}
            name="email"
            value={formData.email}
            onChange={handleEmailChange}
          ></InputComponent>
          <span style={{ color: 'red', fontSize: '14px' }}>{emailError}</span>
        </div>
        <div style={{ marginTop: '8px' }}>
          <label htmlFor="summary">
            Summary<span style={{ color: 'red' }}>*</span>
          </label>
          <InputComponent
            fullWidth
            placeholder={''}
            style={{ width: '100%' }}
            name="summary"
            value={formData.summary}
            onChange={handleChange}
          ></InputComponent>
        </div>
        <div style={{ marginTop: '8px' }}>
          <label htmlFor="feedback">Feedback</label>
          <InputComponent
            fullWidth
            multiline
            rows={3}
            value={formData.feedback}
            onChange={handleChange}
            name="feedback"
            helperText={'Available Characters: ' + (200 - formData.feedback?.length)}
          />
        </div>

        <div style={{ margin: '20px 0' }}>
          <Button
            variant="contained"
            color="primary"
            type="button"
            aria-haspopup="true"
            onClick={onSubmit}
            disabled={
              !formData.feedbackType ||
              !formData.name ||
              !formData.email ||
              !formData.summary
            }
          >
            <span>Submit</span>
          </Button>

          <Button id="primary-button" aria-haspopup="true" onClick={onReset}>
            <span>Reset</span>
          </Button>
        </div>
      </div>
    </FeedbackContainer>
  );
};
