import { FooterDialog } from './styled';
import { Button, Stack } from '@mui/material';
import { ContentFormUpdate } from './styled';
import { HOOClosedPeriodsInfoCard } from '../HOOEditDialog/HOOClosedPeriodsInfoCard/HOOClosedPeriodsInfoCard';


export const DeleteHOO = ({ dataDialog, selectedHOORows, setShowConfirmationDialog }: any) => {



    const closeDialog = () => dataDialog.setDialogDeleteHOO(false);




    return (
        <ContentFormUpdate >

            <div>
                {selectedHOORows.map((row: any, index: any) => {

                    return (<HOOClosedPeriodsInfoCard key={index} row={row.original} />)

                })}
            </div>

            <FooterDialog>
                <Stack spacing={1} direction={'row'}>
                    <Button style={{ 'color': '#2196F3', 'fontWeight': '550' }} onClick={closeDialog}>
                        Close
                    </Button>
                    <Button style={{ 'color': '#2196F3', 'fontWeight': '550' }} onClick={() => setShowConfirmationDialog(true)}
                    >
                        Delete
                    </Button>
                </Stack>
            </FooterDialog>
        </ContentFormUpdate >
    );
};
