import { useContext, useState } from 'react';
import { ContainerEditRow, ContentDialog, HeaderDialog } from './styled';
import { successToast, errorToast } from '../../../../components/Toast/Toast';
import { useHOOLists } from '../../../../hooks/useHOOList';

import { DeleteHOO } from './DeleteHOO';
import { ConfirmationDialog } from '../../../../components/ConfirmationDialog/ConfirmationDialog';
import { CustomDialogComponent } from '../../../../components/DialogComponent/CustomDialogComponent';
import { UserInfoContext } from '../../../../context/UserInfoContext';


interface dataUpdateProps {
    name: string;
    loginId: string;
    payload: any

}

export const HOODeleteDialog = ({ context }: any) => {
    const { dataDialog, selectedHOORows, originalDataStructure, setLoadingData } = context;
    const { mutateUpdateHOO } = useHOOLists();
    const userContext = useContext(UserInfoContext);
    const [stageRenderEditPrompt, setStageRenderEditPrompt] = useState<number>(0);
    const [errorPrompt, setErrorPrompt] = useState<boolean>(false);
    const [showConfirmationDialog, setShowConfirmationDialog] = useState<boolean>(false);

    const handleDeleteHOO = async () => {
        const deletedQueues: any[] = [];
        const tempMap = new Map();
        selectedHOORows.map((item: any) => {
            let obj = originalDataStructure.get(item.original.CustomHOODeterminatorType + '' + item.original.CustomHOODeterminatorSubType)

            if (tempMap.has(item.original.CustomHOODeterminatorType + '' + item.original.CustomHOODeterminatorSubType)) {
                obj = tempMap.get(item.original.CustomHOODeterminatorType + '' + item.original.CustomHOODeterminatorSubType)
            }

            switch (item.original.CustomHOODeterminatorSubType) {

                case 'Federal':{
                    const federalClosedDetailArray = obj.CustomHOO.Federal[item.original.secondLevelIndex].ClosedPeriod.Details.filter((detail : any) => {
                        return detail.id != item.original.Id
                    });
                    obj.CustomHOO.Federal[item.original.secondLevelIndex].ClosedPeriod.Details = federalClosedDetailArray;
                    let federalArray = obj.CustomHOO.Federal;
                    if(federalClosedDetailArray.length == 0){
                        federalArray = obj.CustomHOO.Federal.filter((federal : any) => {
                            return federal.Name != obj.CustomHOO.Federal[item.original.secondLevelIndex].Name
                        });
                        
                    

                    if(federalArray.length == 0){
                        deletedQueues.push(obj.CustomHOODeterminatorType)
                    }   
                    }
                    obj.CustomHOO.Federal = federalArray;

                    tempMap.set(item.original.CustomHOODeterminatorType + '' + item.original.CustomHOODeterminatorSubType, obj)
                    break;
                }
                case 'State':{
                    const stateArrayClosedDetailArray = obj.CustomHOO.State[item.original.secondLevelIndex].ClosedPeriod.Details.filter((detail : any) => {
                        return detail.id != item.original.Id
                    });
                    obj.CustomHOO.State[item.original.secondLevelIndex].ClosedPeriod.Details = stateArrayClosedDetailArray;
                    let stateArray = obj.CustomHOO.State;
                    if(stateArrayClosedDetailArray.length == 0){
                        stateArray = obj.CustomHOO.State.filter((state : any) => {
                            return state.Name != obj.CustomHOO.State[item.original.secondLevelIndex].Name
                        });
                        
                    

                    if(stateArray.length == 0){
                        deletedQueues.push(obj.CustomHOODeterminatorType)
                    }   
                    }
                    obj.CustomHOO.State = stateArray;
                    tempMap.set(item.original.CustomHOODeterminatorType + '' + item.original.CustomHOODeterminatorSubType, obj)
                    break;
                }
                case 'Adhoc':{
                    const adhocArrayClosedDetailArray = obj.CustomHOO.Adhoc[item.original.secondLevelIndex].ClosedPeriod.Details.filter((detail : any) => {
                        return detail.id != item.original.Id
                    });
                    obj.CustomHOO.Adhoc[item.original.secondLevelIndex].ClosedPeriod.Details = adhocArrayClosedDetailArray;
                    let adhocArray = obj.CustomHOO.Adhoc;
                    if(adhocArrayClosedDetailArray.length == 0){
                        adhocArray = obj.CustomHOO.Adhoc.filter((adhoc : any) => {
                            return adhoc.Name != obj.CustomHOO.Adhoc[item.original.secondLevelIndex].Name
                        });
                        
                    

                    if(adhocArray.length == 0){
                        deletedQueues.push(obj.CustomHOODeterminatorType)
                    }   
                    }
                    obj.CustomHOO.State = adhocArray;
                    tempMap.set(item.original.CustomHOODeterminatorType + '' + item.original.CustomHOODeterminatorSubType, obj)
                    break;
                }
                default:
                    break;
            }
            

        });


        const payload = Array.from(tempMap.values())
        console.log('deletedQueues', deletedQueues)
        console.log('payload', payload)

        const dataUpdate: dataUpdateProps = {
            name: userContext.name,
            loginId: userContext.email,
            payload: payload,
        };

        return await mutateUpdateHOO(dataUpdate, {
            onSuccess: () => {
                successToast('Success deleting closed period(s)');
                setShowConfirmationDialog(false)
                dataDialog.setDialogDeleteHOO(false);
                setLoadingData(true);

            },
            onError: (): any => {
                setStageRenderEditPrompt(0);
                return errorToast('Error updating item');
            },
        });
    };

    const flowStates = [
        <DeleteHOO
            context={context}
            dataDialog={dataDialog}
            errorPrompt={{ errorPrompt, setErrorPrompt }}
            handleDeleteHOO={handleDeleteHOO}
            setShowConfirmationDialog={setShowConfirmationDialog}
            selectedHOORows={selectedHOORows}

        />,
    ];

    return (
        <ContainerEditRow>
            <HeaderDialog>
                <h2>Delete {selectedHOORows.length} {context.selectedSubType} Operation Period(s)</h2>
            </HeaderDialog>
            <ContentDialog>{flowStates[stageRenderEditPrompt]}</ContentDialog>
            <CustomDialogComponent open={showConfirmationDialog} fullWidth={true} size="sm" >
                <ConfirmationDialog setShowConfirmationDialog={setShowConfirmationDialog} handleAction={handleDeleteHOO} header={'Confirm Delete'} message={'Are you sure you want to delete these closed periods of operation?'} />
            </CustomDialogComponent>
        </ContainerEditRow>
        
    );
};
