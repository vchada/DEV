import { useContext, useState } from 'react';
import { ContainerEditRow, ContentDialog, HeaderDialog } from './styled';
import { successToast, errorToast } from '../../../../components/Toast/Toast';
import { useHOOLists } from '../../../../hooks/useHOOList';
import { EditHOO } from './EditHOO';
import './EditHOO.css'
import { CustomDialogComponent } from '../../../../components/DialogComponent/CustomDialogComponent';
import { ConfirmationDialog } from '../../../../components/ConfirmationDialog/ConfirmationDialog';
import { UserInfoContext } from '../../../../context/UserInfoContext';

interface dataUpdateProps {
    loginId: string;
    name: string;
    payload: any

}




export const HOOEditDialog = ({ context }: any) => {
    const { dataDialog, selectedHOORows, originalDataStructure, setLoadingData, selectedSubType } = context;
    const { mutateUpdateHOO } = useHOOLists();
    const userContext = useContext(UserInfoContext);
    const [stageRenderEditPrompt, setStageRenderEditPrompt] = useState<number>(0);
    const [errorPrompt, setErrorPrompt] = useState<boolean>(false);
    const [dateValue, setDateValue] = useState<any>();
    const [dayValue, setDayValue] = useState<any>();
    const [startValue, setStartValue] = useState<any>('12:00 AM');
    const [endValue, setEndValue] = useState<any>('12:00 AM');

    const [timeZone, setTimeZone] = useState('EST');
    const [nextActionType, setNextActionType] = useState('VM');
    const [locationType, setLocationType] = useState('TTS');
    const [locationName, setLocationName] = useState('');
    const [locationKey, setLocationKey] = useState('');
    const [locationSubKey, setLocationSubKey] = useState('');
    const [locationValue, setLocationValue] = useState('');
    const [additionalDetails, setAdditionalDetails] = useState<any[]>([{ Name: '', Value: '', index: 0 }]);

    const [showConfirmationDialog, setShowConfirmationDialog] = useState<boolean>(false);




    const handleUpdateHOO = async () => {

        const tempMap = new Map();
        selectedHOORows.map((item: any) => {
            let obj = originalDataStructure.get(item.original.CustomHOODeterminatorType + '' + item.original.CustomHOODeterminatorSubType)

            if (tempMap.has(item.original.CustomHOODeterminatorType + '' + item.original.CustomHOODeterminatorSubType)) {
                obj = tempMap.get(item.original.CustomHOODeterminatorType + '' + item.original.CustomHOODeterminatorSubType)
            }

            switch (item.original.CustomHOODeterminatorSubType) {

                case 'Federal':
                    obj.CustomHOO.Federal[item.original.secondLevelIndex].ClosedPeriod.Details[item.original.thirdLevelIndex].Date = dateValue;
                    obj.CustomHOO.Federal[item.original.secondLevelIndex].ClosedPeriod.Details[item.original.thirdLevelIndex].Day = dayValue;
                    obj.CustomHOO.Federal[item.original.secondLevelIndex].ClosedPeriod.Details[item.original.thirdLevelIndex].Hours.Start = startValue;
                    obj.CustomHOO.Federal[item.original.secondLevelIndex].ClosedPeriod.Details[item.original.thirdLevelIndex].Hours.End = endValue;
                    obj.CustomHOO.Federal[item.original.secondLevelIndex].ClosedPeriod.Details[item.original.thirdLevelIndex].TimeZone = timeZone;
                    tempMap.set(item.original.CustomHOODeterminatorType + '' + item.original.CustomHOODeterminatorSubType, obj)
                    break;
                case 'State':
                    obj.CustomHOO.State[item.original.secondLevelIndex].ClosedPeriod.Details[item.original.thirdLevelIndex].Day = dayValue;
                    obj.CustomHOO.State[item.original.secondLevelIndex].ClosedPeriod.Details[item.original.thirdLevelIndex].Hours.Start = startValue;
                    obj.CustomHOO.State[item.original.secondLevelIndex].ClosedPeriod.Details[item.original.thirdLevelIndex].Hours.End = endValue;
                    obj.CustomHOO.State[item.original.secondLevelIndex].ClosedPeriod.Details[item.original.thirdLevelIndex].TimeZone = timeZone;
                    tempMap.set(item.original.CustomHOODeterminatorType + '' + item.original.CustomHOODeterminatorSubType, obj)
                    break;
                case 'Adhoc':
                    obj.CustomHOO.Adhoc[item.original.secondLevelIndex].ClosedPeriod.Details[item.original.thirdLevelIndex].Date = dateValue;
                    obj.CustomHOO.Adhoc[item.original.secondLevelIndex].ClosedPeriod.Details[item.original.thirdLevelIndex].Day = dayValue;
                    obj.CustomHOO.Adhoc[item.original.secondLevelIndex].ClosedPeriod.Details[item.original.thirdLevelIndex].Hours.Start = startValue;
                    obj.CustomHOO.Adhoc[item.original.secondLevelIndex].ClosedPeriod.Details[item.original.thirdLevelIndex].Hours.End = endValue;
                    obj.CustomHOO.Adhoc[item.original.secondLevelIndex].ClosedPeriod.Details[item.original.thirdLevelIndex].TimeZone = timeZone;
                    tempMap.set(item.original.CustomHOODeterminatorType + '' + item.original.CustomHOODeterminatorSubType, obj)
                    break;
                default:
                    break;
            }

        });
        const payload = Array.from(tempMap.values())
        // console.log('payload', payload)

        const dataUpdate: dataUpdateProps = {
            loginId: userContext.email,
            name: userContext.name,
            payload: payload,
        };

        return await mutateUpdateHOO(dataUpdate, {
            onSuccess: () => {
                successToast('Success updating closed period(s)');
                dataDialog.setDialogViewEditHOO(false);
                setShowConfirmationDialog(false)
                setLoadingData(true);


            },
            onError: (): any => {
                setStageRenderEditPrompt(0);
                return errorToast('Error updating closed `period(s)');
            },
        });
    };

    const flowStates = [
        <EditHOO
            context={context}
            dataDialog={dataDialog}
            errorPrompt={{ errorPrompt, setErrorPrompt }}
            dateValue={dateValue}
            dayValue={dayValue}
            startValue={startValue}
            endValue={endValue}
            setDateValue={setDateValue}
            setDayValue={setDayValue}
            setStartValue={setStartValue}
            setEndValue={setEndValue}
            setShowConfirmationDialog={setShowConfirmationDialog}
            selectedSubType={selectedSubType}
            timeZone={timeZone}
            setTimeZone={setTimeZone}
            nextActionType={nextActionType}
            setNextActionType={setNextActionType}
            locationType={locationType}
            setLocationType={setLocationType}
            locationName={locationName}
            setLocationName={setLocationName}
            locationKey={locationKey}
            setLocationKey={setLocationKey}
            locationSubKey={locationSubKey}
            setLocationSubKey={setLocationSubKey}
            locationValue={locationValue}
            setLocationValue={setLocationValue}
            additionalDetails={additionalDetails}
            setAdditionalDetails={setAdditionalDetails}
            selectedHOORows={selectedHOORows}
            handleUpdateHOO={handleUpdateHOO}
        />,
    ];

    return (
        <ContainerEditRow>
            <HeaderDialog>
                <h2>Edit {selectedHOORows.length} {selectedSubType} Operation Period(s)</h2>
            </HeaderDialog>
            <ContentDialog>{flowStates[stageRenderEditPrompt]}</ContentDialog>
            <CustomDialogComponent open={showConfirmationDialog} fullWidth={true} size="sm" >
                <ConfirmationDialog setShowConfirmationDialog={setShowConfirmationDialog} handleAction={handleUpdateHOO} header={'Confirm Edit'} message={'Are you sure you want to modify these closed periods of operation?'} />
            </CustomDialogComponent>
        </ContainerEditRow>

    );
};
