import './HOOClosedPeriodsInfoCard.css'

export const HOOClosedPeriodsInfoCard = ({ row }: any) => {

    return (<div className="container">

        {<div style={{ 'display': 'flex' }}>
            <p style={{ 'marginRight': '5px', 'fontWeight': '700' }}> Queue: </p><p id='name'>{row.CustomHOODeterminatorType}</p>

        </div>}

        {(row.CustomHOODeterminatorSubType == 'State' || row.CustomHOODeterminatorSubType == 'Adhoc') && <div style={{ 'display': 'flex' }}>
            <p style={{ 'marginRight': '5px', 'fontWeight': '700' }}> State:</p> <p id='name'>{row.Name}</p>

        </div>}

        {(row.CustomHOODeterminatorSubType == 'Federal') && <div style={{ 'display': 'flex' }}>
        <p style={{ 'marginRight': '5px', 'fontWeight': '700' }}> Holiday:</p> <p id='name'>{row.Name}</p>
        </div>}


        {/* {row.Date && <br />} */}
        <div style={{ 'display': 'flex', 'justifyContent': 'space-between' }}>
            {row.Date && <div style={{ 'display': 'flex', }}>
            <p style={{ 'marginRight': '5px', 'fontWeight': '700' }}> Date:</p> <p id='name'>{row.Date}</p>

            </div>}

        </div>
        {/* <br /> */}
        {row.Day && <div style={{ 'display': 'flex' }}>
        <p style={{ 'marginRight': '5px', 'fontWeight': '700' }}> Day:</p> <p id='name'>{row.Day}</p>

        </div>}
        {/* <br /> */}
        {<div style={{ 'display': 'flex' }}>
            <p  style={{ 'marginRight': '5px', 'fontWeight': '700' }}> Hours: </p><p id="hours">From {row.StartTime} to {row.EndTime} {row.TimeZone}</p>

        </div>}

    </div>);



}