import { FooterDialog } from './styled';
import { Button, Checkbox, FormControlLabel, Stack } from '@mui/material';
import { ContentFormUpdate } from './styled';
import { DatePicker, LocalizationProvider, TimePicker } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { useEffect, useState } from 'react';
import dayjs from 'dayjs';


const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']

const HOURS: Record<string, number> = {
    '12AM': 0, '01AM': 1, '02AM': 2, '03AM': 3, '04AM': 4, '05AM': 5, '06AM': 6,
    '07AM': 7, '08AM': 8, '09AM': 9, '10AM': 10, '11AM': 11, '12PM': 12, '01PM': 13,
    '02PM': 14, '03PM': 15, '04MM': 16, '05PM': 17, '06PM': 18, '07PM': 19, '08PM': 20,
    '09PM': 21, '10PM': 22, '11PM': 23,
    '1AM': 1, '2AM': 2, '3AM': 3, '4AM': 4, '5AM': 5, '6AM': 6,
    '7AM': 7, '8AM': 8, '9AM': 9, '1PM': 13,
    '2PM': 14, '3PM': 15, '4MM': 16, '5PM': 17, '6PM': 18, '7PM': 19, '8PM': 20,
    '9PM': 21
}

export const EditHOO = ({ dataDialog, selectedHOORows,
    dateValue, dayValue, startValue, endValue, setDateValue, setDayValue, setStartValue, setEndValue, setShowConfirmationDialog, selectedSubType }: any) => {

    const [allDayValue, setAllDayValue] = useState<boolean>(false);
    const closeDialog = () => dataDialog.setDialogViewEditHOO(false);

    // console.log('selectedHOORows', selectedHOORows)


    useEffect(() => {

        if (selectedHOORows.length == 1) {
            setDateValue(selectedHOORows[0].original.Date);
            setDayValue(selectedHOORows[0].original.Day);
            setStartValue(selectedHOORows[0].original.StartTime)
            setEndValue(selectedHOORows[0].original.EndTime)
        } else {
            setDayValue(DAYS[dayjs().day()]);
            setDateValue(dayjs().format('MM/DD/YYYY'));
            setStartValue('12:00 AM')
            setEndValue('12:00 AM')
        }
    }, []);


    const handleAllDaySelection = () => {
        if (!allDayValue) {
            setStartValue('12:00 AM')
            setEndValue('11:59 PM')
        }
        setAllDayValue(!allDayValue);

    }

    return (
        <ContentFormUpdate >

            <div className='dialog'>
                <div className='left-side'>
                    {/* Content for left side */}
                    <div>
                        <div style={{ 'marginBottom': '10px' }}><p style={{ 'fontSize': '14px', 'fontWeight': '800', 'font': 'Roboto', 'color': '#616161' }}>Closed Period(s)</p></div>
                        <div>
                            {selectedHOORows.map((row: any, index: any) => {

                                return (<p key={index} style={{ 'fontSize': '14px', 'marginBottom': '5px', 'fontWeight': '400', 'font': 'Roboto', 'color': '#616161' }}>
                                    {row.original.CustomHOODeterminatorType} - {row.original.Name} - {row.original.Day}  - {row.original.StartTime} to {row.original.EndTime} {row.original.TimeZone}

                                </p>)
                            })}
                        </div>
                    </div>
                    <br />

                </div>
                <div className='right-side'>
                    {/* Content for right side */}
                    <p style={{ 'fontSize': '14px', 'fontWeight': '400', 'font': 'Roboto', 'color': '#616161' }}>Make changes to all selected operational hours entries. All times are represented as Eastern Standard Time.</p>
                    <br />
                    <div style={{ 'display': 'flex', 'flexDirection': 'column', 'gap': '2rem', 'marginTop': '10px' }}>
                        {selectedSubType == 'Adhoc' && <div className='space-x-[10px]'>

                            {<LocalizationProvider dateAdapter={AdapterDayjs}>
                                <DatePicker value={dayjs(dateValue)} slotProps={{ textField: { size: 'small' } }} label="Select a Date"  onChange={(newValue): any => {
                                    if (newValue) {
                                        setDayValue(DAYS[newValue?.day()])
                                        setDateValue(newValue?.format('MM/DD/YYYY'))
                                    }
                                }} />
                            </LocalizationProvider>
                            }
                            {/* {<FormControlLabel label="Include Date?" control={<Checkbox defaultChecked onChange={handleIncludeDate} />} />} */}
                        </div>}
                        {/* {selectedSubType == 'Federal' && <div>
                            {<LocalizationProvider dateAdapter={AdapterDayjs}>
                                <DatePicker value={dayjs(dateValue)} slotProps={{ textField: { size: 'small' } }} label="Select a Date" onChange={(newValue): any => {
                                    if (newValue) {
                                        setDayValue(DAYS[newValue?.day()])
                                        setDateValue(newValue?.format('MM/DD/YYYY'))
                                    }
                                }} />
                            </LocalizationProvider>
                            }
                        </div>} */}


                        {(selectedSubType == 'State' || selectedSubType == 'Adhoc') &&

                            <div className='float-label-group'>
                                <select id="day" disabled={selectedSubType == 'Federal' || selectedSubType == 'Adhoc'} value={dayValue} style={{ 'width': '215px', 'height': '38px' }} onChange={(e: any) => {
                                    setDayValue(e.target.value)
                                }}>
                                    {DAYS.map((row: any) => {
                                        return (
                                            <option key={row} value={row}>{row}</option>
                                        );
                                    })}
                                </select>
                                <label className="float-label">Day of the Week</label>
                            </div>
                        }

                        {<FormControlLabel label="All Day" control={<Checkbox onChange={handleAllDaySelection} />} />}

                        <LocalizationProvider dateAdapter={AdapterDayjs}>
                            <TimePicker disabled={allDayValue} value={dayjs().hour(HOURS[startValue.split(' ')[0].split(':')[0] + startValue.split(' ')[1]]).minute(Number(startValue.split(' ')[0].split(':')[1]))} slotProps={{ textField: { size: 'small' } }} label="Closed From" onChange={(newValue): any => {
                                let hour = newValue?.hour();
                                let hourStr = ''
                                let timeOfDay = 'AM'
                                if (hour) {

                                    if (hour > 11) {
                                        timeOfDay = 'PM'
                                    }
                                    if (hour != 12) {
                                        hour = hour % 12;
                                    }

                                    hourStr = hour + '';

                                    if (hour < 10) {
                                        hourStr = '0' + hour
                                    }


                                } else if (hour == 0) {
                                    hour = 12
                                    hourStr = hour + '';

                                }
                                const tempMinute = newValue?.minute();
                                let minute = ''

                                if (tempMinute == 0) {
                                    minute = '00'
                                } else if (tempMinute && tempMinute < 10) {
                                    minute = '0' + tempMinute;
                                } else {
                                    minute = '' + tempMinute
                                }

                                const newString = hourStr + ':' + minute + ' ' + timeOfDay

                                setStartValue(newString)

                            }} />
                        </LocalizationProvider>

                        <LocalizationProvider dateAdapter={AdapterDayjs}>
                            <TimePicker disabled={allDayValue} value={dayjs().hour(HOURS[endValue.split(' ')[0].split(':')[0] + endValue.split(' ')[1]]).minute(Number(endValue.split(' ')[0].split(':')[1]))} slotProps={{ textField: { size: 'small' } }} label="Closed Until" onChange={(newValue): any => {
                                let hour = newValue?.hour();
                                let hourStr = ''
                                let timeOfDay = 'AM'
                                if (hour) {

                                    if (hour > 11) {
                                        timeOfDay = 'PM'
                                    }
                                    if (hour != 12) {
                                        hour = hour % 12;
                                    }

                                    hourStr = hour + '';

                                    if (hour < 10) {
                                        hourStr = '0' + hour
                                    }

                                } else if (hour == 0) {
                                    hour = 12
                                    hourStr = hour + '';

                                }
                                const tempMinute = newValue?.minute();
                                let minute = ''

                                if (tempMinute == 0) {
                                    minute = '00'
                                } else if (tempMinute && tempMinute < 10) {
                                    minute = '0' + tempMinute;
                                } else {
                                    minute = '' + tempMinute
                                }

                                const newString = hourStr + ':' + minute + ' ' + timeOfDay

                                setEndValue(newString);

                            }} />
                        </LocalizationProvider>
                        {selectedSubType == 'Federal' && selectedHOORows.length > 1  && <p className='font-bold'>{selectedHOORows[0].original.Date} {dayValue} From {startValue} to {endValue} EST</p>}
                        {selectedSubType == 'State' && <p className='font-bold'>{dayValue}s From {startValue} to {endValue} EST</p>}
                        {selectedSubType == 'Adhoc' && <p className='font-bold'>{dateValue} {dayValue} From {startValue} to {endValue} EST</p>}

                        {/* <select disabled id="timezone" style={{ 'width': '215px', 'height': '38px' }} defaultValue={'EST'}>
                            {timeZones.map((row: any, index: any) => {
                                return (
                                    <option key={row + index} value={row}>{row}</option>
                                );
                            })}
                        </select> */}
                    </div>
                </div>
            </div>




            <FooterDialog>
                <Stack spacing={1} direction={'row'}>
                    <Button style={{ 'color': '#2196F3', 'fontWeight': '550' }} onClick={closeDialog}>
                        Close
                    </Button>

                    {/* <Button style={{ 'color': '#2196F3', 'fontWeight': '550' }} onClick={() => handleUpdateHOO(dateValue, dayValue, startValue, endValue)}> */}
                    <Button style={{ 'color': '#2196F3', 'fontWeight': '550' }} onClick={() => setShowConfirmationDialog(true)}>
                        Save
                    </Button>
                </Stack>
            </FooterDialog>
        </ContentFormUpdate >
    );
};
