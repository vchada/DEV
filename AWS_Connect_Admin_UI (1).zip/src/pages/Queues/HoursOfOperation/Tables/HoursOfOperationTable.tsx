import { useEffect, useMemo, useState } from 'react';
import {
  MaterialReactTable,
  MRT_Row,
  useMaterialReactTable,
  type MRT_ColumnDef,
} from 'material-react-table';


import './Tables.css'
import { LoadingComponent } from '../../../../components/LoadingComponent/LoadingComponent';
import Toolbar from '../../../../components/Toolbar/Toolbar';
import { getHoursOfOperation } from '../../../../services/Queues/HoursOfOperation/getHoursOfOperations';
import { errorToast } from '../../../../components/Toast/Toast';
import { CustomDialogComponent } from '../../../../components/DialogComponent/CustomDialogComponent';
import { ExportTableDialog } from '../../../../components/ExportTableDialog/ExportTableDialog';



export type HoursOfOperation = {
  Active: string;
  CustomHOODeterminatorSubType: string;
  CustomHOODeterminatorType: string;
  Order: string;
  CustomHOO: {
    Federal: any[],
    State: any[],
    Adhoc: any[]
  }
};

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']





export const HoursOfOperationTable = ({ context, type, controlStage }: any) => {


  // console.log('Rendering HoursOfOperationTable...')
  const { loadingData, setLoadingData, hoursOfOperationList, setHoursOfOperationList, selectedHOORows, setSelectedHOORows, selectedSubType,
    setSelectedSubType, setOriginalDataStructure, setCurrentTableQueues, setModifiedRows } = context;



  const [rowSelection, setRowSelection] = useState<any>({});

  const isRowDisabled = (row: any) => {
    if (type == 'Adhoc') return false;

    if (type == 'State') {
      if (selectedHOORows.length > 0 &&
        ((row.original.StartTime + row.original.EndTime + row.original.Day) != (selectedHOORows[0].original.StartTime + selectedHOORows[0].original.EndTime + selectedHOORows[0].original.Day))) {
        return true;
      } else {
        return false
      }
    } else if (type == 'Federal') {
      return (
        selectedHOORows.length > 0 &&
        row.original.Name != selectedHOORows[0].original.Name
      );
    }

  };

  const handleRowSelection = (rows: any) => {
    setRowSelection(rows)
  };



  const addToQueueSet = (queueName: any) => {
    setCurrentTableQueues((prevSet: any) => {
      const newSet = new Set(prevSet);
      newSet.add(queueName);
      return newSet;
    });
  }


  useEffect(() => {
    setModifiedRows([]);
    setSelectedSubType(type);
    setLoadingData(true);
  }, [controlStage.currentStage]);

  //reset table selections/modifications
  useEffect(() => {
    if (loadingData || hoursOfOperationList.length == 0) {

      let data: any = [];

      data = getHoursOfOperation(type);

      const structuredData: any[] = [];
      data.then((data: any) => {
        if (data.name) {
          console.log('There is an Error!', data.name, data.message)
          setLoadingData(false);
          return errorToast('Error retrieving data');
        }

        setRowSelection({})
        setCurrentTableQueues(new Map());

        data.data.map((row: any, index1: number) => {
          setOriginalDataStructure((prevMap: any) => {
            const newMap = new Map(prevMap);
            newMap.set(`${row.CustomHOODeterminatorType + row.CustomHOODeterminatorSubType}`, row);
            return newMap;
          });
          addToQueueSet(row.CustomHOODeterminatorType + row.CustomHOODeterminatorSubType);
          switch (row.CustomHOODeterminatorSubType) {
            case 'Federal':
              row.CustomHOO.Federal.map((customHOO: any, index2: number) => {
                customHOO.ClosedPeriod.Details.map((closedPeriod: any, index3: number) => {
                  structuredData.push({
                    CustomHOODeterminatorType: row.CustomHOODeterminatorType,
                    CustomHOODeterminatorSubType: row.CustomHOODeterminatorSubType,
                    Active: row.Active,
                    Order: row.Order,
                    firstLevelIndex: index1,
                    secondLevelIndex: index2,
                    thirdLevelIndex: index3,
                    Name: customHOO.Name,
                    Date: closedPeriod.Date,
                    Day: closedPeriod.Day,
                    TimeZone: closedPeriod.TimeZone,
                    StartTime: closedPeriod.Hours.Start,
                    EndTime: closedPeriod.Hours.End,
                    AdditionalDetails: closedPeriod.AdditionalDetails,
                    NextAction: closedPeriod.NextAction,
                    Id: closedPeriod.id,
                    Holiday: customHOO.Name
                  })
                })
              })

              return;
            case 'State':
              row.CustomHOO.State.map((customHOO: any, index2: number) => {
                customHOO.ClosedPeriod.Details.map((closedPeriod: any, index3: number) => {
                  structuredData.push({
                    CustomHOODeterminatorType: row.CustomHOODeterminatorType,
                    CustomHOODeterminatorSubType: row.CustomHOODeterminatorSubType,
                    Active: row.Active,
                    Order: row.Order,
                    firstLevelIndex: index1,
                    secondLevelIndex: index2,
                    thirdLevelIndex: index3,
                    Name: customHOO.Name,
                    Date: closedPeriod.Date,
                    Day: closedPeriod.Day,
                    TimeZone: closedPeriod.TimeZone,
                    StartTime: closedPeriod.Hours.Start,
                    EndTime: closedPeriod.Hours.End,
                    AdditionalDetails: closedPeriod.AdditionalDetails,
                    NextAction: closedPeriod.NextAction,
                    Id: closedPeriod.id,
                    State: customHOO.Name
                  })
                })
              })
              return;
            case 'Adhoc':
              row.CustomHOO.Adhoc.map((customHOO: any, index2: number) => {
                customHOO.ClosedPeriod.Details.map((closedPeriod: any, index3: number) => {
                  structuredData.push({
                    CustomHOODeterminatorType: row.CustomHOODeterminatorType,
                    CustomHOODeterminatorSubType: row.CustomHOODeterminatorSubType,
                    Active: row.Active,
                    Order: row.Order,
                    firstLevelIndex: index1,
                    secondLevelIndex: index2,
                    thirdLevelIndex: index3,
                    Name: customHOO.Name,
                    Date: closedPeriod.Date,
                    Day: closedPeriod.Day,
                    TimeZone: closedPeriod.TimeZone,
                    StartTime: closedPeriod.Hours.Start,
                    EndTime: closedPeriod.Hours.End,
                    AdditionalDetails: closedPeriod.AdditionalDetails,
                    NextAction: closedPeriod.NextAction,
                    Id: closedPeriod.id,
                    State: customHOO.Name
                  })
                })
              })
              return;
            default:
              return;
          }
        });
        setHoursOfOperationList(structuredData);
        setLoadingData(false);
      });

    }
  }, [loadingData]);

  const daysList = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  const columns = useMemo<MRT_ColumnDef<any>[]>(
    () => [
      {
        accessorKey: 'CustomHOODeterminatorType',
        header: 'Queue Name',
        enableEditing: false,
      },
      {
        accessorKey: 'CustomHOODeterminatorSubType',
        header: 'Closed Hours Type',
        enableEditing: false,
        enableColumnFilter: false,
      },
      {
        accessorKey: 'Holiday',
        header: 'Holiday',
        enableEditing: false
      },
      {
        accessorKey: 'State',
        header: 'State',
        enableEditing: false

      },
      {
        accessorKey: 'Date',
        header: 'Date',
        enableEditing: ((row: MRT_Row<any>) => {
          switch (row.original.CustomHOODeterminatorSubType) {
            case 'Federal':
              return true;
            case 'State':
              return false;
            case 'Adhoc':
              return true;
            default:
              return true;
          }
        }),
      },
      {
        accessorKey: 'Day',
        header: 'Day of the Week',
        editVariant: 'select',
        editSelectOptions: DAYS,
        // muiEditTextFieldProps: {
        //   select: true,
        // },
        filterVariant: 'multi-select',
        filterSelectOptions: daysList,
        // renderColumnFilterModeMenuItems: (props: {column}) => {
        //   return daysList.map((day) => {
        //     return {
        //       value: day,
        //       label: day,
        //     };
        //   });
        // },
      },
      {
        accessorKey: 'StartTime',
        header: 'Closed From',
      },
      {
        accessorKey: 'EndTime',
        header: 'Closed Until',

      },
      {
        accessorKey: 'Order',
        header: 'Priority',
        enableEditing: false,
        enableColumnFilter: false,
      },
    ],
    [],
  );

  const table = useMaterialReactTable({
    columns: columns,
    data: hoursOfOperationList,
    enableSelectAll: ((type == 'Federal' && selectedHOORows.length > 0) || (type == 'State' && selectedHOORows.length > 0)),
    enableMultiRowSelection: true,
    enableTopToolbar: selectedHOORows.length > 0,
    enableToolbarInternalActions: false,
    enablePagination: true,
    // getRowId : (row:any) => row.id,
    enableRowSelection: (row: any) => type == 'All' ? false : !isRowDisabled(row),
    onRowSelectionChange: handleRowSelection,
    state: { rowSelection: rowSelection },

    enableColumnPinning: true,
    enableSorting: false,
    columnFilterDisplayMode: 'custom',
    muiFilterTextFieldProps: ({ column }) => ({
      label: `Filter by ${column.columnDef.header}`,
    }),
    enableColumnActions: false,
    muiPaginationProps: {
      rowsPerPageOptions: [{ value: 10, label: '10' }, { value: 20, label: '20' }, { value: 50, label: '50' }, { value: 100, label: '100' }, { value: hoursOfOperationList.length, label: 'All' }],
    },
    autoResetPageIndex: false,
    enableDensityToggle: true,
    enableStickyHeader: true,
    muiTableContainerProps: { sx: { height: 'auto', maxHeight: '600px', zIndex: 0 } },
    initialState: {
      density: 'comfortable',
      pagination: {
        pageIndex: 0,
        pageSize: 50,
      },
      columnPinning: {
        left: [
          'mrt-row-select',
          'mrt-row-actions',
          'CustomHOODeterminatorType',
          'CustomHOODeterminatorSubType'
        ]
      }
    },
    enableFullScreenToggle: false,
  })

  useEffect(() => {
    //fetch data based on row selection state
    setSelectedHOORows(table.getSelectedRowModel().rows)
  }, [table.getState().rowSelection]);


  return (
    <>
      {loadingData && <LoadingComponent />}

      <div className='flex flex-col'>
        <div className='flex flex-col w-full justify-items-start'>
          <div>
            <p className='text-base' hidden={selectedSubType !== 'All'}>
              ** "All" view is read-only and does not allow modifications. To modify entries, please select Federal, State or Adhoc as the Sub Type.
            </p>
          </div>
        </div>

        {/* ----------------------- Create Filter here ----------------------- */}
        <div className='flex flex-row justify-self-center'>
          <Toolbar table={table} context={context} importEnabled={false} setLoadingData={setLoadingData} handleEdit={null}/>
        </div>

        {/* ------------------------------------------------------------------ */}
        <div className='flex flex-row'>
          <MaterialReactTable table={table} />
          <CustomDialogComponent size={'sm'} fullWidth={false} open={context.dataDialog.exportDialog}>
            <ExportTableDialog context={context} table={table} headers={['Queue Name', 'Closed Hours Type', 'Holiday', 'State', 'Date', 'Day', 'Closed From', 'Closed Until', 'Priority']} data={table.getPaginationRowModel().rows.map((row: any) => {
              const obj = {
                CustomHOODeterminatorType: row.original.CustomHOODeterminatorType,
                CustomHOODeterminatorSubType: row.original.CustomHOODeterminatorSubType,
                Holiday: row.original.Holiday,
                State: row.original.State,
                Date: row.original.Date,
                Day: row.original.Day,
                StartTime: row.original.StartTime,
                EndTime: row.original.EndTime,
                Order: row.original.Order,
              }
              return Object.values(obj);

            })} columns={columns} filename='hours_of_operation' />
          </CustomDialogComponent>
        </div>
      </div>
    </>
  )
};

