import './ViewHOOCell.css'
import { useCallback } from "react";




export const ViewHOOCell = ({openViewEditHOODialog, data, context}: any) => {


    const openDialog = () => {
        openViewEditHOODialog();
      };

      const handleEdit = useCallback(
        (dataEdit: any) => {
            context.setCurrentHOORow(dataEdit)
            openDialog();
        },
        [openDialog],
    );

    return (<a className="link" onClick={() => handleEdit(data)}>View/Edit Hours</a>);
}