import { ContainerQueues } from './styled';
import { useContext } from 'react';
import { QueuesContext } from '../../../context/Queues/QueuesContext';
import { HoursOfOperationTable } from './Tables/HoursOfOperationTable';
import { HOOEditDialog } from './HOOEditDialog/HOOEditDialog';
import { HOODeleteDialog } from './HOODeleteDialog/HOODeleteDialog';
import { HOOAddClosedPeriodDialog } from './HOOAddDialog/HOOAddClosedPeriodDialog';
import { CustomDialogComponent } from '../../../components/DialogComponent/CustomDialogComponent';
import { MdQueue, MdHistory } from 'react-icons/md';
import { HOONavigation } from '../../../components/Navigation/HOONavigation';
import { HOONavigationContext } from '../../../context/HOONavigationContext/HOONavigationContext';


export const HoursOfOperation = () => {

  const queuesContext = useContext(QueuesContext);

  const { dialogViewEditHOO, dialogDeleteHOO, dialogAddClosedPeriodHOO } = queuesContext.dataDialog;

  const navContext = useContext(HOONavigationContext);

  const { controlStage } = navContext;


  const flowRender = [<HoursOfOperationTable context={queuesContext} type='All' controlStage={controlStage} />, <HoursOfOperationTable context={queuesContext} type='Federal' controlStage={controlStage} />, <HoursOfOperationTable context={queuesContext} type='State' controlStage={controlStage} />,  <HoursOfOperationTable context={queuesContext} type='Adhoc' controlStage={controlStage} /> ];

  const dataItems = [
    
    
    {
      nameItem: 'All',
      icon: <MdQueue />,
      value: 0,
    },
    {
      nameItem: 'Federal',
      icon: <MdQueue />,
      value: 1,
    },
    {
      nameItem: 'State',
      icon: <MdQueue />,
      value: 2,
    },
    {
      nameItem: 'Adhoc',
      icon: <MdHistory />,
      value: 3,
    },
  ];



  return (
    <ContainerQueues initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <HOONavigation dataItems={dataItems} />
      {flowRender[controlStage.currentStage]}
      <CustomDialogComponent open={dialogViewEditHOO} fullWidth={true} size="lg"  >
        <HOOEditDialog context={queuesContext} />
      </CustomDialogComponent>
      <CustomDialogComponent open={dialogDeleteHOO} fullWidth={true} size="lg" >
        <HOODeleteDialog context={queuesContext} />
      </CustomDialogComponent>
      <CustomDialogComponent open={dialogAddClosedPeriodHOO} fullWidth={true} size="sm" >
        <HOOAddClosedPeriodDialog context={queuesContext} />
      </CustomDialogComponent>
    </ContainerQueues>

  );
};


