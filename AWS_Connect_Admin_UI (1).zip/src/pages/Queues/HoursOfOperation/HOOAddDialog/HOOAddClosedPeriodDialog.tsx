import { useContext, useState } from 'react';
import { ContainerEditRow, ContentDialog, HeaderDialog } from './styled';
import { successToast, errorToast } from '../../../../components/Toast/Toast';

import { useHOOLists } from '../../../../hooks/useHOOList';
import { HOOAddClosedPeriod } from './HOOAddClosedPeriods/HOOAddClosedPeriod';
import { ConfirmationDialog } from '../../../../components/ConfirmationDialog/ConfirmationDialog';
import { CustomDialogComponent } from '../../../../components/DialogComponent/CustomDialogComponent';
import { v4 as uuid } from 'uuid'
import { UserInfoContext } from '../../../../context/UserInfoContext';
// import { getQueues } from '../../../../services/Queues/HoursOfOperation/getQueues';

interface dataUpdateProps {
    name: string;
    loginId: string;
    payload: any

}

type ClosedPeriod = any;




export const HOOAddClosedPeriodDialog = ({ context }: any) => {
    const { dataDialog, selectedSubType, currentTableQueues, originalDataStructure, setLoadingData } = context;
    const { mutateAddHOO } = useHOOLists();
    const userContext = useContext(UserInfoContext);
    const [stageRenderEditPrompt, setStageRenderEditPrompt] = useState<number>(0);
    const [errorPrompt, setErrorPrompt] = useState<boolean>(false);
    const [showConfirmationDialog, setShowConfirmationDialog] = useState<boolean>(false);


    const [dayValue, setDayValue] = useState('Sunday');
    const [dateValue, setDateValue] = useState('');
    const [startTime, setStartTime] = useState('12:00 AM');
    const [endTime, setEndTime] = useState('12:00 AM');
    const [timeZone, setTimeZone] = useState('EST');
    const [nextActionType, setNextActionType] = useState('EndCall');
    const [locationType, setLocationType] = useState('TTS');
    const [locationName, setLocationName] = useState('');
    const [locationKey, setLocationKey] = useState('');
    const [locationSubKey, setLocationSubKey] = useState('');
    const [locationValue, setLocationValue] = useState('');
    // const [additionalDetails, setAdditionalDetails] = useState<any[]>([{ Name: '', Value: '', index: 0 }]);
    const [selectedQueues, setSelectedQueues] = useState([]);
    const [selectedStates, setSelectedStates] = useState([]);
    const [selectedHoliday, setSelectedHoliday] = useState({ value: 'Select a Holiday...', label: 'Select Holiday...' });

    const handleAddHOOClosedPeriod = async () => {


        const newQueues: any[] = [];
        const existingQueues: any[] = [];


        switch (selectedSubType) {

            case 'Federal':
                selectedQueues.map((queue: any) => {
                    if (currentTableQueues.has(queue.value + selectedSubType)) {
                        const obj = originalDataStructure.get(queue.value + '' + selectedSubType)
                        const foundObject = obj.CustomHOO.Federal.find((obj: any) => obj.Name === selectedHoliday.value);
                        if (foundObject) {
                            //If Queue DOES have association to holiday
                            for (let i = 0; i < obj.CustomHOO.Federal.length; i++) {
                                if (obj.CustomHOO.Federal[i].Name == selectedHoliday.value) {
                                    obj.CustomHOO.Federal[i].ClosedPeriod.Details.push({
                                        // AdditionalDetails: additionalDetails,
                                        Date: dateValue,
                                        Day: dayValue,
                                        TimeZone: timeZone,
                                        Hours: {
                                            Start: startTime,
                                            End: endTime
                                        },
                                        NextAction: {
                                            Message: {
                                                Location: {
                                                    Key: locationKey,
                                                    Name: locationName,
                                                    Subkey: locationSubKey,
                                                    Type: locationType,
                                                    Value: locationValue
                                                }
                                            },
                                            Type: nextActionType
                                        },
                                        id: uuid()
                                    });
                                }
                            }
                        } else {
                            //If Queue does NOT have association to holiday
                            obj.CustomHOO.Federal.push({
                                Name: selectedHoliday.label,
                                ClosedPeriod: {
                                    Details: [{
                                        // AdditionalDetails: additionalDetails,
                                        Date: dateValue,
                                        Day: dayValue,
                                        TimeZone: timeZone,
                                        Hours: {
                                            Start: startTime,
                                            End: endTime
                                        },
                                        NextAction: {
                                            Message: {
                                                Location: {
                                                    Key: locationKey,
                                                    Name: locationName,
                                                    Subkey: locationSubKey,
                                                    Type: locationType,
                                                    Value: locationValue
                                                }
                                            },
                                            Type: nextActionType
                                        },
                                        id: uuid()
                                    }]
                                }
                            });
                        }
                        existingQueues.push(obj)

                    } else {
                        newQueues.push({
                            Active: 'Y',
                            CustomHOODeterminatorSubType: selectedSubType,
                            CustomHOODeterminatorType: queue.value,
                            Order: '1',
                            CustomHOO: {
                                Federal: [{
                                    Name: selectedHoliday.label,
                                    ClosedPeriod: {
                                        Details: [{
                                            // AdditionalDetails: additionalDetails,
                                            Date: dateValue,
                                            Day: dayValue,
                                            TimeZone: timeZone,
                                            Hours: {
                                                Start: startTime,
                                                End: endTime
                                            },
                                            NextAction: {
                                                Message: {
                                                    Location: {
                                                        Key: locationKey,
                                                        Name: locationName,
                                                        Subkey: locationSubKey,
                                                        Type: locationType,
                                                        Value: locationValue
                                                    }
                                                },
                                                Type: nextActionType
                                            },
                                            id: uuid()
                                        }]
                                    }
                                }]
                            }


                        });
                    }
                });
                console.log('existingQueues', existingQueues)
                console.log('newQueues', newQueues)
                break;
            case 'State':
                selectedQueues.map((queue: any) => {
                    if (currentTableQueues.has(queue.value + selectedSubType)) {
                        const obj = originalDataStructure.get(queue.value + '' + selectedSubType)
                        selectedStates.map((state: any) => {
                            const foundObject = obj.CustomHOO.State.find((obj: any) => obj.Name === state.value);
                            if (foundObject) {
                                //If Queue DOES have association to State
                                for (let i = 0; i < obj.CustomHOO.State.length; i++) {
                                    if (obj.CustomHOO.State[i].Name == state.value) {
                                        obj.CustomHOO.State[i].ClosedPeriod.Details.push({
                                            // AdditionalDetails: additionalDetails,
                                            Day: dayValue,
                                            TimeZone: timeZone,
                                            Hours: {
                                                Start: startTime,
                                                End: endTime
                                            },
                                            NextAction: {
                                                Message: {
                                                    Location: {
                                                        Key: locationKey,
                                                        Name: locationName,
                                                        Subkey: locationSubKey,
                                                        Type: locationType,
                                                        Value: locationValue
                                                    }
                                                },
                                                Type: nextActionType
                                            },
                                            id: uuid()
                                        });
                                    }
                                }
                            } else {
                                //If Queue does NOT have association to State
                                obj.CustomHOO.State.push({
                                    Name: state.value,
                                    ClosedPeriod: {
                                        Details: [{
                                            // AdditionalDetails: additionalDetails,
                                            Day: dayValue,
                                            TimeZone: timeZone,
                                            Hours: {
                                                Start: startTime,
                                                End: endTime
                                            },
                                            NextAction: {
                                                Message: {
                                                    Location: {
                                                        Key: locationKey,
                                                        Name: locationName,
                                                        Subkey: locationSubKey,
                                                        Type: locationType,
                                                        Value: locationValue
                                                    }
                                                },
                                                Type: nextActionType
                                            },
                                            id: uuid()
                                        }]
                                    }
                                });
                            }
                        });
                        existingQueues.push(obj)

                    } else {


                        const newStateObject: ClosedPeriod = {
                            Active: 'Y',
                            CustomHOODeterminatorSubType: selectedSubType,
                            CustomHOODeterminatorType: queue.value,
                            Order: '2',
                            CustomHOO: {
                                State: []
                            }


                        }
                        selectedStates.map((state: any) => {
                            const newClosedPeriod: ClosedPeriod = {
                                Name: state.value,
                                ClosedPeriod: {
                                    Details: [{
                                        // AdditionalDetails: additionalDetails,
                                        Day: dayValue,
                                        TimeZone: timeZone,
                                        Hours: {
                                            Start: startTime,
                                            End: endTime
                                        },
                                        NextAction: {
                                            Message: {
                                                Location: {
                                                    Key: locationKey,
                                                    Name: locationName,
                                                    Subkey: locationSubKey,
                                                    Type: locationType,
                                                    Value: locationValue
                                                }
                                            },
                                            Type: nextActionType
                                        },
                                        id: uuid()
                                    }]
                                }
                            }
                            newStateObject.CustomHOO.State.push(newClosedPeriod)
                        });
                        newQueues.push(newStateObject);
                    }
                });
                // console.log('existingQueues', existingQueues)
                // console.log('newQueues', newQueues)
                break;
            case 'Adhoc':
                selectedQueues.map((queue: any) => {
                    if (currentTableQueues.has(queue.value + selectedSubType)) {
                        const obj = originalDataStructure.get(queue.value + '' + selectedSubType)
                        selectedStates.map((state: any) => {
                            const foundObject = obj.CustomHOO.Adhoc.find((obj: any) => obj.Name === state.value);
                            if (foundObject) {
                                //If Queue DOES have association to State
                                for (let i = 0; i < obj.CustomHOO.Adhoc.length; i++) {
                                    if (obj.CustomHOO.Adhoc[i].Name == state.value) {
                                        obj.CustomHOO.Adhoc[i].ClosedPeriod.Details.push({
                                            // AdditionalDetails: additionalDetails,
                                            Day: dayValue,
                                            Date: dateValue,
                                            TimeZone: timeZone,
                                            Hours: {
                                                Start: startTime,
                                                End: endTime
                                            },
                                            NextAction: {
                                                Message: {
                                                    Location: {
                                                        Key: locationKey,
                                                        Name: locationName,
                                                        Subkey: locationSubKey,
                                                        Type: locationType,
                                                        Value: locationValue
                                                    }
                                                },
                                                Type: nextActionType
                                            },
                                            id: uuid()
                                        });
                                    }
                                }
                            } else {
                                //If Queue does NOT have association to State
                                obj.CustomHOO.Adhoc.push({
                                    Name: state.value,
                                    ClosedPeriod: {
                                        Details: [{
                                            // AdditionalDetails: additionalDetails,
                                            Day: dayValue,
                                            Date: dateValue,
                                            TimeZone: timeZone,
                                            Hours: {
                                                Start: startTime,
                                                End: endTime
                                            },
                                            NextAction: {
                                                Message: {
                                                    Location: {
                                                        Key: locationKey,
                                                        Name: locationName,
                                                        Subkey: locationSubKey,
                                                        Type: locationType,
                                                        Value: locationValue
                                                    }
                                                },
                                                Type: nextActionType
                                            },
                                            id: uuid()
                                        }]
                                    }
                                });
                            }
                        });
                        existingQueues.push(obj)

                    } else {


                        const newAdhocObject: ClosedPeriod = {
                            Active: 'Y',
                            CustomHOODeterminatorSubType: selectedSubType,
                            CustomHOODeterminatorType: queue.value,
                            Order: '3',
                            CustomHOO: {
                                Adhoc: []
                            }


                        }
                        selectedStates.map((state: any) => {
                            const newClosedPeriod: ClosedPeriod = {
                                Name: state.value,
                                ClosedPeriod: {
                                    Details: [{
                                        // AdditionalDetails: additionalDetails,
                                        Day: dayValue,
                                        Date: dateValue,
                                        TimeZone: timeZone,
                                        Hours: {
                                            Start: startTime,
                                            End: endTime
                                        },
                                        NextAction: {
                                            Message: {
                                                Location: {
                                                    Key: locationKey,
                                                    Name: locationName,
                                                    Subkey: locationSubKey,
                                                    Type: locationType,
                                                    Value: locationValue
                                                }
                                            },
                                            Type: nextActionType
                                        },
                                        id: uuid()
                                    }]
                                }
                            }
                            newAdhocObject.CustomHOO.Adhoc.push(newClosedPeriod)
                        });
                        newQueues.push(newAdhocObject);
                    }
                });
                // console.log('existingQueues', existingQueues)
                // console.log('newQueues', newQueues)
                break;
            default:
                break;
        }




        const dataUpdate: dataUpdateProps = {
            name: userContext.name,
            loginId: userContext.email,
            payload: {
                existingQueues: existingQueues,
                newQueues: newQueues
            }
        };

        return await mutateAddHOO(dataUpdate, {
            onSuccess: () => {
                successToast('Success adding closed period');
                setShowConfirmationDialog(false)
                dataDialog.setDialogAddClosedPeriodHOO(false);
                setLoadingData(true);

            },
            onError: (): any => {
                setStageRenderEditPrompt(0);
                return errorToast('Error creating item');
            },
        });
    };

    const flowStates = [
        <HOOAddClosedPeriod
            context={context}
            dataDialog={dataDialog}
            errorPrompt={{ errorPrompt, setErrorPrompt }}
            handleAddHOOClosedPeriod={handleAddHOOClosedPeriod}
            setShowConfirmationDialog={setShowConfirmationDialog}
            dateValue={dateValue}
            setDateValue={setDateValue}
            dayValue={dayValue}
            setDayValue={setDayValue}
            startTime={startTime}
            setStartTime={setStartTime}
            endTime={endTime}
            setEndTime={setEndTime}
            timeZone={timeZone}
            setTimeZone={setTimeZone}
            nextActionType={nextActionType}
            setNextActionType={setNextActionType}
            locationType={locationType}
            setLocationType={setLocationType}
            locationName={locationName}
            setLocationName={setLocationName}
            locationKey={locationKey}
            setLocationKey={setLocationKey}
            locationSubKey={locationSubKey}
            setLocationSubKey={setLocationSubKey}
            locationValue={locationValue}
            setLocationValue={setLocationValue}
            // additionalDetails={additionalDetails}
            // setAdditionalDetails={setAdditionalDetails}
            selectedQueues={selectedQueues}
            setSelectedQueues={setSelectedQueues}
            selectedStates={selectedStates}
            setSelectedStates={setSelectedStates}
            selectedHoliday={selectedHoliday}
            setSelectedHoliday={setSelectedHoliday}

        />,
    ];



    return (
        <ContainerEditRow>
            <HeaderDialog>
                {/* <MdEdit /> */}
                <h2>Add {selectedSubType} HOO Closed Period</h2>
            </HeaderDialog>
            {/* {loadingUpdatePrompt && <LoadingComponent />} */}
            <ContentDialog>{flowStates[stageRenderEditPrompt]}</ContentDialog>
            <CustomDialogComponent open={showConfirmationDialog} fullWidth={true} size="sm" >
                <ConfirmationDialog setShowConfirmationDialog={setShowConfirmationDialog} handleAction={handleAddHOOClosedPeriod} header={'Confirm Add'} message={'Are you sure you want to add these closed periods of operation?'} />
            </CustomDialogComponent>
        </ContainerEditRow>

    );
};
