// import { styled } from "styled-components";
import { MdDelete } from 'react-icons/md';
import { Button, TextField } from '@mui/material';




export const AdditionalDetails = ({ handleAddAdditionalDetails, index, count, handleDeleteAdditionalDetails, additionalDetails, setAdditionalDetails }: any) => {
    

    return (<div className="row" style={{ 'display': 'flex' }}>
        <div>
            <TextField size={'small'} style={{ 'marginBottom': '10px', 'marginRight': '10px' }} type="text" id="additionaldetailname" className="form-control" label="Enter Name" value={additionalDetails[index].Name} autoComplete='off' autoFocus={false} onChange={(e: any) => {
                setAdditionalDetails((list : any) => list.map((item : any, i: number) => // Array.protptype.map creates new array
                    i === index
                        ? {                               // new object reference for updated item
                            ...item,                        // shallow copy previous item state
                            Name: e.target.value             // overwrite property being updated
                        }
                        : item
                ));
            }} />
        </div>
        <div>
            <TextField size={'small'} style={{ 'marginBottom': '10px' }} type="text" id="additionaldetailvalue" className="form-control" label="Enter Value" value={additionalDetails[index].Value} autoComplete='off' autoFocus={false} onChange={(e: any) => {

                setAdditionalDetails((list : any) => list.map((item : any, i: number) => // Array.protptype.map creates new array
                    i === index
                        ? {                               // new object reference for updated item
                            ...item,                        // shallow copy previous item state
                            Value: e.target.value             // overwrite property being updated
                        }
                        : item
                ));
            }} />

        </div>
        <div style={{ 'display': 'flex', 'alignItems': 'center', 'maxWidth': '40px' }}>
            <div hidden={index == 0}><Button style={{'maxWidth': '10', 'padding': '0px', 'minWidth': '0px', 'marginLeft': '8px'}} onClick={() => handleDeleteAdditionalDetails(index)}><MdDelete size={20} /></Button></div>
            <div hidden={count - 1 != index}>
                {/* <Button ><MdPlusOne size={20} onClick={() => {
                    handleAddClosedPeriod()
                }} /></Button> */}
                <Button style={{'maxWidth': '10', 'padding': '0px', 'minWidth': '30px', 'marginLeft': '5px', 'fontSize':'16px'}} onClick={() => {
                    handleAddAdditionalDetails(index + 1)
                }}>+</Button>
            </div>
        </div>

    </div>);



}




