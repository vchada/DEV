import { useEffect, useState } from 'react';
import { ContentFormUpdate, FooterDialog } from '../../HOOEditDialog/HOOClosedPeriodsInfoCard/styled';
import { Accordion, AccordionDetails, AccordionSummary, Button, TextField, Stack, Tooltip, Checkbox, FormControlLabel } from '@mui/material';
import { ArrowDropDownIcon } from '../../../../../components/Icons/Icons';
import './HOOAddClosedPeriod.css'
import { MdOutlineInfo } from 'react-icons/md';
import { DatePicker, LocalizationProvider, TimePicker } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { states, timeZones } from '../../../Utils';
import Select from 'react-select';
import { MultiSelect } from '../../../../../components/MultiSelect';
import dayjs from 'dayjs';
import Holidays, { HolidaysTypes } from 'date-holidays';
import { getQueues } from '../../../../../services/Queues/HoursOfOperation/getQueues';
import { errorToast } from '../../../../../components/Toast/Toast';
import { LoadingComponent } from '../../../../../components/LoadingComponent/LoadingComponent';





export const HOOAddClosedPeriod = ({ context, setShowConfirmationDialog, dayValue, setDayValue, dateValue, setDateValue, setStartTime, setEndTime, startTime, endTime,
    nextActionType, setNextActionType, locationValue, setLocationValue,
    selectedQueues, setSelectedQueues, selectedStates, setSelectedStates, selectedHoliday, setSelectedHoliday }: any) => {

    const opts: HolidaysTypes.Options = {
        types: ['public'],
        languages: '',
        timezone: 'America/New_York'
    }

    const hd = new Holidays('US', opts)
    hd.getHolidays(dayjs().year())


    const HOLIDAYS: any[] = hd.getHolidays(dayjs().year()).map((holiday: any) => {

        if (holiday.name == `Washington's Birthday`) {
            holiday.name = `Presidents' Day`;
        }

        const date = holiday.date.split(' ')[0];

        const splitDate = date.split('-');

        const finalDateString = splitDate[1] + '/' + splitDate[2] + '/' + splitDate[0]

        return {
            value: finalDateString,
            label: holiday.name
        }
    })

    const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']

    const HOURS: Record<string, number> = {
        '12AM': 0, '01AM': 1, '02AM': 2, '03AM': 3, '04AM': 4, '05AM': 5, '06AM': 6,
        '07AM': 7, '08AM': 8, '09AM': 9, '10AM': 10, '11AM': 11, '12PM': 12, '01PM': 13,
        '02PM': 14, '03PM': 15, '04MM': 16, '05PM': 17, '06PM': 18, '07PM': 19, '08PM': 20,
        '09PM': 21, '10PM': 22, '11PM': 23,
        '1AM': 1, '2AM': 2, '3AM': 3, '4AM': 4, '5AM': 5, '6AM': 6,
        '7AM': 7, '8AM': 8, '9AM': 9, '1PM': 13,
        '2PM': 14, '3PM': 15, '4MM': 16, '5PM': 17, '6PM': 18, '7PM': 19, '8PM': 20,
        '9PM': 21
    }

    const STATES: any[] = states.map((item: any) => {
        return {
            value: item,
            label: item
        }
    })

    const closeDialog = () => context.dataDialog.setDialogAddClosedPeriodHOO(false);
    const { selectedSubType } = context;
    const [selectedDate, setSelectedDate] = useState<any>(null);
    const [allDayValue, setAllDayValue] = useState<boolean>(false);
    const [queues, setQueues] = useState<any>([]);
    const [loadingQueues, setLoadingQueues] = useState<boolean>(false);


    const handleHolidaySelect = (e: any) => {
        setSelectedHoliday(e);
        setDateValue(e.value)
        setSelectedDate(dayjs(e.value))
        setDayValue(DAYS[dayjs(e.value).day()]);
    };

    const handleAllDaySelection = () => {
        if (!allDayValue) {
            setStartTime('12:00 AM')
            setEndTime('11:59 PM')
        }
        setAllDayValue(!allDayValue);

    }

    useEffect(() => {
        setLoadingQueues(true);
        if (queues.length == 0) {
            try {
                const data = getQueues();
                data.then((data) => {
                    if (data.name) {
                        console.log('There is an Error!', data.name, data.message)
                        return errorToast('Error retrieving queues');
                    }

                    const set = new Set(data.data);

                    const newData = Array.from(set).map((row: any) => {
                        return {
                            value: row,
                            label: row
                        }
                    });

                    setQueues(newData);

                    setLoadingQueues(false);

                });
            } catch (error: any) {
                console.log('Error retrieving queues', error);
                setLoadingQueues(false);
            }
        }
    }, [])

    useEffect(() => {

        setDayValue(DAYS[dayjs().day()]);
        setDateValue(dayjs().format('MM/DD/YYYY'));
        setStartTime('12:00 AM');
        setEndTime('12:00 AM');

    }, []);




    return (
        <ContentFormUpdate >
            {loadingQueues && <LoadingComponent />}
            <div >
                {/* <fieldset> */}
                <div className="row">

                    <div>

                        <MultiSelect className='select-style' label={'All Queues'} id='queues' placeholder={'Select Queue(s)...'} maxMenuHeight={200} options={queues} value={selectedQueues} onChange={setSelectedQueues} ></MultiSelect>

                    </div>
                    {selectedSubType != 'Federal' && <div style={{ 'marginTop': '10px' }}>
                        <MultiSelect className='select-style' label={'All States'} id='states' placeholder={'Select State(s)...'} maxMenuHeight={200} options={STATES} value={selectedStates} onChange={setSelectedStates} ></MultiSelect>
                    </div>}
                    {selectedSubType == 'Federal' && <div style={{ 'marginTop': '10px' }}>
                        <Select menuPortalTarget={document.body} styles={{ menuPortal: (base: any) => ({ ...base, zIndex: 9999 }) }} className='select-style' id='holidays' placeholder={'Choose Holiday...'} maxMenuHeight={2000} options={HOLIDAYS} value={selectedHoliday} onChange={handleHolidaySelect}  ></Select>
                    </div>}

                    <div className="floating-label-group">

                        {selectedSubType == 'Federal' &&
                            <div style={{ 'display': 'flex' }}>
                                <div className="floating-label-group" style={{ 'marginBottom': '20px' }}>
                                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                                        <DatePicker value={selectedDate} disabled={true} slotProps={{ textField: { size: 'small' } }} label="Select a Date" onChange={(newValue): any => {
                                            if (newValue) {
                                                setDayValue(DAYS[newValue?.day()]);
                                                setDateValue(newValue?.format('MM/DD/YYYY'));

                                            }
                                        }} />
                                    </LocalizationProvider>
                                </div>
                                {/* {selectedSubType == 'Adhoc' && <FormControlLabel style={{ 'marginLeft': '5px' }} label="Include Date?" control={<Checkbox defaultChecked onChange={handleIncludeDate} />} />} */}
                            </div>

                        }
                        {selectedSubType == 'Adhoc' &&
                            <div style={{ 'display': 'flex' }}>
                                <div className="floating-label-group" style={{ 'marginBottom': '20px' }}>
                                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                                        <DatePicker value={selectedDate} slotProps={{ textField: { size: 'small' } }} label="Select a Date" onChange={(newValue): any => {
                                            if (newValue) {
                                                setDayValue(DAYS[newValue?.day()])
                                                setDateValue(newValue?.format('MM/DD/YYYY'))
                                                setSelectedDate(newValue);
                                            }
                                        }} />
                                    </LocalizationProvider>
                                </div>
                                {/* {selectedSubType == 'Adhoc' && <FormControlLabel style={{ 'marginLeft': '5px' }} className='mb-[18px]' label="Include Date?" control={<Checkbox defaultChecked onChange={handleIncludeDate} />} />} */}
                            </div>

                        }
                        <div className="float-label-group" style={{ 'marginBottom': '5px', 'marginTop': '20px' }}>
                            <select id="day" style={{ 'width': '215px', 'height': '38px' }} disabled={(selectedSubType == 'Federal' || selectedSubType == 'Adhoc')} value={dayValue} onChange={(e: any) => {
                                setDayValue(e.target.value)
                            }}>
                                {DAYS.map((row: any) => {
                                    return (
                                        <option key={row} value={row}>{row}</option>
                                    );
                                })}
                            </select>
                            <label className="float-label">Day of the Week</label>
                        </div>
                        <div>
                            {<FormControlLabel label="All Day" control={<Checkbox onChange={handleAllDaySelection} />} />}
                        </div>
                        <div className='mt-[20px]'>
                            <LocalizationProvider dateAdapter={AdapterDayjs}>
                                <TimePicker disabled={allDayValue} value={dayjs().hour(HOURS[startTime.split(' ')[0].split(':')[0] + startTime.split(' ')[1]]).minute(Number(startTime.split(' ')[0].split(':')[1]))} slotProps={{ textField: { size: 'small' } }} label="Closed From" onChange={(newValue): any => {
                                    let hour = newValue?.hour();
                                    let hourStr = ''
                                    let timeOfDay = 'AM'
                                    if (hour) {

                                        if (hour > 11) {
                                            timeOfDay = 'PM'
                                        }
                                        if (hour != 12) {
                                            hour = hour % 12;
                                        }

                                        hourStr = hour + '';

                                        if (hour < 10) {
                                            hourStr = '0' + hour
                                        }


                                    } else if (hour == 0) {
                                        hour = 12
                                        hourStr = hour + '';

                                    }
                                    const tempMinute = newValue?.minute();
                                    let minute = ''

                                    if (tempMinute == 0) {
                                        minute = '00'
                                    } else if (tempMinute && tempMinute < 10) {
                                        minute = '0' + tempMinute;
                                    } else {
                                        minute = '' + tempMinute
                                    }

                                    const newString = hourStr + ':' + minute + ' ' + timeOfDay

                                    setStartTime(newString)

                                }} />
                            </LocalizationProvider>
                        </div>
                        <div className="floating-label-group mt-[20px]">
                            <LocalizationProvider dateAdapter={AdapterDayjs}>
                                <TimePicker disabled={allDayValue} value={dayjs().hour(HOURS[endTime.split(' ')[0].split(':')[0] + endTime.split(' ')[1]]).minute(Number(endTime.split(' ')[0].split(':')[1]))} slotProps={{ textField: { size: 'small' } }} label="Closed Until" onChange={(newValue): any => {
                                    let hour = newValue?.hour();
                                    let hourStr = ''
                                    let timeOfDay = 'AM'
                                    if (hour) {

                                        if (hour > 11) {
                                            timeOfDay = 'PM'
                                        }
                                        if (hour != 12) {
                                            hour = hour % 12;
                                        }

                                        hourStr = hour + '';

                                        if (hour < 10) {
                                            hourStr = '0' + hour
                                        }


                                    } else if (hour == 0) {
                                        hour = 12
                                        hourStr = hour + '';

                                    }
                                    const tempMinute = newValue?.minute();
                                    let minute = ''

                                    if (tempMinute == 0) {
                                        minute = '00'
                                    } else if (tempMinute && tempMinute < 10) {
                                        minute = '0' + tempMinute;
                                    } else {
                                        minute = '' + tempMinute
                                    }

                                    const newString = hourStr + ':' + minute + ' ' + timeOfDay

                                    setEndTime(newString)

                                }} />
                            </LocalizationProvider>
                            {/* <label className="floating-label">Enter End Time</label> */}
                        </div>

                        <div className="float-label-group mt-[25px] mb-[25px]">
                            {/* <input type="text" id="timezone" className="form-control" autoComplete='off' required /> */}
                            <select disabled id="timezone" style={{ 'width': '215px', 'height': '38px' }} defaultValue={'EST'}>
                                {timeZones.map((row: any, index: any) => {
                                    return (
                                        <option key={row + index} value={row}>{row}</option>
                                    );
                                })}
                            </select>
                            <label className="float-label">Time Zone</label>
                        </div>

                    </div>
                </div>
                {(selectedSubType == 'Federal' || selectedSubType == 'Adhoc') && <Accordion >
                    <AccordionSummary sx={{ 'paddingLeft': '10px' }} id="panel-header" aria-controls="panel-content" expandIcon={<ArrowDropDownIcon />} >
                        Next Action <Tooltip title={'The next action that needs to be taken if determined to be a closed hour. Th.'}><span style={{ 'marginLeft': '10px' }}><MdOutlineInfo /></span></Tooltip>
                    </AccordionSummary>
                    <AccordionDetails sx={{ 'paddingLeft': '5px' }}>
                        <Accordion elevation={0}>
                            <AccordionDetails sx={{ 'paddingLeft': '5px' }}>
                                <div className="row">
                                    <div className="floating-label-group flex items-center">
                                        {/* <input type="text" id="type" className="form-control" autoComplete='off' autoFocus={false} required /> <Tooltip title={'Describes what the next action would be'}><span style={{ 'marginLeft': '10px' }}><MdOutlineInfo /></span></Tooltip> */}
                                        <select value={nextActionType} id="day" style={{ 'width': '215px', 'height': '40px' }} onChange={(e: any) => {
                                            if (e.target.value == 'VM' || e.target.value == 'MiniAttendant') {
                                                setLocationValue('')
                                            }
                                            setNextActionType(e.target.value)
                                        }}>
                                            <option value="VM">VM (Voicemail)</option>
                                            <option value="MiniAttendant">Mini Attendant</option>
                                            <option value="EndCall">EndCall</option>
                                        </select> <Tooltip title={'Describes what the next action would be. VM (Voicemail) or End Call'}><span style={{ 'marginLeft': '10px' }}><MdOutlineInfo /></span></Tooltip>
                                        <label className="floating-label">Enter Type</label>
                                    </div>
                                </div>
                                <Accordion defaultExpanded elevation={0} >
                                    <AccordionSummary sx={{ 'paddingLeft': '3px' }} id="panel-header" aria-controls="panel-content" expandIcon={<ArrowDropDownIcon />}>
                                        Message  <Tooltip title={'The message (if any) that needs to be played when the closed hour is determined.'}><span style={{ 'marginLeft': '10px' }}><MdOutlineInfo /></span></Tooltip>
                                    </AccordionSummary>
                                    <AccordionDetails sx={{ 'paddingLeft': '0px' }}>

                                        <div style={{ 'display': 'flex', 'alignItems': 'center' }}>
                                            <TextField size={'small'} style={{ 'marginBottom': '10px', 'padding': 'auto' }} type="text" id="locationValue" className="form-control" autoComplete='off' label='Enter Message' autoFocus={false} value={locationValue} disabled={nextActionType == 'VM' || nextActionType == 'MiniAttendant'} onChange={(e: any) => {
                                                setLocationValue(e.target.value)
                                            }} /> <Tooltip title={'Contains the actual message to be played. Set only for End Call. Set to empty for Voicemail and Mini Attendant next action type.'}><span style={{ 'marginLeft': '10px' }}><MdOutlineInfo /></span></Tooltip>
                                        </div>
                                    </AccordionDetails>
                                </Accordion>
                            </AccordionDetails>

                        </Accordion>
                    </AccordionDetails>
                </Accordion>}
                {/* <Accordion>
                    <AccordionSummary id="panel-header" aria-controls="panel-content" expandIcon={<ArrowDropDownIcon />} >
                        Additional Details <Tooltip title={'A list of name-value pairs to add in any other additional details for the closed period.'}><span style={{ 'marginLeft': '10px' }}><MdOutlineInfo /></span></Tooltip>
                    </AccordionSummary>
                    <AccordionDetails key={addClosedHoursViewKey}>
                        <>
                            {additionalDetails.map((item: any, index: any) => {
                                return (
                                    <AdditionalDetails
                                        key={index}
                                        addClosedHoursViewKey={addClosedHoursViewKey}
                                        index={index}
                                        context={context}
                                        item={item}
                                        handleAddAdditionalDetails={handleAddAdditionalDetails}
                                        count={additionalDetails.length}
                                        handleDeleteAdditionalDetails={handleDeleteAdditionalDetails}
                                        additionalDetails={additionalDetails}
                                        setAdditionalDetails={setAdditionalDetails} />

                                )
                            })}
                        </>

                    </AccordionDetails>
                </Accordion> */}

            </div>

            <FooterDialog>
                <Stack spacing={1} direction={'row'}>
                    <Button onClick={closeDialog}>
                        Close
                    </Button>
                    <Button disabled={selectedQueues.length == 0 || (selectedHoliday.value == 'Select a Holiday...' && selectedSubType == 'Federal') ||
                        (startTime == '' || startTime == undefined) || (endTime == '' || endTime == undefined) || (dateValue == '' && selectedSubType == 'Federal') || (selectedSubType == 'State' && selectedStates.length == 0) ||
                        (selectedSubType == 'Adhoc' && selectedStates.length == 0)} onClick={() => setShowConfirmationDialog(true)}>
                        Save
                    </Button>
                </Stack>
            </FooterDialog>
        </ContentFormUpdate>
    );
};

