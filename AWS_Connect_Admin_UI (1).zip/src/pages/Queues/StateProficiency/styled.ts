import styled from 'styled-components';
import {motion} from 'framer-motion'

export const ContainerQueues = styled(motion.div)`
  width: 100%;
  height: 100%;
  min-height: 420px;
  padding: 1rem 1rem;
  display: block;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 2rem;

  table {
    thead {
      font-weight: 700
      tr {
        th {
          user-select: none;
          min-width: 60px;
          text-align: start;
          padding: 10px 1rem;
          font-size: 0.8rem;
          font-weight: 400;
          background-color: var(--white);
          min-width: 200px;

        

          &:nth-child(1) {
            min-width: 200px;
          }
          
          &:nth-child(4) {
            min-width: 320px;
          }

          &:nth-child(5) {
            min-width: 200px;
          }

          &:nth-child(6) {
            min-width: 100px;
          }

          &:nth-child(7) {
            min-width: 60px;
          }
        }
      }
    }
    tbody {
      tr {
        td {
          min-width: 120px;
          &:nth-child(1) {
            min-width: 200px;
          }
          &:nth-child(2) {
            min-width: 120px;
          }

          &:nth-child(4) {
            min-width: 300px;
          }

          &:nth-child(7) {
            min-width: 60px;
          }
        }
      }
    }
  }
`;



