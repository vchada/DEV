import { XLSX } from "../../../App";
import { useContext, useMemo, useState } from "react";

import { MaterialReactTable, MRT_ColumnDef, useMaterialReactTable } from 'material-react-table';
import { Button } from '@mui/material';
import { ConfirmationDialog } from '../../../components/ConfirmationDialog/ConfirmationDialog';
import { CustomDialogComponent } from '../../../components/DialogComponent/CustomDialogComponent';
import { getPreSignedURL } from '../../../services/StateProficiency/uploadGLSFile';
import { errorToast, successToast } from '../../../components/Toast/Toast';
import { QueuesContext } from '../../../context/Queues/QueuesContext';
import axios from 'axios';
import { LoadingComponent } from '../../../components/LoadingComponent/LoadingComponent';

export const StateProficiency = () => {

    const context = useContext(QueuesContext);
    const [data, setData] = useState<any[]>([]);
    const [file, setFile] = useState(null);
    const [resetKey, setResetKey] = useState(0);
    const [showConfirmationDialog, setShowConfirmationDialog] = useState<boolean>(false);
    const [showLoad, setShowLoad] = useState(false)
    const [invalidPresent, setInvalidPresent] = useState(false)




    const handleFileUpload = (e: any) => {
        setInvalidPresent(false)

        const file = e.target.files[0];
        setFile(file)
        console.log('file', file)
        const reader = new FileReader();

        reader.onload = (event) => {
            let invalidUpload = false;
            console.log('In onLoad')
            const workbook = XLSX.read(event?.target?.result, { type: 'binary' });
            const sheetName = workbook.SheetNames[0];
            const sheet = workbook.Sheets[sheetName];
            const sheetData: any[] = XLSX.utils.sheet_to_json(sheet);

            // Regex to validate the format of the product/department proficiency map
            const regexValidation = new RegExp(`^([A-Za-z]+=[1-5])(;[A-Za-z]+=[1-5])*$`)

            if (sheetData.length > 0) {
                if (!Object.prototype.hasOwnProperty.call(sheetData[0], 'AssociateNumber') || !Object.prototype.hasOwnProperty.call(sheetData[0], 'LicenseStateProficiencyLevel') || !Object.prototype.hasOwnProperty.call(sheetData[0], 'ProductTypeProficiencyMap') || !Object.prototype.hasOwnProperty.call(sheetData[0], 'DepartmentProficiencyMap')) {
                    handleClear();
                    return errorToast('Invalid column(s) in file');
                }
            }

            const processedData = sheetData.map((row: any) => {
                invalidUpload = false;
                if (![1, 2, 3, 4, 5].includes(row.LicenseStateProficiencyLevel)) {
                    invalidUpload = true;
                    setInvalidPresent(true)
                } else if (!regexValidation.test(row.ProductTypeProficiencyMap)){
                    invalidUpload = true;
                    setInvalidPresent(true)
                } else if (!regexValidation.test(row.DepartmentProficiencyMap)){
                    invalidUpload = true;
                    setInvalidPresent(true)
                }

                return {
                    AssociateNumber: row.AssociateNumber,
                    LicenseStateProficiencyLevel: row.LicenseStateProficiencyLevel,
                    ProductTypeProficiencyMap: row.ProductTypeProficiencyMap,
                    DepartmentProficiencyMap: row.DepartmentProficiencyMap,
                    invalid: invalidUpload,

                }
            })
            
            setData(processedData);
        };

        reader.readAsBinaryString(file);
    };

    const handleClear = () => {
        setData([]);
        setFile(null)
        setInvalidPresent(false)
        setResetKey(resetKey + 1)
    };

    // Function to upload the selected file using the generated presigned url
    const uploadToPresignedUrl = async (presignedUrl: any, formatData: any) => {

        // Upload file to pre-signed URL
        const uploadResponse = await axios.put(presignedUrl.data, formatData, {
            headers: {
                "Content-Type": "application/csv",
                "x-amz-server-side-encryption": "aws:kms",
            },
            onUploadProgress: (progressEvent: any) => {
                console.log(`Upload Progress: ${Math.round((progressEvent.loaded / progressEvent.total) * 100)} %`);
            },
        });

        if (uploadResponse.status == 200) {
            context.setLoadingData(false);
            setShowConfirmationDialog(false);
            handleClear()
            return successToast('Success uploading file');
        } else {
            return errorToast('Error uploading file');
        }
    };

    // Function to orchestrate the upload process
    const handleUpload = async () => {
        setShowLoad(true)
        try {
            // Ensure a file is selected
            if (!file) {
                console.error("No file selected.");
                return;
            }

            const presignedUrl = await getPreSignedURL();
            uploadToPresignedUrl(presignedUrl, file);
        } catch (error) {
            // Handle error
            console.error("Error uploading file:", error);
            return errorToast('Error uploading file');
        } finally {
            setShowLoad(false)
        }
    };

    const columns = useMemo<MRT_ColumnDef<any>[]>(
        () => [
            // {
            //     accessorKey: 'AgentName',
            //     header: 'Agent Name',
            // },
            {
                accessorKey: 'AssociateNumber',
                header: 'Associate Number ',
            },
            // {
            //     accessorKey: 'Email',
            //     header: 'Email',

            // },
            // {
            //     accessorKey: 'ProductType',
            //     header: 'Product Type',

            // },
            // {
            //     accessorKey: 'Department',
            //     header: 'Department',

            // },
            {
                accessorKey: 'LicenseStateProficiencyLevel',
                header: 'License State Proficiency Level',

            },
            {
                accessorKey: 'ProductTypeProficiencyMap',
                header: 'Product Proficiency Map',


            },
            {
                accessorKey: 'DepartmentProficiencyMap',
                header: 'Department Proficiency Map',

            },

        ],
        [],
    );

    const table = useMaterialReactTable({
        columns: columns,
        data: data,
        muiPaginationProps: {
            rowsPerPageOptions: [{ value: 10, label: '10' }, { value: 20, label: '20' }, { value: 50, label: '50' }, { value: 100, label: '100' }, { value: data.length, label: 'All' }],
        },
        enableColumnPinning: true,
        autoResetPageIndex: false,
        enableDensityToggle: true,
        columnFilterDisplayMode: 'subheader',
        // muiFilterTextFieldProps = {{
        //   sx: { width: '100%' },
        //   variant: 'outlined',
        // }}
        enableStickyHeader: true,
        muiTableContainerProps: { sx: { height: '600px' } },

        initialState: {
            density: 'comfortable', pagination: { pageIndex: 0, pageSize: 20, },
            columnPinning: {
                left: [
                    'AgentName',
                    'AssociateNumber',
                ]
            }
        },
        enableFullScreenToggle: false,
        enableTopToolbar: false,
        muiTableBodyRowProps: ({ row }) => ({
            sx: { backgroundColor: row.original.invalid ? '#f56c6c' : 'white' }
          }),

    })


    return (
        <>
            {showLoad && <LoadingComponent />}

            <div className='container ml-auto mr-auto mt-[20px] border-0 text-black'>
                <div className='flex justify-between'>
                    <div className='flex'>
                        <input key={resetKey} className='mb-[5px] auto w-auto' accept='.csv' type="file" onChange={handleFileUpload} />
                        <div className='content-center mb-[5px]' hidden={data.length == 0}><Button className='h-[30px]' color='primary' onClick={handleClear}>Clear</Button></div>
                    </div>
                    <div className='content-end mb-[5px]' hidden={data.length == 0}><Button className='h-[30px]' variant="outlined" color='primary' disabled={data.length == 0 || (data.length > 0 && invalidPresent)} onClick={() => {
                        setShowConfirmationDialog(true)
                    }}>Save</Button></div>
                </div>
                {(data.length > 0 && invalidPresent) && 
                <div>
                    <p style={{'color': 'red'}}>There are invalid rows (labeled in red) in the file. Please make sure the file's contents fulfills all criteria below and then clear and re-select the file.</p>
                    <p style={{'fontWeight' : '600'}}>License State Proficiency Level should have a value between 1 and 5</p>
                    <p style={{'fontWeight' : '600'}}>Product Proficiency Map value should follow this example format: 'DEPLOYYEDDRIVER=3;GPUP=2'</p>
                    <p style={{'fontWeight' : '600'}}>Department Proficiency Map value should follow this example format: 'CLAIMS=1;MOATSERVICE=3;SOMOSSERVICE=2'</p>
                </div>
                }
                {data.length == 0 && <p>Please select a proficiency document to upload.</p>}
                {data.length > 0 && <MaterialReactTable table={table} />}
            </div>
            <CustomDialogComponent open={showConfirmationDialog} fullWidth={true} size="sm" >
                <ConfirmationDialog setShowConfirmationDialog={setShowConfirmationDialog} handleAction={handleUpload} header={'Confirm Upload'} message={'Are you sure you want to upload this file?'} />
            </CustomDialogComponent>

        </>

    );
};