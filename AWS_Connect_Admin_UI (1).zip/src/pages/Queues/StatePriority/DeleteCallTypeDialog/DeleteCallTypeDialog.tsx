import { useState } from 'react';
import { ContainerEditRow, ContentDialog, HeaderDialog } from './styled';
// import { ConfirmationUpdate } from './UMConfirmationUpdate/UMConfirmationUpdate';
// import { LoadingComponent } from '../../../../../components/LoadingComponent';
import { successToast, errorToast } from '../../../../components/Toast/Toast';
import { useCallTypeIdLists } from '../../../../hooks/useCallTypeIdList';
import { DeleteCallTypeIdsForm } from './DeleteCallTypeIdsForm/DeleteCallTypeIdForm';
import { DeleteCallTypeIdsConfirmation } from './DeleteCallTypeIdsConfirmation/DeleteCallTypeIdsConfirmation';

interface dataUpdateProps {
  method: string;
  user: string;
  payload: any[]
}

export const DeleteCallTypeDialog = ({ context }: any) => {
  const { dataDialog, setLoadingData, selectedCallTypeIds } = context;
  const { mutateDeleteCallTypeIds } = useCallTypeIdLists();
  const [stageRenderEditPrompt, setStageRenderEditPrompt] = useState<number>(0);
  // const [errorPrompt, setErrorPrompt] = useState<boolean>(false);


  const handleDeleteItem = async () => {

    const payload: any = selectedCallTypeIds.map((row: any) => {
      return {
        callTypeId: row.callTypeId,
        licenseState: row.LicenseState,
        Priority: Number(row.Priority),
      }
    });

    const dataUpdate: dataUpdateProps = {
      method: 'DELETE_CALL_TYPE_IDS',
      user: 'USER TEST',
      payload: payload
    };

    // console.log('mutateDeleteCallTypeIds payload: ', dataUpdate)

    return await mutateDeleteCallTypeIds(dataUpdate, {
      onSuccess: () => {
        successToast('Success deleting call type IDs');
        setLoadingData(true)
        dataDialog.setDialogDelete(false);
      },
      onError: (): any => {
        setStageRenderEditPrompt(0);
        return errorToast('Error deleting items');
      },
    });
  };

  const flowStates = [
    <DeleteCallTypeIdsForm
      selectedCallTypeIds={selectedCallTypeIds}
      changeStage={() => setStageRenderEditPrompt(1)}
      dataDialog={dataDialog}
    // errorPrompt={{ errorPrompt, setErrorPrompt }}
    />,
    <DeleteCallTypeIdsConfirmation
      changeStage={() => setStageRenderEditPrompt(0)}
      handleDelete={() => handleDeleteItem()}
    //   hasError={errorPrompt || selectedUsers.length === 0}
    />,
  ];

  return (
    <ContainerEditRow>
      <HeaderDialog>
        <h1>Delete State Priority Value(s)?</h1>
      </HeaderDialog>
      <ContentDialog>{flowStates[stageRenderEditPrompt]}</ContentDialog>
    </ContainerEditRow>
  );
};
