import { FormEvent } from 'react';
import { ContentFormUpdate, FooterDialog } from './styled';
import { Button, Stack } from '@mui/material';
import './QueueDeleteCallTypeIds.css'
// import { errorToast } from '../../../../../../components/Toast';
// import { useUserManagementContext } from '../../../../../../context/UserManagement/useUserManagementContext';




// interface UpdateCallTypeIdsProps {
    // itemPrompt: {
    //   itemPrompt: string;
    //   setItemPrompt: (item: string) => void;
    // };
    //   userMgmtContext: any;
    //   selectedUsers: User[];
    //   setPayload: (payload: PayLoadProps) => void;
    //   errorPrompt: {
    //     errorPrompt: boolean;
    //     setErrorPrompt: (state: boolean) => void;
    //   };
    //   changeStage: () => void;
// }



// type SecurityProfileProps = {
//     Id: string;
//     Name: string;
// }

// type RoutingProfileProps = {
//     Id: string;
//     Name: string;
// }

// type PhoneTypeProps = {
//   Id: string;
//   Name: string;
// }

export const DeleteCallTypeIdsForm = ({ selectedCallTypeIds, changeStage, dataDialog }: any) => {
    //   const { dataDialog } = userMgmtContext;

    const closeDialog = () => dataDialog.setDialogDelete(false);

    // let multipeSelections = selectedUsers.length > 1 ? false: true;
    const handleDeleteIds = (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        changeStage();
    };


    return (
        <ContentFormUpdate onSubmit={handleDeleteIds}>


            <div className='tableContainer'>
                <table className='styled-table'>
                    <thead>
                        <tr>
                            <th>Call Type ID</th>
                            <th>License State</th>
                            <th>Current Priority</th>
                            {/* <th>New Priority</th> */}
                        </tr>
                    </thead>
                    <tbody>
                        {selectedCallTypeIds.map((row: any) => {
                            return (
                                <tr key={row.callTypeId + '-' + row.LicenseState}>
                                    <td>{row.callTypeId}</td>
                                    <td>{row.LicenseState}</td>
                                    <td>{row.Priority}</td>
                                    {/* <td>{row.obj.priorityUIValue}</td> */}
                                </tr>
                            );
                        })}
                    </tbody>

                </table>
            </div>



            <FooterDialog>
                <Stack spacing={1} direction={'row'}>
                    <Button variant="contained" color="warning" onClick={closeDialog}>
                        Cancel
                    </Button>
                    <Button
                        variant="contained"
                        color="primary"
                        type="submit"
                    // disabled={promptRender.length === 0}
                    >
                        Delete
                    </Button>
                </Stack>
            </FooterDialog>
        </ContentFormUpdate>
    );
};
