import styled from 'styled-components';

export const ContentFormUpdate = styled.form`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

export const FooterDialog = styled.footer`
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 0.75rem;


  div {
    button {
      padding: 8px 10px;
      letter-spacing: 0.8px;
      line-height: 1.25;
      &:last-child {
        font-weight: 400;
        background-color: var(--blue-500);
      }

      &:disabled {
        background-color: var(--gray-100);
      }
    }
  }
`;
