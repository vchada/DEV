import { FormEvent, useState } from 'react';
import { ContentFormUpdate, FooterDialog } from './styled';
import { Button, Stack } from '@mui/material';
import { InputComponent } from '../../../../../components/InputComponent';
import './AddCallTypeIdForm.css'
import { CallTypeId } from '../../Types/Types';

const states = ['AK', 'AL', 'AR', 'AZ', 'CA', 'CO', 'CT', 'DC', 'DE', 'FL', 'GA',
	'HI', 'IA', 'ID', 'IL', 'IN', 'KS', 'KY', 'LA', 'MA', 'MD', 'ME', 'MI'
	, 'MN', 'MO', 'MS', 'MT', 'NC', 'ND', 'NE', 'NH', 'NJ', 'NV', 'NY',
	'OH', 'OK', 'OR', 'PA', 'RI', 'SC', 'SD', 'TN', 'TX', 'UM', 'UT', 'VA',
	'VT', 'WA', 'WI', 'WV', 'WY']

export const AddCallTypeIdForm = ({ changeStage, dataDialog, handleSetCallTypeId }: any) => {

	const [diableSubmit, setDisbleSubmit] = useState<boolean>(true);
	const [callTypeIdName, setCallTypeIdName] = useState<string>('');

	const closeDialog = () => dataDialog.setDialogAddCallTypeId(false);

	const onChange = (e: any) => {
		setCallTypeIdName(e.target.value)
		const str = String(e.target.value);
		if (str.trim().length == 0 || str.charAt(0) == ' ') {
			setDisbleSubmit(true);
		} else {
			setDisbleSubmit(false);
		}
	}


	// let multipeSelections = selectedUsers.length > 1 ? false: true;
	const handleAddCallTypeId = (e: FormEvent<HTMLFormElement>) => {
		e.preventDefault();
		const tableValues = document.getElementById("addCallTypeIdTable") as HTMLTableElement;
		const callTypeIdName = (document.getElementById("callTypeIdName") as HTMLInputElement)?.value;
		const tableData: CallTypeId[] = [];
		// LOOP THROUGH EACH ROW OF THE TABLE AFTER HEADER.
		for (let i = 1; i < tableValues.rows.length; i++) {

			// GET THE CELLS COLLECTION OF THE CURRENT ROW.
			const objCells = tableValues?.rows?.item(i)?.cells;
			const state = objCells?.item(0)?.innerHTML;
			const priority = (objCells?.item(1)?.children[0] as HTMLSelectElement).value;
			tableData.push({
				callTypeId: callTypeIdName,
				LicenseState: state ? state : '',
				Priority: priority ? Number(priority) : 5
			})

		}
		handleSetCallTypeId(tableData);
		changeStage();
	};


	return (
		<ContentFormUpdate onSubmit={handleAddCallTypeId}>
			<InputComponent placeholder={'Enter Call Type ID Name...'} style={{ width: 300 }} id='callTypeIdName' onChange={onChange} value={callTypeIdName}></InputComponent>

			<div className='tableContainer'>
				<table className='styled-table' id='addCallTypeIdTable'>
					<thead>
						<tr>
							<th>License State</th>
							<th>Priority</th>

						</tr>
					</thead>
					<tbody>
						{states.map((state: string) => {
							return (
								<tr key={state}>
									<td>{state}</td>
									<td><select defaultValue={5}>
										<option>1</option>
										<option>2</option>
										<option>3</option>
										<option>4</option>
										<option>5</option>
									</select></td>
								</tr>
							);
						})}
					</tbody>

				</table>
			</div>

			<FooterDialog>
				<Stack spacing={1} direction={'row'}>
					<Button variant="contained" color="warning" onClick={closeDialog}>
						Cancel
					</Button>
					<Button
						variant="contained"
						color="primary"
						type="submit"
						disabled={diableSubmit}
					>
						Add
					</Button>
				</Stack>
			</FooterDialog>
		</ContentFormUpdate>
	);
};
