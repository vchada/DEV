import { useEffect, useState } from 'react';
import { ContainerEditRow, ContentDialog, HeaderDialog } from './styled';
import { successToast, errorToast } from '../../../../components/Toast/Toast';

import { CallTypeId } from '../Types/Types';
import { useCallTypeIdLists } from '../../../../hooks/useCallTypeIdList';
import { AddCallTypeIdForm } from './AddCallTypeIdForm/AddCallTypeIdForm';
import { AddCallTypeIdConfirmation } from './AddCallTypeIdConfirmation/AddCallTypeIdConfirmation';

interface dataUpdateProps {
  method: string;
  user: string;
  payload: CallTypeId[]
}

export const AddCallTypeIdDialog = ({ context, addCallTypeId, setAddCallTypeId }: any) => {
  const { dataDialog, setLoadingData } = context;
  const { mutateAddCallTypeId } = useCallTypeIdLists();
  const [stageRenderEditPrompt, setStageRenderEditPrompt] = useState<number>(0);
  const addedCallTypeId: CallTypeId[] = [];

  useEffect(() => {
    setAddCallTypeId(addedCallTypeId);
  }, []);

  const handleSetCallTypeId = (ids: CallTypeId[]) => {
    setAddCallTypeId(ids);
  }

  const handleAddCallTypeId = async () => {
    const dataUpdate: dataUpdateProps = {
      method: 'ADD_CALL_TYPE_ID',
      user: 'USER TEST',
      payload: addCallTypeId,

    };

    return await mutateAddCallTypeId(dataUpdate, {

      onSuccess: () => {
        successToast('Success updating call type IDs');
        setLoadingData(true)
        dataDialog.setDialogAddCallTypeId(false);
      },
      onError: (): any => {
        setStageRenderEditPrompt(0);
        return errorToast('Error updating item');
      },
    });
  };

  const flowStates = [
    <AddCallTypeIdForm
      changeStage={() => setStageRenderEditPrompt(1)}
      dataDialog={dataDialog}
      handleSetCallTypeId={handleSetCallTypeId}
    />,
    <AddCallTypeIdConfirmation
      changeStage={() => setStageRenderEditPrompt(0)}
      handleUpdate={() => handleAddCallTypeId()}
      addCallTypeId={addCallTypeId}
    />,
  ];

  return (
    <ContainerEditRow>
      <HeaderDialog>
        <h1>Add State Priorities For New Call Type ID</h1>
      </HeaderDialog>
      <ContentDialog>{flowStates[stageRenderEditPrompt]}</ContentDialog>
    </ContainerEditRow>
  );
};
