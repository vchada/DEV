import { useEffect, useMemo, useState } from 'react';
import {
  MaterialReactTable,
  useMaterialReactTable,
  type MRT_ColumnDef,
} from 'material-react-table';

import { CallTypeIdStatePriority } from '../Types/Types';
import { getStatePriority } from '../../../../services/Queues/StatePriority/getStatePriority';
import { PrioritySelect } from '../CellTypes/PrioritySelect';
import './Tables.css'
import { LoadingComponent } from '../../../../components/LoadingComponent/LoadingComponent';
import { errorToast } from '../../../../components/Toast/Toast';
import Toolbar from '../../../../components/Toolbar/Toolbar';
import { CustomDialogComponent } from '../../../../components/DialogComponent/CustomDialogComponent';
import { ExportTableDialog } from '../../../../components/ExportTableDialog/ExportTableDialog';

type ModifiedStatePriorityRows = {
  key: string;
  obj: CallTypeIdStatePriority;
}




export const CallTypeIdStatePriorityTable = ({ context }: any) => {


  const { dataDialog, modifiedRows, setModifiedRows, loadingData, setLoadingData, setCallTypeIds, setSelectedCallTypeIds, setSelectedSubType } = context;

  const { setDialogEditPrompt } = dataDialog;

  const [callTypeIdsData, setCallTypeIdsData] = useState<any[]>([]);
  const [muiTableKey, setMuiTableKey] = useState(0);

  useEffect(() => {
    setLoadingData(true);
    setSelectedSubType('All');
  }, []);



  //reset table selections/modifications
  useEffect(() => {
    if (loadingData || callTypeIdsData.length == 0) {
      try {
        const data = getStatePriority();
        data.then((data) => {
          if (data.name) {
            console.log('There is an Error!', data.name, data.message)
            setLoadingData(false);
            return errorToast('Error retrieving data');
          }

          setCallTypeIds(data);
          data.map((row: any) => {
            row.priorityUIValue = row.Priority;
          });

          setCallTypeIdsData(data);
          setModifiedRows([]);
          setLoadingData(false);
          setSelectedCallTypeIds([]);
          setMuiTableKey(muiTableKey + 1)
        });
      } catch (error: any) {
        setLoadingData(false);
      }


    } else {
      setLoadingData(false);
    }
  }, [loadingData]);



  const openEditDialog = () => {
    setDialogEditPrompt(true);
  };


  const handleEdit =
    (dataEdit: ModifiedStatePriorityRows[]) => {
      if (dataEdit.length == 0) return;
      openEditDialog();
    };


  const updateModifiedRows = (value: string, data: CallTypeIdStatePriority) => {
    const numVal = Number(value);
    data.priorityUIValue = numVal;
    if (Number(data.Priority) === numVal) {
      // modifiedRowsArray = modifiedRowsArray.filter((row: ModifiedStatePriorityRows) => row.key != (data.callTypeId + '-' + data.LicenseState));
      setModifiedRows(
        modifiedRows.filter((row: ModifiedStatePriorityRows) => row.key != (data.callTypeId + '-' + data.LicenseState))
      );
    } else {
      const found = modifiedRows.find((row : any ) => row.key == data.callTypeId + '-' + data.LicenseState)
      if (found) {
        found.obj.priorityUIValue = numVal;
      } else {
        const record: ModifiedStatePriorityRows = {
          key: (data.callTypeId + '-' + data.LicenseState),
          obj: {
            callTypeId: data.callTypeId,
            LicenseState: data.LicenseState,
            Priority: data.Priority,
            priorityUIValue: numVal
          }
        };

        setModifiedRows( // Replace the state
          [ // with a new array
            ...modifiedRows, // that contains all the old items
            record // and one new item at the end
          ]
        );
      }


    }
  }




  const columns = useMemo<MRT_ColumnDef<any>[]>(
    () => [
      {
        accessorKey: 'callTypeId',
        header: 'Call Type ID',
      },
      {
        accessorKey: 'LicenseState',
        header: 'License State',
      },
      //   {
      //     accessorKey: 'Priority',
      //     header: 'Priority',
      //   },
      {
        accessorKey: 'priorityUIValue',
        header: 'Priority',
        Cell: ({ cell }) => (

          <PrioritySelect key={muiTableKey} data={cell.row.original} onChange={updateModifiedRows}>{cell}</PrioritySelect>
        ),
      },

    ],
    [callTypeIdsData, modifiedRows],
  );



  const table = useMaterialReactTable({
    columns: columns,
    data: callTypeIdsData,
    muiPaginationProps: {
      rowsPerPageOptions: [{ value: 10, label: '10' }, { value: 20, label: '20' }, { value: 50, label: '50' }, { value: 100, label: '100' }, { value: callTypeIdsData.length, label: 'All' }],
    },
    enableToolbarInternalActions: false,
    enableTopToolbar: false,
    autoResetPageIndex: false,
    columnFilterDisplayMode: 'subheader',
    enableStickyHeader: true,
    muiTableContainerProps: { sx: { height: '600px', width: '100%' } },
    initialState: { density: 'comfortable', pagination: { pageIndex: 0, pageSize: 20, } },
    enableFullScreenToggle: false,
    muiTableBodyRowProps: ({ row }) => ({
      sx: { backgroundColor: row.original.priorityUIValue != row.original.Priority ? 'aliceblue' : 'white' }
    }),
    // muiTablePaperProps: {
    //   elevation: 0, //change the mui box shadow

    // }
  });



  return (
    <>
      {loadingData && <LoadingComponent />}
      <div className='flex flex-col'>
        {/* ----------------------- Create Filter here ----------------------- */}
        <div className='flex flex-row justify-self-center'>
          <Toolbar table={table} context={context} importEnabled={true} setLoadingData={setLoadingData} handleEdit={handleEdit} />
        </div>
        <div className='flex flex-row'>
          <div className='w-screen'>
            <MaterialReactTable key={muiTableKey} table={table} />
          </div>

          <CustomDialogComponent size={'sm'} fullWidth={false} open={context.dataDialog.exportDialog}>
            <ExportTableDialog context={context} table={table} headers={['callTypeId', 'LicenseState', 'Priority']} data={table.getPaginationRowModel().rows.map((row: any) => {
              const obj = {
                callTypeId: row.original.callTypeId,
                LicenseState: row.original.LicenseState,
                Priority: row.original.priorityUIValue
              }
              return Object.values(obj);

            })} columns={columns} filename='calltypeId_state_priority_values' />
          </CustomDialogComponent>
        </div>
      </div>
    </>
  )

};

