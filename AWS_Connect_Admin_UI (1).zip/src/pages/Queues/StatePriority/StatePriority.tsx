import { ContainerQueues } from './styled';
import { DialogComponent } from '../../../components/DialogComponent/DialogComponent';

import { CallTypeIdStatePriorityTable } from './Tables/CallTypeIdStatePriorityTable';
import { useContext, useState } from 'react';
import { QueuesContext } from '../../../context/Queues/QueuesContext';
import { QueueEditRowComponent } from './QueueEditRowComponent/QueueEditRowComponent';
import { CSVLink, CSVDownload } from "react-csv";
import { jsPDF } from 'jspdf'; //or use your library of choice here
import autoTable from 'jspdf-autotable';
import { AddCallTypeIdDialog } from './AddCallTypeIdDialog/AddCallTypeIdDialog';
import { CallTypeId } from './Types/Types';
import { ImportCallTypeIdDialog } from './ImportCallTypeIdDialog/ImportCallTypeIdDialog';
import { DeleteCallTypeDialog } from './DeleteCallTypeDialog/DeleteCallTypeDialog';

export const StatePriority = () => {

  const context = useContext(QueuesContext);

  const { dialogEditPrompt, dialogAddCallTypeId, dialogImport, dialogDelete } = context.dataDialog;

  const [addCallTypeId, setAddCallTypeId] = useState<CallTypeId[]>();


  return (
    <ContainerQueues initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <CallTypeIdStatePriorityTable context={context} CSVLink={CSVLink} CSVDownload={CSVDownload} jsPDF={jsPDF} autoTable={autoTable} />
      <DialogComponent open={dialogEditPrompt} >
        <QueueEditRowComponent context={context} />
      </DialogComponent>
      <DialogComponent open={dialogAddCallTypeId}>
        <AddCallTypeIdDialog context={context} addCallTypeId={addCallTypeId} setAddCallTypeId={setAddCallTypeId} />
      </DialogComponent>
      <DialogComponent open={dialogImport}>
        <ImportCallTypeIdDialog context={context} />
      </DialogComponent>
      <DialogComponent open={dialogDelete}>
        <DeleteCallTypeDialog context={context} />
      </DialogComponent>
    </ContainerQueues>

  );
};
