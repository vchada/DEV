import { useState } from "react";




export const PrioritySelect = ({ data, onChange }: any) => {

    const [currentPriority, setCurrentPriority] = useState(data.priorityUIValue)

    console.debug(currentPriority);

    const handleEdit = (e: any) => {
        setCurrentPriority(e.target.value);
        onChange(e.target.value, data)

    };




    return (<select value={data.priorityUIValue} onChange={handleEdit}>
        <option>1</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
        <option>5</option>
    </select>);



}