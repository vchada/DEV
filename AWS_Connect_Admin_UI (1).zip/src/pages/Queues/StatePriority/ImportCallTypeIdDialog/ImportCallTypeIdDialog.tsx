import { useContext, useState } from 'react';
import { ContainerEditRow, ContentDialog } from './styled';
import { successToast, errorToast } from '../../../../components/Toast/Toast';
import { ImportCallTypeIdForm } from './ImportCallTypeIdForm/ImportCallTypeIdForm';
import { useCallTypeIdLists } from '../../../../hooks/useCallTypeIdList';
import { ConfirmationDialog } from '../../../../components/ConfirmationDialog/ConfirmationDialog';
import { CustomDialogComponent } from '../../../../components/DialogComponent/CustomDialogComponent';
import { UserInfoContext } from '../../../../context/UserInfoContext';

interface dataImportProps {
  // modified: {
  //   method: string;
  //   user: string;
  //   data: any[]
  // },
  // new: {
  //   method: string;
  //   user: string;
  //   data: any[]
  // }
  name: string;
  loginId: string;
  payload: any[]

}

export const ImportCallTypeIdDialog = ({ context }: any) => {
  const { dataDialog, setLoadingData } = context;
  const { mutateImportCallTypeIds } = useCallTypeIdLists();
  const userContext = useContext(UserInfoContext);
  const [stageRenderEditPrompt, setStageRenderEditPrompt] = useState<number>(0);
  const [changedCallTypeIds, setChangedCallTypeIds] = useState<any[]>([]);
  const [showConfirmationDialog, setShowConfirmationDialog] = useState<boolean>(false);
  // const [errorPrompt, setErrorPrompt] = useState<boolean>(false);

  const handleImportCallTypeIds = async () => {

    const dataImport: dataImportProps = {

      name: userContext.name,
      loginId: userContext.email,
      payload: changedCallTypeIds.map((item: any) => item.data)

    };

    return await mutateImportCallTypeIds(dataImport, {

      onSuccess: () => {
        successToast('Success importing state priority values');
        setLoadingData(true)
        dataDialog.setDialogImport(false);
        setShowConfirmationDialog(false)
      },
      onError: (): any => {
        setStageRenderEditPrompt(0);
        return errorToast('Error importing state priority values');
      },
    });
  };

  const flowStates = [
    <ImportCallTypeIdForm
      // changeStage={() => setStageRenderEditPrompt(1)}
      context={context}
      changedCallTypeIds={changedCallTypeIds}
      setChangedCallTypeIds={setChangedCallTypeIds}
      setShowConfirmationDialog={setShowConfirmationDialog} 
    // errorPrompt={{ errorPrompt, setErrorPrompt }}
    />,
    // <ImportCallTypeIdConfirmation
    //   changeStage={() => setStageRenderEditPrompt(0)}
    //   handleUpdate={() => handleImportCallTypeIds()}
    // //   hasError={errorPrompt || selectedUsers.length === 0}
    // />,
  ];

  return (
    <ContainerEditRow>
      {/* <HeaderDialog>
        <h2>Import Call Type ID(s)</h2>
      </HeaderDialog> */}
      <ContentDialog>{flowStates[stageRenderEditPrompt]}</ContentDialog>
      <CustomDialogComponent open={showConfirmationDialog} fullWidth={true} size="sm" >
        <ConfirmationDialog setShowConfirmationDialog={setShowConfirmationDialog} handleAction={handleImportCallTypeIds} header={'Confirm Import'} message={'Are you sure you want to import these state priority values?'} />
      </CustomDialogComponent>
    </ContainerEditRow>
  );
};
