import { FormEvent, useMemo, useState } from 'react';
import { ContentFormUpdate, FooterDialog } from './styled';
import { Button, Stack } from '@mui/material';
import { XLSX } from "../../../../../App";
import './ImportCallTypeIdForm.css'
import { MaterialReactTable, MRT_ColumnDef, useMaterialReactTable } from 'material-react-table';

export const ImportCallTypeIdForm = ({ context, changedCallTypeIds, setChangedCallTypeIds, setShowConfirmationDialog }: any) => {
	const { callTypeIds, dataDialog } = context;

	const [disableImport, setDisableImport] = useState<boolean>(false);

	const closeDialog = () => dataDialog.setDialogImport(false);

	const [data, setData] = useState<unknown[]>([]);

	const modifiedCallTypeIds: any[] = [];

	const handleFileUpload = (e: any) => {

		const file = e.target.files[0];
		const reader = new FileReader();

		reader.onload = (event) => {
			const workbook = XLSX.read(event?.target?.result, { type: 'binary' });
			const sheetName = workbook.SheetNames[0];
			const sheet = workbook.Sheets[sheetName];
			const sheetData = XLSX.utils.sheet_to_json(sheet);

			setData(sheetData);

			setDisableImport(false)
			sheetData.map((row: any) => {
				const found = callTypeIds.find((rowCallTypeIds: any) => row.callTypeId == rowCallTypeIds.callTypeId && row.LicenseState == rowCallTypeIds.LicenseState)
				if (found) {
					if ([1, 2, 3, 4, 5].includes(row.Priority)) { /* empty */ } else {
						setDisableImport(true)
					}

					if (Number(row.Priority) != Number(found.Priority)) {
						return modifiedCallTypeIds.push({
							state: {
								callTypeId: row.callTypeId,
								LicenseState: row.LicenseState,
								currentPriority: Number(found.Priority),
								newPriority: Number(row.Priority),
								newCallTypeId: false
							},
							data: {
								PreviousPriority: Number(found.Priority),
								callTypeId: row.callTypeId,
								LicenseState: row.LicenseState,
								NewPriority: Number(row.Priority)
							}
						})
					}


				} else {
					if ([1, 2, 3, 4, 5].includes(row.Priority)) { /* empty */ } else {
						setDisableImport(true)
					}
					return modifiedCallTypeIds.push({
						state: {
							callTypeId: row.callTypeId,
							LicenseState: row.LicenseState,
							currentPriority: 5,
							newPriority: Number(row.Priority),
							newCallTypeId: true
						},
						data: {
							callTypeId: row.callTypeId,
							LicenseState: row.LicenseState,
							Priority: Number(row.Priority),
						}
					})
				}
			});
			setChangedCallTypeIds(modifiedCallTypeIds);
		};

		reader.readAsBinaryString(file);
	};


	const handleImport = (e: FormEvent<HTMLFormElement>) => {
		e.preventDefault();
	};

	const columns = useMemo<MRT_ColumnDef<any>[]>(
		() => [
			{
				accessorKey: 'state.callTypeId',
				header: 'Call Type ID',
			},
			{
				accessorKey: 'state.LicenseState',
				header: 'License State',
			},
			{
				accessorKey: 'state.currentPriority',
				header: 'Current Priority',

			},
			{
				accessorKey: 'state.newPriority',
				header: 'New Priority',

			},
		],
		[],
	);

	const table = useMaterialReactTable({
		columns: columns,
		data: changedCallTypeIds,
		enableTopToolbar: false,
		muiPaginationProps: {
			rowsPerPageOptions: [{ value: 10, label: '10' }, { value: 20, label: '20' }, { value: 50, label: '50' }, { value: 100, label: '100' }, { value: data.length, label: 'All' }],
		},
		autoResetPageIndex: false,
		enableDensityToggle: true,
		columnFilterDisplayMode: 'subheader',
		enableStickyHeader: true,
		muiTableContainerProps: { sx: { height: 'auto', maxHeight: '500px' } },
		initialState: { density: 'comfortable', pagination: { pageIndex: 0, pageSize: 20, } },
		enableFullScreenToggle: false,

	})


	return (
		<ContentFormUpdate onSubmit={handleImport}>
			<div style={{ 'marginTop': '20px', 'marginLeft': '20px', 'backgroundColor': '#efefef', 'borderRadius': '20px', 'width': '500px' }}>
				<input type="file" accept=".csv,.xls,.xlsx" onChange={handleFileUpload} style={{ 'width': '400px' }} />
			</div>
			{disableImport &&
				<div>
					<p style={{ 'color': 'red' }}>File cannot be imported due to invalid priority value(s). Please make sure the file has acceptable priority values then re-upload.</p>
				</div>
			}

			<div style={{ 'marginTop': '5px' }}>

				{data.length == 0 && changedCallTypeIds.length == 0 && <h2 style={{ 'display': 'flex', 'justifyContent': 'center' }}>Please select an Excel or CSV file.</h2>}
				{data.length > 0 && changedCallTypeIds.length == 0 && <h2 style={{ 'display': 'flex', 'justifyContent': 'center' }}>No changes reflected in chosen file.</h2>}

				{data.length > 0 && changedCallTypeIds.length != 0 && (
					<MaterialReactTable table={table} />
				)}
			</div>




			<FooterDialog style={{ 'marginBottom': '30px' }}>
				<Stack spacing={1} direction={'row'}>
					<Button onClick={closeDialog}>
						Cancel
					</Button>
					<Button
						disabled={changedCallTypeIds.length == 0 || disableImport}
						onClick={() => setShowConfirmationDialog(true)}
					>
						Import
					</Button>
				</Stack>
			</FooterDialog>
		</ContentFormUpdate >
	);
};
