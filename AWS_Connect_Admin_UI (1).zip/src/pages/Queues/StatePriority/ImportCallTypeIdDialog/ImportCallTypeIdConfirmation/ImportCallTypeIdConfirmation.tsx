import { Button, Stack } from '@mui/material';
import { ConfirmationUpdateContent, FooterConfirmation } from './styled';


export const ImportCallTypeIdConfirmation = ({
    changeStage,
    handleUpdate,
}: any) => {
    const handleImportCallTypeIds = () => {
        handleUpdate();
        return;
    };

    return (
        <ConfirmationUpdateContent>
            <p>
                Are you sure? <br /> This will import the Call Type ID(s) into Production.
            </p>

            <FooterConfirmation>
                <Stack spacing={1} direction={'row'} justifyContent={'flex-end'}>
                    <Button variant="contained" color="warning" onClick={changeStage}>
                        Cancel
                    </Button>
                    <Button
                        variant="contained"
                        type="button"
                        onClick={handleImportCallTypeIds}
                    // disabled={hasError}
                    >
                        Confirm
                    </Button>
                </Stack>
            </FooterConfirmation>
        </ConfirmationUpdateContent>
    );
};
