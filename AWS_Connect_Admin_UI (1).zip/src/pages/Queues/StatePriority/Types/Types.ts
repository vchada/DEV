export type CallTypeIdStatePriority = {
    callTypeId: string;
    LicenseState: string;
    Priority: number;
    priorityUIValue: number;
}

export type ModifiedStatePriorityRows = {
    key: string;
    obj: CallTypeIdStatePriority;
  }


  export type CallTypeId = {
    callTypeId: string;
    LicenseState: string;
    Priority: number;
}

