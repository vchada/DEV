import { useContext, useState } from 'react';
import { ContainerEditRow, ContentDialog, HeaderDialog } from './styled';
// import { ConfirmationUpdate } from './UMConfirmationUpdate/UMConfirmationUpdate';
// import { LoadingComponent } from '../../../../../components/LoadingComponent';
import { successToast, errorToast } from '../../../../components/Toast/Toast';
import { QueueUpdateCallTypeIds } from './QueueUpdateCallTypeIds/QueueUpdateCallTypeIds';
import { ModifiedStatePriorityRows } from '../Types/Types';
import { useCallTypeIdLists } from '../../../../hooks/useCallTypeIdList';
import { ConfirmationDialog } from '../../../../components/ConfirmationDialog/ConfirmationDialog';
import { CustomDialogComponent } from '../../../../components/DialogComponent/CustomDialogComponent';
import { UserInfoContext } from '../../../../context/UserInfoContext';

interface dataUpdateProps {
  name: string;
  loginId: string;
  payload: any[]
}

export const QueueEditRowComponent = ({ context }: any) => {
  const { dataDialog, modifiedRows, setLoadingData } = context;
  const { mutateUpdateCallTypeIds } = useCallTypeIdLists();
  const userContext = useContext(UserInfoContext);
  const [stageRenderEditPrompt, setStageRenderEditPrompt] = useState<number>(0);
  const [showConfirmationDialog, setShowConfirmationDialog] = useState<boolean>(false);

  const handleUpdateItem = async () => {

    const modifiedData: any[] = modifiedRows.map((row: ModifiedStatePriorityRows) => {

      return {
        PreviousPriority: row.obj.Priority,
        callTypeId: row.obj.callTypeId,
        LicenseState: row.obj.LicenseState,
        NewPriority: row.obj.priorityUIValue
      }
    });

    const dataUpdate: dataUpdateProps = {
      name: userContext.name,
      loginId: userContext.email,
      payload: modifiedData
    };

    return await mutateUpdateCallTypeIds(dataUpdate, {
      onSuccess: () => {
        successToast('Success updating call type IDs');
        setLoadingData(true)
        dataDialog.setDialogEditPrompt(false);
        setShowConfirmationDialog(false)
      },
      onError: (): any => {
        setStageRenderEditPrompt(0);
        return errorToast('Error updating call type ID(s)');
      },
    });
  };

  const flowStates = [
    <QueueUpdateCallTypeIds
      modifiedRows={modifiedRows}
      setShowConfirmationDialog={setShowConfirmationDialog} 
      dataDialog={dataDialog}
    />,
  ];

  return (
    <ContainerEditRow>
      <HeaderDialog>
        <h1>Save Changes?</h1>
      </HeaderDialog>
      <ContentDialog>{flowStates[stageRenderEditPrompt]}</ContentDialog>
      <CustomDialogComponent open={showConfirmationDialog} fullWidth={true} size="sm" >
        <ConfirmationDialog setShowConfirmationDialog={setShowConfirmationDialog} handleAction={handleUpdateItem} header={'Confirm Edit'} message={'Are you sure you want to modify these state priority values?'} />
      </CustomDialogComponent>
    </ContainerEditRow>
  );
};
