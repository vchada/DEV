import { useMemo } from 'react';
import { ContentFormUpdate, FooterDialog } from './styled';
import { Button, Stack } from '@mui/material';
import './QueueUpdateCallTypeIds.css'
import { MaterialReactTable, MRT_ColumnDef, useMaterialReactTable } from 'material-react-table';
import { data } from '../../../../UserManagement/MReactTable/makeData';
// import { errorToast } from '../../../../../../components/Toast';
// import { useUserManagementContext } from '../../../../../../context/UserManagement/useUserManagementContext';




export const QueueUpdateCallTypeIds = ({ modifiedRows, dataDialog, setShowConfirmationDialog }: any) => {

    const closeDialog = () => dataDialog.setDialogEditPrompt(false);


    const columns = useMemo<MRT_ColumnDef<any>[]>(
        () => [
            {
                accessorKey: 'obj.callTypeId',
                header: 'Call Type ID',
            },
            {
                accessorKey: 'obj.LicenseState',
                header: 'License State',
            },
            {
                accessorKey: 'obj.Priority',
                header: 'Current Priority',

            },
            {
                accessorKey: 'obj.priorityUIValue',
                header: 'New Priority',

            },
        ],
        [],
    );

    const table = useMaterialReactTable({
        columns: columns,
        data: modifiedRows,
        enableTopToolbar: false,
        muiPaginationProps: {
            rowsPerPageOptions: [{ value: 10, label: '10' }, { value: 20, label: '20' }, { value: 50, label: '50' }, { value: 100, label: '100' }, { value: data.length, label: 'All' }],
        },
        autoResetPageIndex: false,
        enableDensityToggle: true,
        columnFilterDisplayMode: 'subheader',
        // muiFilterTextFieldProps = {{
        //   sx: { width: '100%' },
        //   variant: 'outlined',
        // }}
        enableStickyHeader: true,
        muiTableContainerProps: { sx: { height: 'auto', maxHeight: '500px' } },

        initialState: { density: 'comfortable', pagination: { pageIndex: 0, pageSize: 20, } },
        enableFullScreenToggle: false,

    })


    return (
        <ContentFormUpdate>
            <MaterialReactTable table={table} />
            <FooterDialog>
                <Stack spacing={1} direction={'row'}>
                    <Button onClick={closeDialog}>
                        Cancel
                    </Button>
                    <Button onClick={() => setShowConfirmationDialog(true)}>
                        Update
                    </Button>
                </Stack>
            </FooterDialog>
        </ContentFormUpdate>
    );
};
