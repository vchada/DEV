export const timeZones = ['ACDT', 'ACST', 'ACT', 'ACT', 'ACWST', 'ADT', 'AEDT', 'AEST', 'AET (AEST/AEDT)', 'AFT', 'AKDT', 'AKST', 'ALMT', 'AMST', 'AMT', 'AMT', 'ANAT', 'AQTT', 'ART', 'AST', 'AST', 'AWST', 'AZOST', 'AZOT', 'AZT', 'BNT', 'BIOT', 'BIT', 'BOT', 
'BRST', 'BRT', 'BST', 'BST', 'BST', 'BTT', 'CAT', 'CCT', 'CDT', 'CDT', 'CEST', 'CET', 'CHADT', 'CHAST', 'CHOT', 'CHOST', 'CHST', 'CHUT', 'CIST', 'CKT', 'CLST', 'CLT', 'COST', 'COT', 'CST', 'CST', 'CST',
 'CT (CST/CDT)', 'CVT', 'CWST', 'CXT', 'DAVT', 'DDUT', 'DFT', 'EASST', 'EAST', 'EAT', 'ECT', 'ECT', 'EDT', 'EEST', 'EET', 'EGST', 'EGT', 'EST', 'ET (EST/EDT)', 'FET',
 'FJT', 'FKST', 'FKT', 'FNT', 'GALT', 'GAMT', 'GET', 'GFT', 'GILT', 'GIT', 'GMT', 'GST', 'GST', 'GYT', 'HDT', 'HAEC', 'HST', 'HKT', 'HMT', 'HOVST', 'HOVT', 'ICT', 'IDLW', 
 'IDT', 'IOT', 'IRDT', 'IRKT', 'IRST', 'IST', 'IST', 'IST', 'JST', 'KALT', 'KGT', 'KOST', 'KRAT', 'KST', 'LHST', 'LHST', 'LINT', 'MAGT', 'MART', 'MAWT', 'MDT', 'MET', 'MEST', 'MHT', 'MIST', 'MIT', 'MMT', 'MSK', 'MST', 'MST', 'MT (MST/MDT)',
  'MUT', 'MVT', 'MYT', 'NCT', 'NDT', 'NFT', 'NOVT', 'NPT', 'NST', 'NT', 'NUT', 'NZDT', 'NZST', 'OMST', 'ORAT', 'PDT', 'PET', 'PETT', 'PGT', 'PHOT', 'PHT', 'PHST', 'PKT', 'PMDT', 'PMST', 'PONT', 'PST', 'PT (PST/PDT)', 'PWT', 'PYST', 'PYT', 'RET', 'ROTT', 'SAKT', 'SAMT', 'SAST', 'SBT', 'SCT', 'SDT', 'SGT', 'SLST', 'SRET', 
  'SRT', 'SST', 'SYOT', 'TAHT', 'THA', 'TFT', 'TJT', 'TKT', 'TLT', 'TMT', 'TRT', 'TOT', 'TST', 'TVT', 'ULAST', 'ULAT', 'UTC', 'UYST', 'UYT', 'UZT', 'VET', 'VLAT', 'VOLT', 'VOST', 'VUT', 'WAKT', 'WAST', 'WAT', 'WEST', 'WET', 'WIB', 'WIT', 'WITA', 'WGST', 'WGT', 'WST', 'YAKT', 'YEKT']


  export const states = ['AK', 'AL', 'AR', 'AZ', 'CA', 'CO', 'CT', 'DC', 'DE', 'FL', 'GA',
  'HI', 'IA', 'ID', 'IL', 'IN', 'KS', 'KY', 'LA', 'MA', 'MD', 'ME', 'MI'
  , 'MN', 'MO', 'MS', 'MT', 'NC', 'ND', 'NE', 'NH', 'NJ', 'NV', 'NY',
  'OH', 'OK', 'OR', 'PA', 'RI', 'SC', 'SD', 'TN', 'TX', 'UM', 'UT', 'VA',
  'VT', 'WA', 'WI', 'WV', 'WY']

  export const HOURS: Record<string, number> = {
    '12AM': 0, '01AM': 1, '02AM': 2, '03AM': 3, '04AM': 4, '05AM': 5, '06AM': 6,
    '07AM': 7, '08AM': 8, '09AM': 9, '10AM': 10, '11AM': 11, '12PM': 12, '01PM': 13,
    '02PM': 14, '03PM': 15, '04MM': 16, '05PM': 17, '06PM': 18, '07PM': 19, '08PM': 20,
    '09PM': 21, '10PM': 22, '11PM': 23
}