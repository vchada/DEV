import styled from 'styled-components';

export const ConfirmationBoxContent = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  padding: 2rem;
  min-width: 600px;

  p {
    font-size: 1rem;
    color: var(--gray-400);
    font-weight: 500;
    line-height: 1.5rem;
  }
`;

export const HeaderHistoryDialog = styled.header`
  width: 100%;
  display: flex;
  justify-content: flex-start;
  gap: 0.75rem;
  align-items: center;
  h1 {
    font-size: 1.2rem;
    color: var(--gray-500);
    margin-bottom: 0rem;
  }
  svg {
    font-size: 1.2rem;
    color: var(--blue-500);
  }
`;

export const FooterConfirmation = styled.footer`
  width: 100%;
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 0.75rem;
  padding-top: 1rem;

  div {
    button {
      padding: 8px 10px;
      letter-spacing: 0.8px;
      line-height: 1.25;
      &:last-child {
        font-weight: 600;
        background-color: var(--blue-500);
      }

      &:disabled {
        background-color: var(--gray-100);
      }
    }
  }
`;
