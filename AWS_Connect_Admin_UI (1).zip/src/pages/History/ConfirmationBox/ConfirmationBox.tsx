import { Button, Stack } from '@mui/material';
import {
  ConfirmationBoxContent,
  FooterConfirmation,
  HeaderHistoryDialog,
} from './styled';
import { SettingsBackupRestoreIcon } from '../../../components/Icons/Icons';
import { useHistory } from '../../../context/History/useHistory';
import { useHistoryLists } from '../../../hooks/useHistoryLists';
import { LoadingComponent } from '../../../components/LoadingComponent/LoadingComponent';

export const ConfirmationBox = () => {
  const { dataDialog, dataSelected } = useHistory();
  const { handleRollbackPrompt, loadingRollbackPrompt } = useHistoryLists();

  const handleRollbackItem = async () => {
    handleRollbackPrompt(dataSelected.itemHistorySelected);
  };

  const closeDialog = () => {
    dataDialog.setDialogHistoryRollback(false);
    dataSelected.setItemHistorySelected(null);
  };

  return (
    <ConfirmationBoxContent> 
      {loadingRollbackPrompt && <LoadingComponent />}

      <HeaderHistoryDialog>
        <SettingsBackupRestoreIcon />
        <h1>Restore Prompt</h1>
      </HeaderHistoryDialog>

      <p>Are you sure, you want to return this prompt?</p>

      <FooterConfirmation>
        <Stack spacing={1} direction={'row'} justifyContent={'flex-end'}>
          <Button variant="contained" color="warning" onClick={closeDialog}>
            Cancel
          </Button>
          <Button
            variant="contained"
            color="primary"
            type="button"
            onClick={handleRollbackItem}
          >
            Confirm
          </Button>
        </Stack>
      </FooterConfirmation>
    </ConfirmationBoxContent>
  );
};
