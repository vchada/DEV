import { MenuItem } from '@mui/material';

import { PanelFilterData } from './styled';
import { SelectComponent } from '../../../components/SelectComponent/SelectComponent';
import { useHistory } from '../../../context/History/useHistory';
import { ChangeEvent } from 'react';

export const PanelFilterHistory = () => {
  const { optionsIdCollections, dataFilters } = useHistory();
  return (
    <PanelFilterData>
      <SelectComponent
        labelSelect={'Filter ItemID'}
        aria-label={'Filter Item ID History'}
        value={dataFilters.filterHistories}
        onChange={(event: ChangeEvent<HTMLSelectElement>) =>
          dataFilters.setFilterHistories(event.target.value)
        }
      >
        <MenuItem value={'0'}>Select All</MenuItem>
        {optionsIdCollections.map((item: string, index: number) => (
          <MenuItem key={index} value={item}>
            {item}
          </MenuItem>
        ))}
      </SelectComponent>
    </PanelFilterData>
  );
};
