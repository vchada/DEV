import styled from 'styled-components';

export const PanelFilterData = styled.div`
  width: 100%;
  padding: 0rem;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  margin-top: 2rem;

  @media (max-width: 768px) {
    flex-direction: column;
  }
`;
