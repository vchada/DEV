import styled from 'styled-components';
import {motion} from 'framer-motion'

export const ContainerHistory = styled(motion.div)`
  width: 100%;
  height: calc(100vh - 100px);
  min-height: 420px;
  padding: 1rem 1rem;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 2rem;

  table {
    thead {
      tr {
        th {
          min-width: 180px;
          &:nth-child(1) {
            min-width: 140px;
          }
          &:nth-child(2) {
            min-width: 180px;
          }

          &:nth-child(3) {
            min-width: 200px;
          }

          &:nth-child(4) {
            min-width: 300px;
          }

          &:nth-child(5) {
            min-width: 300px;
          }

          &:nth-child(6) {
            min-width: 40px;
          }

          &:nth-child(7) {
            min-width: 40px;
          }
        }
      }
    }
    tbody {
      tr {
        td {
          min-width: 120px;
          &:nth-child(1) {
            min-width: 140px;
          }
          &:nth-child(2) {
            min-width: 160px;
          }

          &:nth-child(4) {
            min-width: 320px;
          }

          &:nth-child(5) {
            min-width: 320px;
          }


          &:nth-child(7) {
            min-width: 60px;
          }
        }
      }
    }
  }
`;
