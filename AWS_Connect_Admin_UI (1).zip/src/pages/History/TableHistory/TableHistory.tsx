import { useContext, useEffect, useMemo } from 'react';
import { format } from 'date-fns';
import { useHistory } from '../../../context/History/useHistory';
import { MaterialReactTable, MRT_ColumnDef, useMaterialReactTable } from 'material-react-table';
import { LoadingComponent } from '../../../components/LoadingComponent/LoadingComponent';
import { CustomDialogComponent } from '../../../components/DialogComponent/CustomDialogComponent';
import { ExportTableDialog } from '../../../components/ExportTableDialog/ExportTableDialog';
import Toolbar from '../../../components/Toolbar/Toolbar';
import { QueuesContext } from '../../../context/Queues/QueuesContext';
import { getHistories } from '../../../services/History/getHistory';
import { errorToast } from '../../../components/Toast/Toast';



const formatTime = (time: string) => {
  const timeToNumber = +time;
  const convertToDate = format(new Date(timeToNumber), 'Pp');
  return convertToDate;
};

export const TableHistory = () => {
  const { filteredHistories, setListHistoryPrompts } = useHistory();
  const context = useContext(QueuesContext);


  useEffect(() => {
    context.setSelectedSubType('All');
    context.setModifiedRows([]);
    if (context.loadingData || filteredHistories.length == 0) {
      try {
        context.setLoadingData(true);
        const data = getHistories();
        data.then((data) => {
          if (data.name) {
            console.log('There is an Error!', data.name, data.message)
            context.setLoadingData(false);
            return errorToast('Error retrieving data');
          }

          setListHistoryPrompts(data);

          context.setLoadingData(false);

        });
      } catch (error: any) {
        context.setLoadingData(false);
      }
    } else {
      context.setLoadingData(false);
    }
  }, [context.loadingData]);


  const columns = useMemo<MRT_ColumnDef<any>[]>(
    () => [
      {
        header: 'User',
        accessorKey: 'user',
      },
      {
        header: 'Update time',
        accessorKey: 'updatedTimestamp',
        id: 'updateTime',
        Cell: ({ row }: any) => formatTime(row.original.updatedTimestamp),
      },
      {
        header: 'Current message',
        accessorKey: 'currentPrompt',
        // Cell: ({ row }: any) => <span title={row.original.currentPrompt}>{validatePrompt(row.original.currentPrompt)}</span>
      },
      {
        header: 'Previous message',
        accessorKey: 'previousMessage',
        // Cell: ({ row }: any) => <span title={row.original.previousMessage}>{validatePrompt(row.original.previousMessage)}</span>
      },
      // {
      //   header: 'Has Restore',
      //   accessorKey: 'hasRestore',
      //   Cell: ({ row }: any) => (row.original.hasRestore ? 'True' : 'False'),
      // },
      // {
      //   header: 'Revert',
      //   id: 'revert',
      //   Cell: ({ row }: any) => (
      //     <div className="editTable">
      //       <Button
      //         aria-label="Edit Button"
      //         title={row.original}
      //         onClick={() => handleRollbackItem(row.original)}
      //       >
      //         <Icons.SettingsBackupRestoreIcon />
      //       </Button>
      //     </div>
      //   ),
      // },
    ],
    [],
  );

  const table = useMaterialReactTable({
    columns: columns,
    data: filteredHistories,
    muiPaginationProps: {
      rowsPerPageOptions: [{ value: 10, label: '10' }, { value: 20, label: '20' }, { value: 50, label: '50' }, { value: 100, label: '100' }, { value: filteredHistories.length, label: 'All' }],
    },
    autoResetPageIndex: false,
    enableDensityToggle: true,
    columnFilterDisplayMode: 'subheader',
    enableStickyHeader: true,
    muiTableContainerProps: { sx: { height: '600px' } },

    initialState: { density: 'comfortable', pagination: { pageIndex: 0, pageSize: 20, } },
    enableFullScreenToggle: false,
    enableTopToolbar: false,
    muiTablePaperProps: {
      elevation: 0,
    },

  })

  return (
    <>
      {context.loadingData && <LoadingComponent />}
      <div className='flex flex-col'>
        {/* ----------------------- Create Filter here ----------------------- */}
        <div className='flex flex-row justify-self-center'>
          <Toolbar table={table} context={context} importEnabled={false} setLoadingData={context.setLoadingData} handleEdit={undefined} />
        </div>
        <div className='flex flex-row'>
          <div className='w-screen'>
            <MaterialReactTable table={table} />
          </div>

          <CustomDialogComponent size={'sm'} fullWidth={false} open={context.dataDialog.exportDialog}>
            <ExportTableDialog context={context} table={table} headers={['User', 'Update Time', 'Current Message', 'Previous Message']} data={table.getPaginationRowModel().rows.map((row: any) => {
              const obj = {
                user: row.original.user,
                updateTime: formatTime(row.original.updatedTimestamp),
                // Priority: row.original.itemId.collection_key,
                currentPrompt: row.original.currentPrompt,
                previousMessage: row.original.previousMessage
              }
              return Object.values(obj);

            })} columns={columns} filename='transaction_history' />
          </CustomDialogComponent>
        </div>
      </div>
    </>
  )
};
