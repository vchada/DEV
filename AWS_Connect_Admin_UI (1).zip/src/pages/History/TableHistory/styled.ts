import styled from 'styled-components';

export const ContentCopy = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: 0.5rem;

  &:hover {
    button {
      opacity: 1;
    }
  }

  button {
    opacity: 0;
    padding: 4px;
    min-width: 26px;
    svg {
      font-size: 1rem;
      color: var(--gray-500);
    }
  }
`;
