import { DialogComponent } from '../../components/DialogComponent/DialogComponent';
import { useHistory } from '../../context/History/useHistory';
import { ConfirmationBox } from './ConfirmationBox/ConfirmationBox';
// import { PanelFilterHistory } from './PanelFilter/PanelFilter';
import { TableHistory } from './TableHistory/TableHistory';
import { ContainerHistory } from './styled';

export const History = () => {
  const { dataDialog } = useHistory();
  // const { setDialogHistoryRollback } = dataDialog;

  // const closeDialog = () => {
  //   setDialogHistoryRollback(false);
  // };

  // const openDialog = () => {
  //   setDialogHistoryRollback(true);
  // };

  return (
    <ContainerHistory initial={{opacity: 0}} animate={{opacity: 1}}>
      {/* <PanelFilterHistory /> */}
      <TableHistory/>
      <DialogComponent open={dataDialog.dialogHistoryRollback}>
        <ConfirmationBox />
      </DialogComponent>
    </ContainerHistory>
  );
};
                                                                                                                                                                                              