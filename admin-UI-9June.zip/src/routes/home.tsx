import { getUserInfo } from "../services/session.server";
import { useNavigate } from "react-router";
import { useEffect } from "react";


export default function Index() {
  const navigate = useNavigate();
  useEffect(() => {
      const userId = getUserInfo();
      if (userId) {
        navigate("/gfrDetails")
      } else {
        navigate("/login")
      }
    });

    return (
    <div></div>
    )
}
