import React from 'react';

interface GearMenuIconProps {
  children: React.ReactNode;
}

const GearMenuIcon: React.FC<GearMenuIconProps> = ({ children }) => {
  return (
    <div className='pr-4'>
      {children}
    </div>
  );
}

export default GearMenuIcon;
