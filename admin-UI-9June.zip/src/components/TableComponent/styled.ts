import { Table, TableCell, TableRow as TrMui } from '@mui/material';
import {styled} from 'styled-components';

export const Content = styled.main`
  width: 100%;
  margin-top: 1rem;
  position: relative;
  background-color: var(--white);
  flex: 1;
  max-height: calc(100vh - 300px);
  overflow-x: scroll;
  user-select: none;
`;

export const TableStyled = styled(Table)`
  user-select: text;
  width: 100%;
  position: relative;
  thead {
    top: 0;
    position: sticky;
    background-color: var(--blue-500);
    z-index: 2;

    .content_th {
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: flex-start;
      svg {
        font-size: 1rem;
      }
    }

    .space_th {
      svg {
        color: transparent;
      }
    }
    tr {
      height: 40px;
      z-index: 10;

      th {
        user-select: none;
        min-width: 60px;
        text-align: start;
        padding: 10px 1rem;
        font-size: 0.8rem;
        font-weight: 400;
        color: var(--white);

        &:last-child {
          pointer-events: none;
          width: 40px;
        }
      }
    }
  }
`;

export const TableRow = styled(TrMui)`
  &:hover {
    background-color: var(--gray-100) !important;

    .editTable {
      button {
        background-color: var(--blue-500) !important;
      }
    }
  }
`;

export const TableData = styled(TableCell)`
  font-size: 0.8rem !important;
  max-width: 200px;
  word-wrap: break-word;
  min-width: 120px;

  color: var(--gray-400);

  /* &:nth-child(1) {
    width: 180px;
  }

  &:nth-child(2) {
    max-width: 300px;
  }

  &:nth-child(5) {
    max-width: 140px;
  } */

  .editTable {
    width: 40px;
    display: flex;
    justify-content: center;
    button {
      min-width: 18px;
      width: 22px;
      height: 22px;
      background-color: gray;
      padding: 0.25rem;
      svg {
        font-size: 1rem;
        color: var(--white);
      }

      &:disabled {
        background-color: var(--gray-400) !important;
      }
    }
  }
`;

export const ContentCopy = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: 0.5rem;

  &:hover {
    button {
      opacity: 1;
    }
  }
  button {
    opacity: 0;
    padding: 4px;
    min-width: 26px;
    svg {
      font-size: 1rem;
      color: var(--gray-500);
    }
  }
`;

export const PaginationTable = styled.div`
  width: 100%;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-end;
  gap: 1rem;

  .pagination-part {
    display: flex;
    flex-direction: row;
    align-items: center;
    gap: 1rem;
  }

  span {
    font-size: 0.8rem;
    user-select: none;
    color: var(--gray-300);
  }

  button {
    background-color: var(--blue-500);
    min-width: 20px;
    padding: 2px;
    svg {
      font-size: 1.2rem;
    }
  }

  .btn-back {
    background-color: var(--blue-500);
    padding: 8px 10px;
    letter-spacing: 0.8px;
    line-height: 1.25;
    font-weight: 500;

    &:hover {
      background-color: var(--blue-500);
      opacity: 0.8;
    }
  }

  .MuiInputBase-input {
    font-size: 0.8rem;
    padding: 0.1rem 1rem;
  }
`;
