import {styled} from 'styled-components';

export const ContainerNavigation = styled.header`
  width: 100%;
  height: 70px;
  user-select: none;
  background: #104293;

  .content_nav {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    padding: 0.4rem 1rem;
    height: 100%;


    .MuiButtonBase-root {
      padding: 0 !important;
    }

    .MuiTabs-flexContainer {
      gap: 1rem;
      button {
        color: #ffffff;
        font-size: 0.84rem;

        &:last-child {
          margin-right: 48px;
        }

        &:hover {
          color: #ffffff;
        }
      }
    }

    .Mui-selected {
      color: var(--blue-600) !important;
    }

    .MuiTabs-indicator {
      background-color: var(--blue-600) !important;
    }
  }

  @media (max-width: 550px) {
    .navDesk {
      display: none;
    }
  }
`;
