import { Dialog } from '@mui/material';

interface DialogComponentProps {
  open: boolean;
  children: React.ReactNode;
}

export const DialogComponent = ({ open, children }: DialogComponentProps) => {
  return (
    <Dialog
      fullWidth={true}
      maxWidth={'lg'}
      disableEscapeKeyDown
      open={open}
      aria-labelledby="edit-dialog"
      sx={{
        zIndex: 3,

      }}
    >
      {children}
    </Dialog>
  );
};
