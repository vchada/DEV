import { Dialog } from '@mui/material';

interface DialogComponentProps {
  open: boolean;
  children: React.ReactNode;
}

export const QueueAddEditHOODialogComponent = ({ open, children }: DialogComponentProps) => {
  return (
    <Dialog
      fullWidth={false}
      maxWidth={'lg'}
      open={open}
      disableEscapeKeyDown
      aria-labelledby="edit-dialog"
      sx={{
        zIndex: 3,
        width: '836px',
        height: '624px'


      }}
    >
      {children}
    </Dialog>
  );
};
