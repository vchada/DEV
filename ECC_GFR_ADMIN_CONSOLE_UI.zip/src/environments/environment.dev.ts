export const environment = {
    production: false,
    baseUrl: 'https://eccdv1app11.geico.net:5656'
  };
  