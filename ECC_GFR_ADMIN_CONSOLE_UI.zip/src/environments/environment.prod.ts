export const environment = {
  production: true,
  baseUrl: 'https://eccpd1app21.geico.net:5656'
};