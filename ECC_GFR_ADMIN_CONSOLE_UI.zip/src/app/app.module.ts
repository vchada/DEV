import { BrowserModule } from '@angular/platform-browser';
import { LOCALE_ID, NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {HttpClientModule} from '@angular/common/http';
import {MatTableModule} from '@angular/material/table'
import {
  MatButtonModule, MatDialogModule, MatIconModule, MatInputModule, MatPaginatorModule, MatSortModule,
  MatToolbarModule, MatCardModule, MatProgressSpinnerModule, MatSelectModule, MatAutocompleteModule, MatNativeDateModule, MatSlideToggleModule, MatFormFieldModule, MatMenuModule, MAT_DATE_LOCALE
} from '@angular/material';
import {DataService} from './services/data.service';
import {AddDialogComponent} from './dialogs/add/add.dialog.component';
import {EditDialogComponent} from './dialogs/edit/edit.dialog.component';

import {DeleteDialogComponent} from './dialogs/delete/delete.dialog.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { AppRoutingModule } from './app-routing.module';
import { HomeComponent } from './home/home.component';
import { GfrdetailComponent } from './gfrdetail/gfrdetail.component';
import { AppTagRoutingComponent } from './app-tag-routing/app-tag-routing.component';
import { AppTagRoutingServiceService } from './services/app-tag-routing-service.service';
import { ApptageditComponent } from './dialogs/apptagedit/apptagedit.component';
import { GfrdetaileditComponent } from './dialogs/gfrdetailedit/gfrdetailedit.component';
import { GfrdetailService } from './services/gfrdetail.service';
import { GfrPhoneMappingComponent } from './gfr-phone-mapping/gfr-phone-mapping.component';
import { GfrPhoneMappingService } from './services/gfr-phone-mapping.service';
import { GfrofficehoursComponent } from './gfrofficehours/gfrofficehours.component';
import { GFRCellPhoneOfficeHoursComponent } from './gfrcell-phone-office-hours/gfrcell-phone-office-hours.component';
import { GfrCellPhoneOfficeHoursService } from './services/gfr-cell-phone-office-hours.service';
import { ApptagaddComponent } from './dialogs/apptagadd/apptagadd.component';
import { GfrdetailaddComponent } from './dialogs/gfrdetailadd/gfrdetailadd.component';
import { PhonemapeditComponent } from './dialogs/phonemapedit/phonemapedit.component';
import { PhonemapaddComponent } from './dialogs/phonemapadd/phonemapadd.component';
import { GfrofficehourseditComponent } from './dialogs/gfrofficehoursedit/gfrofficehoursedit.component';
import { GfrofficehoursaddComponent } from './dialogs/gfrofficehoursadd/gfrofficehoursadd.component';
import { GfrcellphoneofficehoursaddComponent } from './dialogs/gfrcellphoneofficehoursadd/gfrcellphoneofficehoursadd.component';
import { GfrcellphoneofficehourseditComponent } from './dialogs/gfrcellphoneofficehoursedit/gfrcellphoneofficehoursedit.component';
import { HeaderComponent } from './header/header.component';
import { AuthService } from './services/auth.service';
import {MatTooltipModule} from '@angular/material/tooltip';
import { GFRTransactionsComponent } from './gfrtransactions/gfrtransactions.component';
import { ScheduleHoursComponent } from './schedule-hours/schedule-hours.component';

import {MatCheckboxModule} from '@angular/material/checkbox';
import { GFRSchedulerComponent } from './gfrscheduler/gfrscheduler.component';
import { GFRScheduleAddComponent } from './dialogs/gfrschedule-add/gfrschedule-add.component';
import { GfrscheduleEditComponent } from './dialogs/gfrschedule-edit/gfrschedule-edit.component';
import { MatMomentDateModule, MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from "@angular/material-moment-adapter";
import { BsDatepickerModule } from 'ngx-bootstrap';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { UploadComponent } from './upload/upload.component';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import { GFRUserComponent } from './gfruser/gfruser.component';
import { GfruseraddComponent } from './dialogs/gfruseradd/gfruseradd.component';
import { GfrusereditComponent } from './dialogs/gfruseredit/gfruseredit.component';
import { SubmitFeedbackComponent } from './submit-feedback/submit-feedback.component';
import { SubmitFeedbackResultDialogComponent } from './submit-feedback/submit-feedback-result-dialog/submit-feedback-result-dialog.component';
import { CommonResultDialogComponent } from './dialogs/common-result-dialog/common-result-dialog.component';
import { NgxSpinnerModule} from 'ngx-spinner';
import { RestrictInputDirective } from './directive/restrict-input.directive';

@NgModule({
  declarations: [
    AppComponent,
    AddDialogComponent,
    EditDialogComponent,
   HeaderComponent,
    DeleteDialogComponent,
    LoginComponent,
    HomeComponent,
    GfrdetailComponent,
    AppTagRoutingComponent,
    ApptageditComponent,
    GfrdetaileditComponent,
    GfrPhoneMappingComponent,
    GfrofficehoursComponent,
    GFRCellPhoneOfficeHoursComponent,
    ApptagaddComponent,
    GfrdetailaddComponent,
    PhonemapeditComponent,
    PhonemapaddComponent,
    GfrofficehourseditComponent,
    GfrofficehoursaddComponent,
    GfrcellphoneofficehoursaddComponent,
    GfrcellphoneofficehourseditComponent,
    GFRTransactionsComponent,
    ScheduleHoursComponent,
    GFRSchedulerComponent,
    GFRScheduleAddComponent,
    GfrscheduleEditComponent,
    UploadComponent,
    GFRUserComponent,
    GfruseraddComponent,
    GfrusereditComponent,
    SubmitFeedbackComponent,
    SubmitFeedbackResultDialogComponent,
    CommonResultDialogComponent,
    RestrictInputDirective
  ],
  imports: [
    
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    MatDialogModule,
    FormsModule,
    MatButtonModule,
    MatInputModule,
    MatMenuModule,
    MatIconModule,
    MatSortModule,
    MatTableModule,
    MatToolbarModule,
    MatPaginatorModule,
    MatSlideToggleModule,    
    MatFormFieldModule,
    ReactiveFormsModule,
    MatCardModule,
    MatProgressSpinnerModule,
    MatAutocompleteModule,
    MatSelectModule,
    AppRoutingModule,
    MatTooltipModule,MatDatepickerModule,MatNativeDateModule,MatCheckboxModule,MatMomentDateModule, BsDatepickerModule.forRoot(),
    TimepickerModule.forRoot(),
    MatProgressBarModule,
    NgxSpinnerModule

   
  ],
  entryComponents: [
    AddDialogComponent,
    EditDialogComponent,
    DeleteDialogComponent,
    ApptageditComponent,
    GfrdetaileditComponent,
    ApptagaddComponent,
    GfrdetailaddComponent,
    PhonemapeditComponent,
    PhonemapaddComponent,
    GfrofficehourseditComponent,
    GfrofficehoursaddComponent,
    GfrcellphoneofficehoursaddComponent,
    GfrcellphoneofficehourseditComponent,
    GFRScheduleAddComponent,
    GfrscheduleEditComponent,
    UploadComponent,
    GfruseraddComponent,
    GfrusereditComponent,
    SubmitFeedbackResultDialogComponent,
    CommonResultDialogComponent
  ],
  providers: [
    DataService,
    AppTagRoutingServiceService,
    GfrdetailService,
    GfrPhoneMappingService,
    GfrCellPhoneOfficeHoursService,
    AuthService,
    {provide: MAT_DATE_LOCALE, useValue: 'en-US'},
    {provide: LOCALE_ID, useValue: 'en-US' },
    {provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: {useUtc: true}}
    
  ],
  exports: [RestrictInputDirective],
  bootstrap: [AppComponent]
})
export class AppModule { }
