import { Component, OnInit, } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { User } from '../models/User';
import { reserveSlots } from '@angular/core/src/render3/instructions';
import { Router } from '@angular/router';

export interface Link {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  isLoggedIn$: Observable<boolean>;
 
  userData: User;
  

  links: Link[] ;


  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit() {

    this.isLoggedIn$ = this.authService.isLoggedIn;
    this.authService.user.subscribe(user =>{
      this.userData = user;
      if(this.userData && this.userData.userName) {
        this.authService.verifyUser(user.userName.trim()).subscribe((res) => {
          if(res){
            this.authService.admin.subscribe(result =>{
              this.links=result;
              if(!this.links.find(item => item.value === 'gfruser')) {
                this.links.push({
                  value: 'gfruser',
                  viewValue: 'GFR User'
                })          
              }
            })
          }else {
            this.authService.gfr.subscribe(result => {
              this.links=result;
            })
          }
        })
      }
    })
    this.isLoggedIn$.subscribe(val => console.log(val));
    

  }

  submitFeedback() {
    this.router.navigate(['submitfeedback'])
  }

  goToHome() {
    this.router.navigate(['gfrdetail'])
  }

  onLogout() {
   
    this.authService.logout();  
    //location.reload();                    // {3}
  }

}
