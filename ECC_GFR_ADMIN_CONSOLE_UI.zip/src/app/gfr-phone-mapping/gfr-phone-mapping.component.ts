import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { MatDialog, MatPaginator, MatSort } from '@angular/material';
import { Issue } from '../models/issue';
import { DataSource } from '@angular/cdk/collections';
import { AddDialogComponent } from '../dialogs/add/add.dialog.component';
import { EditDialogComponent } from '../dialogs/edit/edit.dialog.component';
import { DeleteDialogComponent } from '../dialogs/delete/delete.dialog.component';
import { BehaviorSubject, fromEvent, merge, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { GFRPhoneMapping } from '../models/GFRPhoneMapping';
import { GfrPhoneMappingService } from '../services/gfr-phone-mapping.service';
import { PhonemapeditComponent } from '../dialogs/phonemapedit/phonemapedit.component';
import { PhonemapaddComponent } from '../dialogs/phonemapadd/phonemapadd.component';
import { AuthService } from '../services/auth.service';
import { User } from '../models/User';
import { UploadComponent } from '../upload/upload.component';

@Component({
  selector: 'app-gfr-phone-mapping',
  templateUrl: './gfr-phone-mapping.component.html',
  styleUrls: ['./gfr-phone-mapping.component.css']
})
export class GfrPhoneMappingComponent implements OnInit {

  displayedColumns = ['masterId', 'gfrid', 'phoneNumber', 'gfrDrNum','actions'];
  exampleDatabase: GfrPhoneMappingService | null;
  dataSource: ExampleDataSource | null;
  index: number;
  masterId: string;
  mask: any[] = ['+', '1', ' ', '(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  username: any;
  user: User;
  searchField: string;

  constructor(public httpClient: HttpClient,
    public dialog: MatDialog,
    public gfrphoneservice: GfrPhoneMappingService,private authService:AuthService) { }

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('filter') filter: ElementRef;

  ngOnInit() {
    this.loadData();
    this.authService.user.subscribe(user =>this.user = user)
  }

  refresh() {
    this.loadData();
  }
  clearSearchField() {
    this.searchField = '';
    this.loadData();
  }
  upload() {
    const dialogRef = this.dialog.open(UploadComponent,{
      width: '500px',
      data: {name: 'GfrPhoneMapping'}
    });
    dialogRef.afterClosed().subscribe(result =>  {
      this.refresh();
    });
  }

  addNew(gfrphoneMapping: GFRPhoneMapping) {
    const dialogRef = this.dialog.open(PhonemapaddComponent, {
      data: {gfrphoneMapping: gfrphoneMapping }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        // After dialog is closed we're doing frontend updates
        // For add we're just pushing a new row inside DataService
        this.exampleDatabase.dataChange.value.push(this.gfrphoneservice.getDialogData());
        this.refreshTable();
      }
    });
  }
  startEdit(i: number,masterId: string, gfrid: string,
     phoneNumber: string) {
    this.masterId = masterId;
    // index row is used just for debugging proposes and can be removed
    this.index = i;
    
    console.log(this.index);
    const dialogRef = this.dialog.open(PhonemapeditComponent, {
      data: {
        masterId: masterId, gfrid: gfrid, phoneNumber: phoneNumber,lastModifiedUser:this.user.userName
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        // When using an edit things are little different, firstly we find record inside DataService by id
        const foundIndex = this.exampleDatabase.dataChange.value.findIndex(x => x.masterId === this.masterId);
        // Then you update that record using data from dialogData (values you enetered)
        this.exampleDatabase.dataChange.value[foundIndex] = this.gfrphoneservice.getDialogData();
        // And lastly refresh table
        this.refreshTable();
        this.refresh();
      }
    });
  }
  private refreshTable() {
    // Refreshing table using paginator
    // Thanks yeager-j for tips
    // https://github.com/marinantonio/angular-mat-table-crud/issues/12
    this.paginator._changePageSize(this.paginator.pageSize);
  }




  public loadData() {
    this.exampleDatabase = new GfrPhoneMappingService(this.httpClient,this.authService);
    this.dataSource = new ExampleDataSource(this.exampleDatabase, this.paginator, this.sort);
    fromEvent(this.filter.nativeElement, 'keyup')
      // .debounceTime(150)
      // .distinctUntilChanged()
      .subscribe(() => {
        if (!this.dataSource) {
          return;
        }
        this.dataSource.filter = this.filter.nativeElement.value;
      });
  }
}

export class ExampleDataSource extends DataSource<GFRPhoneMapping> {
  _filterChange = new BehaviorSubject('');

  get filter(): string {
    return this._filterChange.value;
  }

  set filter(filter: string) {
    this._filterChange.next(filter);
  }

  filteredData: GFRPhoneMapping[] = [];
  renderedData: GFRPhoneMapping[] = [];

  constructor(public _exampleDatabase: GfrPhoneMappingService,
    public _paginator: MatPaginator,
    public _sort: MatSort) {
    super();
    // Reset to the first page when the user changes the filter.
    this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
  }

  /** Connect function called by the table to retrieve one stream containing the data to render. */
  connect(): Observable<GFRPhoneMapping[]> {
    // Listen for any changes in the base data, sorting, filtering, or pagination
    const displayDataChanges = [
      this._exampleDatabase.dataChange,
      this._sort.sortChange,
      this._filterChange,
      this._paginator.page
    ];

    this._exampleDatabase.getGFRPhoneMappingDetails();


    return merge(...displayDataChanges).pipe(map(() => {
      // Filter data
      this.filteredData = this._exampleDatabase.data.slice().filter((gfrphoneMapping: GFRPhoneMapping) => {
        const searchStr = (gfrphoneMapping.masterId + gfrphoneMapping.gfrid + gfrphoneMapping.phoneNumber+gfrphoneMapping.gfrDrNum).toLowerCase();
        return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
      });

      // Sort filtered data
      const sortedData = this.sortData(this.filteredData.slice());

      // Grab the page's slice of the filtered sorted data.
      const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
      this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
      return this.renderedData;
    }
    ));
  }

  disconnect() { }


  /** Returns a sorted copy of the database data. */
  sortData(data: GFRPhoneMapping[]): GFRPhoneMapping[] {
    if (!this._sort.active || this._sort.direction === '') {
      return data;
    }

    return data.sort((a, b) => {
      let propertyA: number | string = '';
      let propertyB: number | string = '';

      switch (this._sort.active) {
        case 'masterId': [propertyA, propertyB] = [a.masterId, b.masterId]; break;
        case 'gfrid': [propertyA, propertyB] = [a.gfrid, b.gfrid]; break;
        case 'phoneNumber': [propertyA, propertyB] = [a.phoneNumber, b.phoneNumber]; break;
        case 'gfrDrNum': [propertyA, propertyB] = [a.gfrDrNum, b.gfrDrNum]; break;

      }

      const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
      const valueB = isNaN(+propertyB) ? propertyB : +propertyB;

      return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'asc' ? 1 : -1);
    });
  }
}

