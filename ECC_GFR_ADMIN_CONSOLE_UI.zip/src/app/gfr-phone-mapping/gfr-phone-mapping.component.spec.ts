import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GfrPhoneMappingComponent } from './gfr-phone-mapping.component';

describe('GfrPhoneMappingComponent', () => {
  let component: GfrPhoneMappingComponent;
  let fixture: ComponentFixture<GfrPhoneMappingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GfrPhoneMappingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GfrPhoneMappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
