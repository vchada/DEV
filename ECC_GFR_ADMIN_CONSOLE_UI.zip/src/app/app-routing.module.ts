import { NgModule, Component } from '@angular/core';

import { RouterModule, Routes } from '@angular/router';

import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { GfrdetailComponent } from './gfrdetail/gfrdetail.component';
import { AppTagRoutingComponent } from './app-tag-routing/app-tag-routing.component';
import { GfrPhoneMappingComponent } from './gfr-phone-mapping/gfr-phone-mapping.component';
import { GfrofficehoursComponent } from './gfrofficehours/gfrofficehours.component';
import { GFRCellPhoneOfficeHoursComponent } from './gfrcell-phone-office-hours/gfrcell-phone-office-hours.component';
import { AuthGuard } from './auth.guard';
import { GFRTransactionsComponent } from './gfrtransactions/gfrtransactions.component';
import { ScheduleHoursComponent } from './schedule-hours/schedule-hours.component';
import { GFRSchedulerComponent } from './gfrscheduler/gfrscheduler.component';
import { GFRUserComponent } from './gfruser/gfruser.component';
import { SubmitFeedbackComponent } from './submit-feedback/submit-feedback.component';


const routes: Routes = [
  //{ path: 'home', component: HomeComponent },
  
  { path: 'gfrdetail', component: GfrdetailComponent,canActivate: [AuthGuard] },
  { path: 'apptagrouting', component: AppTagRoutingComponent,canActivate: [AuthGuard] },
  { path: 'gfrphonemapping', component: GfrPhoneMappingComponent,canActivate: [AuthGuard] },
  { path: 'gfrofficehours', component: GfrofficehoursComponent,canActivate: [AuthGuard] },
  { path: 'gfrcellhours', component: GFRCellPhoneOfficeHoursComponent,canActivate: [AuthGuard] },
  { path: 'gfrtransactions', component: GFRTransactionsComponent,canActivate: [AuthGuard] },
  { path: 'scheduleHours', component: GFRSchedulerComponent,canActivate: [AuthGuard] },
  { path: 'gfruser', component: GFRUserComponent,canActivate: [AuthGuard] },
  { path: 'submitfeedback', component: SubmitFeedbackComponent,canActivate: [AuthGuard] },
  
  { path: 'login',component:LoginComponent},
  { path: '',redirectTo: '/login', pathMatch: 'full'},
  { path: '**', redirectTo: '/login', pathMatch: 'full'}
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]

})
export class AppRoutingModule { }
