import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { GfrPhoneMappingService } from '../../services/gfr-phone-mapping.service';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-phonemapedit',
  templateUrl: './phonemapedit.component.html',
  styleUrls: ['./phonemapedit.component.css']
})
export class PhonemapeditComponent {


  constructor(public dialogRef: MatDialogRef<PhonemapeditComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, public dataService: GfrPhoneMappingService) { 
      console.log(data);
    }
    formControl = new FormControl('', [
      Validators.required
      // Validators.email,
    ]);
  
    getErrorMessage() {
      return this.formControl.hasError('required') ? 'Required field' :
        //this.formControl.hasError('phoneNumber') ? 'Phone Number should not exceed 10 digits' :
          '';
    }
  
    submit() {
      // emppty stuff
    }
  
    onNoClick(): void {
      this.dialogRef.close();
    }
  
    stopEdit(): void {
      this.dataService.updateItem(this.data);
    }
}
