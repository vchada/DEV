import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PhonemapeditComponent } from './phonemapedit.component';

describe('PhonemapeditComponent', () => {
  let component: PhonemapeditComponent;
  let fixture: ComponentFixture<PhonemapeditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PhonemapeditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhonemapeditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
