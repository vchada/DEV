import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GfrcellphoneofficehourseditComponent } from './gfrcellphoneofficehoursedit.component';

describe('GfrcellphoneofficehourseditComponent', () => {
  let component: GfrcellphoneofficehourseditComponent;
  let fixture: ComponentFixture<GfrcellphoneofficehourseditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GfrcellphoneofficehourseditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GfrcellphoneofficehourseditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
