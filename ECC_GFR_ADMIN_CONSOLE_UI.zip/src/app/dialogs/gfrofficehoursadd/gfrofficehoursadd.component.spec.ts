import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GfrofficehoursaddComponent } from './gfrofficehoursadd.component';

describe('GfrofficehoursaddComponent', () => {
  let component: GfrofficehoursaddComponent;
  let fixture: ComponentFixture<GfrofficehoursaddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GfrofficehoursaddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GfrofficehoursaddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
