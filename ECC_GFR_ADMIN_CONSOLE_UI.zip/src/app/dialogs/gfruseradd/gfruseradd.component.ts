import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { GfrUserService } from '../../services/gfr-user.service';
import { GfrusereditComponent } from '../gfruseredit/gfruseredit.component';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonResultDialogComponent } from '../common-result-dialog/common-result-dialog.component';

@Component({
  selector: 'app-gfruseradd',
  templateUrl: './gfruseradd.component.html',
  styleUrls: ['./gfruseradd.component.css']
})
export class GfruseraddComponent implements OnInit {

  editForm: FormGroup;
  
  isAdmin = false;

  constructor(public dialogRef: MatDialogRef<GfrusereditComponent>, private gfrUserService: GfrUserService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialog: MatDialog,
    private spinner: NgxSpinnerService) { 
      console.log(data);
    }

    ngOnInit() {
      this.editForm = new FormGroup({
        gfrId: new FormControl('', Validators.required),
        gfrName: new FormControl(''),
        createdUser: new FormControl({value: this.gfrUserService.userData.userName, disabled: true}),
        createdDtTm: new FormControl(null),
        lastModifiedUser: new FormControl({value: this.gfrUserService.userData.userName, disabled: true}),
        lastModifiedDtTm: new FormControl(null),
        userId: new FormControl('', Validators.required),
        userName: new FormControl('', Validators.required),
        email: new FormControl('', [Validators.required, Validators.email])
      });
    }

    changeIsAdminToggle(evt) {
      this.isAdmin = evt.checked;
    }

    validateUserId() {
      if(this.editForm.value.userId) {
        this.spinner.show();
        this.gfrUserService.validateGfrUserId(this.editForm.value.userId).subscribe((value: any) => {
          if(value) {
            this.editForm.patchValue({
              userName: value.userName,
              email: value.email
            })
          }
          this.spinner.hide();
        }, err => {
          const dialogRef = this.dialog.open(CommonResultDialogComponent, {
            width: '450px',
            data: {
              headerText: 'Error',
              msgText: 'User Not found in Active Directory.'
            }
          });
      
          dialogRef.afterClosed().subscribe(result => {
          });
          this.spinner.hide();
        });
      }
    }
  
    submit() {
      const userData = this.editForm.value;
      userData.userId = userData.userId.toUpperCase();
      userData['isAdmin'] = this.isAdmin ? 'TRUE': 'FALSE';
      userData.createdUser = this.gfrUserService.userData.userName;
      userData.lastModifiedUser = this.gfrUserService.userData.userName;
      this.gfrUserService.createGfrUser(userData).subscribe((data) => {
        if(data) {        
          this.dialogRef.close({status: 'success'});
        }
      }, err => {
        console.log(err);
      });
    }
  
    onNoClick(): void {
      this.dialogRef.close();
    }


}
