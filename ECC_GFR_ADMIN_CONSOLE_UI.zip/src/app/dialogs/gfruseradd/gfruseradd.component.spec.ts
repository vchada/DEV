import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GfruseraddComponent } from './gfruseradd.component';

describe('GfruseraddComponent', () => {
  let component: GfruseraddComponent;
  let fixture: ComponentFixture<GfruseraddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GfruseraddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GfruseraddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
