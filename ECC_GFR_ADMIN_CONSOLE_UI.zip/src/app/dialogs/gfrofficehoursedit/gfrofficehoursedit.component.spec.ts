import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GfrofficehourseditComponent } from './gfrofficehoursedit.component';

describe('GfrofficehourseditComponent', () => {
  let component: GfrofficehourseditComponent;
  let fixture: ComponentFixture<GfrofficehourseditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GfrofficehourseditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GfrofficehourseditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
