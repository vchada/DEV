import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AppTagRouting } from '../../models/AppTagRouting';
import { AppTagRoutingServiceService } from '../../services/app-tag-routing-service.service';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-apptagadd',
  templateUrl: './apptagadd.component.html',
  styleUrls: ['./apptagadd.component.css']
})
export class ApptagaddComponent {
  constructor(public dialogRef: MatDialogRef<ApptagaddComponent>,
    @Inject(MAT_DIALOG_DATA) public data: AppTagRouting,
    public dataService: AppTagRoutingServiceService) { }

  formControl = new FormControl('', [
    Validators.required
    // Validators.email,
  ]);

  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
     // this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }

  submit() {
    // emppty stuff
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  public confirmAdd(): void {
    this.dataService.addItem(this.data);
  }
}


