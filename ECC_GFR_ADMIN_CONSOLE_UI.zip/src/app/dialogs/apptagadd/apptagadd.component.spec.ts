import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApptagaddComponent } from './apptagadd.component';

describe('ApptagaddComponent', () => {
  let component: ApptagaddComponent;
  let fixture: ComponentFixture<ApptagaddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApptagaddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApptagaddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
