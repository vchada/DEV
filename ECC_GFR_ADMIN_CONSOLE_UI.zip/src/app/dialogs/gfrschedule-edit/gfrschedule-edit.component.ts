import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { GFRSchedulerService } from '../../services/gfrscheduler.service';
import { FormControl, Validators } from '@angular/forms';
import { GFRInfo } from '../../models/GFRInfo';

@Component({
  selector: 'app-gfrschedule-edit',
  templateUrl: './gfrschedule-edit.component.html',
  styleUrls: ['./gfrschedule-edit.component.css']
})
export class GfrscheduleEditComponent  {
  gfrInfo:GFRInfo[];
  effectiveMinDate: Date;
 // expiryMinDate: Date;
  constructor(public dialogRef: MatDialogRef<GfrscheduleEditComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, public dataService: GFRSchedulerService) {
      this.effectiveMinDate = new Date();
   // this.expiryMinDate = new Date();
    this.effectiveMinDate.setDate(this.effectiveMinDate.getDate());
    /* this.expiryMinDate.setDate(this.effectiveMinDate.getDate()) */
     }
    formControl = new FormControl('', [
      Validators.required
      // Validators.email,
    ]);
    timeData = [' ','12:00 AM','12:30 AM','1:00 AM','1:30 AM','2:00 AM','2:30 AM','3:00 AM','3:30 AM','4:00 AM','4:30 AM','5:00 AM','5:30 AM','6:00 AM','6:30 AM','7:00 AM','7:30 AM','8:00 AM','8:30 AM','9:00 AM','9:30 AM','10:00 AM','10:30 AM','11:00 AM','11:30 AM',
    '12:00 PM','12:30 PM','1:00 PM','1:30 PM','2:00 PM','2:30 PM','3:00 PM','3:30 PM','4:00 PM','4:30 PM','5:00 PM','5:30 PM','6:00 PM','6:30 PM','7:00 PM','7:30 PM','8:00 PM','8:30 PM','9:00 PM','9:30 PM','10:00 PM','10:30 PM','11:00 PM','11:30 PM','11:59 PM' ];
    median = 'AM'
    ngOnInit() {
     // let gfrTemp: GFRInfo[] = [];
      this.dataService.getGFRInfo();
      this.dataService.gfr.subscribe(gfrInfo =>
        this.gfrInfo =gfrInfo);
      /*  gfrInfo.forEach(function (value) {
        value.gfr = value.gfrName + "-" + value.gfrLocation;
        console.log("==", value.gfr)
        gfrTemp.push(value);
      })

    );
    this.gfrInfo = gfrTemp; */
      //this.setTime();
    }
  
    setTime(isTimeValid?: boolean): void {
      let isValid = isTimeValid;
    
      for (let i = 1; i <= 12; i++) {
        for (let j = 0; j < 60; j = j + 30) {
          const time = (i) + ':' + (j < 10 ? ('0' + j) : j) + ' ' + this.median;
          if (i === 12 && j === 0) {
            this.median = this.median === 'AM' ? 'PM' : 'AM';
          }
          this.timeData.push(time);
          if (i === 12 && j === 30 && this.median === 'PM') {
            this.setTime(true);
          }
        }
      }
    }
  
    getErrorMessage() {
      return this.formControl.hasError('required') ? 'Required field' :
        //this.formControl.hasError('phoneNumber') ? 'Phone Number should not exceed 10 digits' :
          '';
    }
  
    submit() {
      // emppty stuff
    }
  
    onNoClick(): void {
      this.dialogRef.close();
    }
  
    stopEdit(): void {
      console.log("Updated ==",this.data.effectiveDate)
      //console.log("Updated ==",this.data.effectiveDate.getFullYear(),this.data.effectiveDate.getUTCDate(),this.data.effectiveDate.getMonth()+1);
      
      this.dataService.updateItem(this.data);
      
    }

}
