import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonResultDialogComponent } from './common-result-dialog.component';

describe('CommonResultDialogComponent', () => {
  let component: CommonResultDialogComponent;
  let fixture: ComponentFixture<CommonResultDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonResultDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonResultDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
