import { Component, Inject, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";

@Component({
  selector: 'app-common-result-dialog',
  templateUrl: './common-result-dialog.component.html',
  styleUrls: ['./common-result-dialog.component.css']
})
export class CommonResultDialogComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<CommonResultDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit() {
    
  }
  
  close() {
    this.dialogRef.close();
  }
}