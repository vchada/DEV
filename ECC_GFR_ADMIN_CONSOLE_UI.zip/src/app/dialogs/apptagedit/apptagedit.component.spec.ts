import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApptageditComponent } from './apptagedit.component';

describe('ApptageditComponent', () => {
  let component: ApptageditComponent;
  let fixture: ComponentFixture<ApptageditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApptageditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApptageditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
