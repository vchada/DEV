import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { GFRCellPhoneOfficeHours } from '../../models/GFRCellPhoneOfficeHours';
import { GfrCellPhoneOfficeHoursService } from '../../services/gfr-cell-phone-office-hours.service';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-gfrcellphoneofficehoursadd',
  templateUrl: './gfrcellphoneofficehoursadd.component.html',
  styleUrls: ['./gfrcellphoneofficehoursadd.component.css']
})
export class GfrcellphoneofficehoursaddComponent implements OnInit {
  timeData = [' ','12:00 AM','12:30 AM','1:00 AM','1:30 AM','2:00 AM','2:30 AM','3:00 AM','3:30 AM','4:00 AM','4:30 AM','5:00 AM','5:30 AM','6:00 AM','6:30 AM','7:00 AM','7:30 AM','8:00 AM','8:30 AM','9:00 AM','9:30 AM','10:00 AM','10:30 AM','11:00 AM','11:30 AM',
                  '12:00 PM','12:30 PM','1:00 PM','1:30 PM','2:00 PM','2:30 PM','3:00 PM','3:30 PM','4:00 PM','4:30 PM','5:00 PM','5:30 PM','6:00 PM','6:30 PM','7:00 PM','7:30 PM','8:00 PM','8:30 PM','9:00 PM','9:30 PM','10:00 PM','10:30 PM','11:00 PM','11:30 PM','11:59 PM' ];
  
  median = 'AM';
  constructor(public dialogRef: MatDialogRef<GfrcellphoneofficehoursaddComponent>,
    @Inject(MAT_DIALOG_DATA) public data: GFRCellPhoneOfficeHours,
    public dataService: GfrCellPhoneOfficeHoursService) { }

  formControl = new FormControl('', [
    Validators.required
    // Validators.email,
  ]);

  ngOnInit() {
   // this.setTime();
  }

  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
      // this.formControl.hasError('email') ? 'Not a valid email' :
      '';
  }

  submit() {
    // emppty stuff
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  public confirmAdd(): void {
    this.dataService.addItem(this.data);
  }

  checkRange(e) {
    if (this.data.gfrid && this.data.gfrid.length >= 5) {
      e.preventDefault();
    }
  }

  setTime(isTimeValid?: boolean): void {
    let isValid = isTimeValid;
	
    for (let i = 1; i <= 12; i++) {
      for (let j = 0; j < 60; j = j + 30) {
        const time = (i) + ':' + (j < 10 ? ('0' + j) : j) + ' ' + this.median;
        if (i === 12 && j === 0) {
          this.median = this.median === 'AM' ? 'PM' : 'AM';
        }
        
        if(i === 11 && j===30 && this.median === 'PM') {
          this.timeData.push("11:30 PM");
          this.timeData.push("11:59 PM");
          
        }
        else {
          this.timeData.push(time);
        }
        if (i === 12 && j === 30 && this.median === 'PM') {
          console.log("in set time")
          this.setTime(true);
        }
      }
    }
  }

}
