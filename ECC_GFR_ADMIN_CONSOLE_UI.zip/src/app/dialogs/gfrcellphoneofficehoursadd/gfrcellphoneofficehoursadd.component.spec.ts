import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GfrcellphoneofficehoursaddComponent } from './gfrcellphoneofficehoursadd.component';

describe('GfrcellphoneofficehoursaddComponent', () => {
  let component: GfrcellphoneofficehoursaddComponent;
  let fixture: ComponentFixture<GfrcellphoneofficehoursaddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GfrcellphoneofficehoursaddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GfrcellphoneofficehoursaddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
