import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GFRScheduleAddComponent } from './gfrschedule-add.component';

describe('GFRScheduleAddComponent', () => {
  let component: GFRScheduleAddComponent;
  let fixture: ComponentFixture<GFRScheduleAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GFRScheduleAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GFRScheduleAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
