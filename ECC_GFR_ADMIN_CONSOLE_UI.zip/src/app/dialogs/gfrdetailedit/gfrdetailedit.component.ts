import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {Component, Inject} from '@angular/core';

import {FormControl, Validators} from '@angular/forms';

import { GfrdetailService } from '../../services/gfrdetail.service';

@Component({
  selector: 'app-gfrdetailedit',
  templateUrl: './gfrdetailedit.component.html',
  styleUrls: ['./gfrdetailedit.component.css']
})
export class GfrdetaileditComponent  {
  options: string[] = ['Y', 'N'];
  tzones: string[] = [
    'America/New_York',
    'America/Chicago',
    'America/Denver',
    'America/Phoenix',
    'America/Los_Angeles',
    'America/Anchorage',
    'Pacific/Honolulu'];

  constructor(public dialogRef: MatDialogRef<GfrdetaileditComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, public dataService: GfrdetailService) { 
      console.log(data);
    }
    formControl = new FormControl('', [
      Validators.required
      // Validators.email,
    ]);
  
    getErrorMessage() {
      return this.formControl.hasError('required') ? 'Required field' :
        //this.formControl.hasError('phoneNumber') ? 'Phone Number should not exceed 10 digits' :
          '';
    }
  
    submit() {
      // emppty stuff
    }
  
    onNoClick(): void {
      this.dialogRef.close();
    }
  
    stopEdit(): void {
      this.dataService.updateItem(this.data);
    }

    checkRange(e, range, field) {
      if (this.data[field] && this.data[field].length >= range) {
        e.preventDefault();
      }
    }
 
}
