import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { GFRPhoneMapping } from '../../models/GFRPhoneMapping';
import { GfrPhoneMappingService } from '../../services/gfr-phone-mapping.service';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-phonemapadd',
  templateUrl: './phonemapadd.component.html',
  styleUrls: ['./phonemapadd.component.css']
})
export class PhonemapaddComponent  {
  constructor(public dialogRef: MatDialogRef<PhonemapaddComponent>,
    @Inject(MAT_DIALOG_DATA) public data: GFRPhoneMapping,
    public dataService: GfrPhoneMappingService) { }

  formControl = new FormControl('', [
    Validators.required
    // Validators.email,
  ]);

  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
     // this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }

  submit() {
    // emppty stuff
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  public confirmAdd(): void {
    this.dataService.addItem(this.data);
  }
}
