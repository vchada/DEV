import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PhonemapaddComponent } from './phonemapadd.component';

describe('PhonemapaddComponent', () => {
  let component: PhonemapaddComponent;
  let fixture: ComponentFixture<PhonemapaddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PhonemapaddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhonemapaddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
