import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { GfrUserService } from '../../services/gfr-user.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-gfruseredit',
  templateUrl: './gfruseredit.component.html',
  styleUrls: ['./gfruseredit.component.css']
})
export class GfrusereditComponent implements OnInit {
  
  editForm: FormGroup;
  
  isAdmin = false;

  constructor(public dialogRef: MatDialogRef<GfrusereditComponent>, private gfrUserService: GfrUserService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private spinner: NgxSpinnerService) { 
      console.log(data);
    }

    ngOnInit() {
      this.editForm = new FormGroup({
        gfrId: new FormControl(this.data.gfrId, Validators.required),
        gfrName: new FormControl(this.data.gfrName),
        createdUser: new FormControl({value: this.data.createdUser, disabled: this.data.createdUser ? true: false}),
        createdDtTm: new FormControl({value: this.data.createdDtTm, disabled: this.data.createdDtTm ? true: false}),
        lastModifiedUser: new FormControl(null),
        lastModifiedDtTm: new FormControl(null),
        userId: new FormControl(this.data.userId, Validators.required),
        userName: new FormControl(this.data.userName, Validators.required),
        email: new FormControl(this.data.email, [Validators.required, Validators.email])
      });
      this.isAdmin = this.data.isAdmin === 'TRUE' ? true: false;
    }

    validateUserId() {
      if(this.editForm.value.userId) {
        this.spinner.show();
        this.gfrUserService.validateGfrUserId(this.editForm.value.userId).subscribe((value: any) => {
          if(value) {
            this.editForm.patchValue({
              userName: value.userName,
              email: value.email
            })
          }
          this.spinner.hide();
        }, err => {
          this.spinner.hide();
        });
      }
    }

    changeIsAdminToggle(evt) {
      this.isAdmin = evt.checked;
    }
  
    submit() {
      const userData = this.editForm.value;
      userData.userId = userData.userId.toUpperCase();
      userData['isAdmin'] = this.isAdmin ? 'TRUE': 'FALSE';
      userData.lastModifiedUser = this.gfrUserService.userData.userName;
      this.gfrUserService.editGfrUser(userData).subscribe((data) => {
        if(data) {
          this.dialogRef.close({status: 'success'});
        }
      }, (err) => {
        console.log(err)
      });
    }
  
    onNoClick(): void {
      this.dialogRef.close();
    }

    

}
