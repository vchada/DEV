import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GfrdetailaddComponent } from './gfrdetailadd.component';

describe('GfrdetailaddComponent', () => {
  let component: GfrdetailaddComponent;
  let fixture: ComponentFixture<GfrdetailaddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GfrdetailaddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GfrdetailaddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
