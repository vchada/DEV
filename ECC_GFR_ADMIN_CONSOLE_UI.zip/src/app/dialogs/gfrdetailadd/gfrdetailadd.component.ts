import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { GFRDetail } from '../../models/GFRDetail';
import { GfrdetailService } from '../../services/gfrdetail.service';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-gfrdetailadd',
  templateUrl: './gfrdetailadd.component.html',
  styleUrls: ['./gfrdetailadd.component.css']
})
export class GfrdetailaddComponent  {
  options: string[] = ['Y', 'N'];
  tzones: string[] = [
    'America/New_York',
    'America/Chicago',
    'America/Denver',
    'America/Phoenix',
    'America/Los_Angeles',
    'America/Anchorage',
    'Pacific/Honolulu'];

  constructor(public dialogRef: MatDialogRef<GfrdetailaddComponent>,
    @Inject(MAT_DIALOG_DATA) public data: GFRDetail,
    public dataService: GfrdetailService) {
     
     }

  formControl = new FormControl('', [
    Validators.required
    // Validators.email,
  ]);

  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
     // this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }

  submit() {
    // emppty stuff
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  public confirmAdd(): void {
   
    this.dataService.addItem(this.data);
  }

  checkRange(e, range, field) {
    if (this.data[field] && this.data[field].length >= range) {
      e.preventDefault();
    }
  }
}
