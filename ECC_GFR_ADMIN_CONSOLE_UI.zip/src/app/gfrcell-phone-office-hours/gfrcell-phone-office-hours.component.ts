import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { GfrCellPhoneOfficeHoursService } from '../services/gfr-cell-phone-office-hours.service';
import { GFRCellPhoneOfficeHours } from '../models/GFRCellPhoneOfficeHours';
import { merge, Observable, BehaviorSubject, fromEvent } from 'rxjs';
import { map } from 'rxjs/operators';
import { MatSort, MatPaginator, MatDialog } from '@angular/material';
import { DataSource } from '@angular/cdk/table';
import { HttpClient } from '@angular/common/http';
import { GfrcellphoneofficehoursaddComponent } from '../dialogs/gfrcellphoneofficehoursadd/gfrcellphoneofficehoursadd.component';
import { GfrcellphoneofficehourseditComponent } from '../dialogs/gfrcellphoneofficehoursedit/gfrcellphoneofficehoursedit.component';
import { AuthService } from '../services/auth.service';
import { User } from '../models/User';
import { UploadComponent } from '../upload/upload.component';

@Component({
  selector: 'app-gfrcell-phone-office-hours',
  templateUrl: './gfrcell-phone-office-hours.component.html',
  styleUrls: ['./gfrcell-phone-office-hours.component.css']
})
export class GFRCellPhoneOfficeHoursComponent implements OnInit {
  displayedColumns = [
    'gfrid',
    'gfrName',
    'gfrSiteCode',
    'gfrLocation',
    'mondayOpen',
    'mondayClose',
    'tuesdayOpen',
    'tuesdayClose',
    'wednesdayOpen',
    'wednesdayClose',
    'thursdayOpen',
    'thursdayClose',
    'fridayOpen',
    'fridayClose',
    'saturdayOpen',
    'saturdayClose',
    'sundayOpen',
    'sundayClose',
    'comments',
    'actions'
  ];
  index: number;
  gfrid: string;
  exampleDatabase: GfrCellPhoneOfficeHoursService | null;
  dataSource: ExampleDataSource | null;
  mask: any[] = ['+', '1', ' ', '(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  user: Observable<User>;
  userrole:User;
  username: User;
  searchField: string;
  constructor(public httpClient: HttpClient,
    public dialog: MatDialog,
    public dataService: GfrCellPhoneOfficeHoursService,
    public authService:AuthService) {

  }
  clearSearchField() {
    this.searchField = '';
    this.loadData();
  }
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('filter') filter: ElementRef;
  ngOnInit() {
    this.user = this.authService.user;
    this.user.subscribe(userrole=> this.userrole = userrole);
    this.loadData();
  }
  upload() {
    const dialogRef = this.dialog.open(UploadComponent,{
      width: '500px',
      data: {name: 'Cellphoneofficehours'}
    });
    dialogRef.afterClosed().subscribe(result =>  {
      this.loadData();
    });
  }

  addNew(gfrcellOfficeHours: GFRCellPhoneOfficeHours) {
    const dialogRef = this.dialog.open(GfrcellphoneofficehoursaddComponent, {
      data: {gfrcellOfficeHours: gfrcellOfficeHours }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        // After dialog is closed we're doing frontend updates
        // For add we're just pushing a new row inside DataService
        this.exampleDatabase.dataChange.value.push(this.dataService.getDialogData());
        
        this.loadData();
      }
    });
  }
  startEdit(i: number,
   gfrid: string,
   gfrName:string,
   gfrLocation:string,
    mondayOpen: string,
    mondayClose : string,
    tuesdayOpen : string,
    tuesdayClose: string,
    wednesdayOpen : string,
    wednesdayClose :string,
    thursdayOpen : string,
    thursdayClose : string,
    fridayOpen : string,
    fridayClose : string,
    saturdayOpen: string,
    saturdayClose : string,
    sundayOpen : string,
    sundayClose : string,
    comments:string) {
    this.gfrid = gfrid;
   // index row is used just for debugging proposes and can be removed
   this.index = i;
   this.user = this.authService.user;
  this.user.subscribe(username=> this.username= username);
   console.log(this.index);
   const dialogRef = this.dialog.open(GfrcellphoneofficehourseditComponent, {
   
     data: {gfrid: gfrid,
      gfrName:gfrName,
      gfrLocation:gfrLocation,
      mondayOpen: mondayOpen,
      mondayClose : mondayClose,
      tuesdayOpen : tuesdayOpen,
      tuesdayClose: tuesdayClose,
      wednesdayOpen : wednesdayOpen,
      wednesdayClose :wednesdayClose,
      thursdayOpen : thursdayOpen,
      thursdayClose : thursdayClose,
      fridayOpen : fridayOpen,
      fridayClose : fridayClose,
      saturdayOpen: saturdayOpen,
      saturdayClose : saturdayClose,
      sundayOpen : sundayOpen,
      sundayClose : sundayClose,
      comments:comments,
      lastModifiedUser:this.userrole.userName}
   });

   dialogRef.afterClosed().subscribe(result => {
     if (result === 1) {
       // When using an edit things are little different, firstly we find record inside DataService by id
       const foundIndex = this.exampleDatabase.dataChange.value.findIndex(x => x.gfrid === this.gfrid);
       // Then you update that record using data from dialogData (values you enetered)
       this.exampleDatabase.dataChange.value[foundIndex] = this.dataService.getDialogData();
       // And lastly refresh table
       
       this.loadData();
     }
   });
 }
 private refreshTable() {
  // Refreshing table using paginator
  // Thanks yeager-j for tips
  // https://github.com/marinantonio/angular-mat-table-crud/issues/12
  this.paginator._changePageSize(this.paginator.pageSize);
}
  public loadData() {
    this.exampleDatabase = new GfrCellPhoneOfficeHoursService(this.httpClient,this.authService);
    this.dataSource = new ExampleDataSource(this.exampleDatabase, this.paginator, this.sort);
    fromEvent(this.filter.nativeElement, 'keyup')
      // .debounceTime(150)
      // .distinctUntilChanged()
      .subscribe(() => {
        if (!this.dataSource) {
          return;
        }
        this.dataSource.filter = this.filter.nativeElement.value;
      });
  }

}
export class ExampleDataSource extends DataSource<GFRCellPhoneOfficeHours> {
  _filterChange = new BehaviorSubject('');

  get filter(): string {
    return this._filterChange.value;
  }

  set filter(filter: string) {
    this._filterChange.next(filter);
  }

  filteredData: GFRCellPhoneOfficeHours[] = [];
  renderedData: GFRCellPhoneOfficeHours[] = [];

  constructor(public _exampleDatabase: GfrCellPhoneOfficeHoursService,
    public _paginator: MatPaginator,
    public _sort: MatSort) {
    super();
    // Reset to the first page when the user changes the filter.
    this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
  }

  /** Connect function called by the table to retrieve one stream containing the data to render. */
  connect(): Observable<GFRCellPhoneOfficeHours[]> {
    // Listen for any changes in the base data, sorting, filtering, or pagination
    const displayDataChanges = [
      this._exampleDatabase.dataChange,
      this._sort.sortChange,
      this._filterChange,
      this._paginator.page
    ];

    //console.log(this._exampleDatabase.getAllIssues());
    this._exampleDatabase.getGFRCellPhoneHoursDetails()

    return merge(...displayDataChanges).pipe(map(() => {
      // Filter data

      this.filteredData = this._exampleDatabase.data.slice().filter((gfrCellPhoneHours: GFRCellPhoneOfficeHours) => {
        const searchStr = (gfrCellPhoneHours.gfrid +gfrCellPhoneHours.gfrName+gfrCellPhoneHours.gfrLocation+ gfrCellPhoneHours.mondayOpen + gfrCellPhoneHours.mondayClose + gfrCellPhoneHours.tuesdayOpen
          + gfrCellPhoneHours.tuesdayClose + gfrCellPhoneHours.wednesdayOpen + gfrCellPhoneHours.wednesdayClose + gfrCellPhoneHours.thursdayOpen
          + gfrCellPhoneHours.thursdayClose + gfrCellPhoneHours.fridayOpen + gfrCellPhoneHours.fridayClose + gfrCellPhoneHours.saturdayOpen
          + gfrCellPhoneHours.saturdayClose + gfrCellPhoneHours.sundayOpen + gfrCellPhoneHours.sundayClose+gfrCellPhoneHours.comments).toLowerCase();
        return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
      });
      this._exampleDatabase.data;

      //   // Sort filtered data
      const sortedData = this.sortData(this.filteredData.slice());

      //   // Grab the page's slice of the filtered sorted data.
      const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
      this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
      return this.renderedData;
    }
    ));
  }

  disconnect() { }


  /** Returns a sorted copy of the database data. */
  sortData(data: GFRCellPhoneOfficeHours[]): GFRCellPhoneOfficeHours[] {
    if (!this._sort.active || this._sort.direction === '') {
      return data;
    }

    return data.sort((a, b) => {
      let propertyA: number | string = '';
      let propertyB: number | string = '';

      switch (this._sort.active) {
        case 'gfrid': [propertyA, propertyB] = [a.gfrid, b.gfrid]; break;
        case 'gfrName': [propertyA, propertyB] = [a.gfrName, b.gfrName]; break;
        case 'gfrLocation': [propertyA, propertyB] = [a.gfrLocation, b.gfrLocation]; break;
        case 'mondayOpen': [propertyA, propertyB] = [a.mondayOpen, b.mondayOpen]; break;
        case 'mondayClose': [propertyA, propertyB] = [a.mondayClose, b.mondayClose]; break;
        case 'tuesdayOpen': [propertyA, propertyB] = [a.tuesdayOpen, b.tuesdayOpen]; break;
        case 'tuesdayClose': [propertyA, propertyB] = [a.tuesdayClose, b.tuesdayClose]; break;
        case 'wednesdayOpen': [propertyA, propertyB] = [a.wednesdayOpen, b.wednesdayOpen]; break;
        case 'wednesdayClose': [propertyA, propertyB] = [a.wednesdayClose, b.wednesdayClose]; break;
        case 'thursdayOpen': [propertyA, propertyB] = [a.thursdayOpen, b.thursdayOpen]; break;
        case 'thursdayClose': [propertyA, propertyB] = [a.thursdayClose, b.thursdayClose]; break;
        case 'fridayOpen': [propertyA, propertyB] = [a.fridayOpen, b.fridayOpen]; break;
        case 'fridayClose': [propertyA, propertyB] = [a.fridayClose, b.fridayClose]; break;
        case 'saturdayOpen': [propertyA, propertyB] = [a.saturdayOpen, b.saturdayOpen]; break;
        case 'saturdayClose': [propertyA, propertyB] = [a.saturdayClose, b.saturdayClose]; break;
        case 'sundayOpen': [propertyA, propertyB] = [a.sundayOpen, b.sundayOpen]; break;
        case 'sundayClose': [propertyA, propertyB] = [a.sundayClose, b.sundayClose]; break;
        case 'comments': [propertyA, propertyB] = [a.comments, b.comments]; break;
      }

      const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
      const valueB = isNaN(+propertyB) ? propertyB : +propertyB;

      return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'asc' ? 1 : -1);
    });
  }
}



