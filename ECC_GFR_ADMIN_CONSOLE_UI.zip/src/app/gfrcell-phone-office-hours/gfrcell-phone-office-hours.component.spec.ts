import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GFRCellPhoneOfficeHoursComponent } from './gfrcell-phone-office-hours.component';

describe('GFRCellPhoneOfficeHoursComponent', () => {
  let component: GFRCellPhoneOfficeHoursComponent;
  let fixture: ComponentFixture<GFRCellPhoneOfficeHoursComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GFRCellPhoneOfficeHoursComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GFRCellPhoneOfficeHoursComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
