import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppTagRoutingComponent } from './app-tag-routing.component';

describe('AppTagRoutingComponent', () => {
  let component: AppTagRoutingComponent;
  let fixture: ComponentFixture<AppTagRoutingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppTagRoutingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppTagRoutingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
