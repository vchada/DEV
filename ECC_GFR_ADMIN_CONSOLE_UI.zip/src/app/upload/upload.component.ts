import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AppTagRoutingServiceService } from '../services/app-tag-routing-service.service';
import { HttpEventType } from '@angular/common/http';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {
  fileUpload = { status: '', message: '',progress:'', filePath: '' };
  error: any;

  constructor(public dialogRef: MatDialogRef<UploadComponent>,
    @Inject(MAT_DIALOG_DATA) public data: string,
    public dataService: AppTagRoutingServiceService) { }

  selectedFileName: string;
  selectedFile: File;
  selectedFileFormat:string;


  onFileSelected(event: any) {
    console.log("File", event.target.files[0]);
    this.selectedFile = <File>event.target.files[0];
    this.selectedFileName = event.target.files[0].name;
    this.selectedFileFormat = event.target.files[0].type;
    //console.log(event.target.files[0].type);
  }
  uploadFile() {
    console.log("Uploaded file");
    const fd = new FormData();
    fd.append('file', this.selectedFile, this.selectedFile.name);
    this.dataService.uploadFile(fd).subscribe(event => {
      if (event.type === HttpEventType.UploadProgress) {
        console.log('Upload Progress' + event.loaded / event.total * 100 + '%');
        this.fileUpload.progress = Math.round(event.loaded / event.total * 100).toString();

      } else if (event.type === HttpEventType.Response) {
       // console.log("Upload Response", event.body);
        this.fileUpload = <any>event.body;
        console.log(this.fileUpload)

      }
    });
  }
  downloadFile() {
    console.log("Download file");
  }
  close(): void {
    this.dialogRef.close();
  }

  ngOnInit() {
  }

}
