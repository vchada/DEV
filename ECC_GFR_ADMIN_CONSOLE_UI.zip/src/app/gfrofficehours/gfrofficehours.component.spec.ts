import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GfrofficehoursComponent } from './gfrofficehours.component';

describe('GfrofficehoursComponent', () => {
  let component: GfrofficehoursComponent;
  let fixture: ComponentFixture<GfrofficehoursComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GfrofficehoursComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GfrofficehoursComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
