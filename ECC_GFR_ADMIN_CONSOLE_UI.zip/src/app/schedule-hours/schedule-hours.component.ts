import { Component, OnInit } from '@angular/core';
import { FormControl, FormBuilder, Validators } from '@angular/forms';
import { ScheduleHours } from '../models/ScheduleHours';

export interface Week {
  value:string;
  viewValue:string;
}

@Component({
  selector: 'app-schedule-hours',
  templateUrl: './schedule-hours.component.html',
  styleUrls: ['./schedule-hours.component.css']
})
export class ScheduleHoursComponent implements OnInit {

  public scheduleHours:ScheduleHours=new ScheduleHours();

  date = new FormControl(new Date());
  gfrOffice:string[] = ["hello","Hi"];

  weeks: Week[] = [
    {value: 'monday', viewValue: 'Monday'},
    {value: 'tuesday', viewValue: 'Tuesday'},
    {value: 'wednesday', viewValue: 'Wednesday'},
    {value: 'thursday', viewValue: 'Thursday'},
    {value: 'friday', viewValue: 'Friday'},
    {value: 'saturday', viewValue: 'Saturday'},
    {value: 'sunday ', viewValue: 'Sunday'}
  ];
  timeData = [' '];
  
  median = 'AM';
  scheduleForm = this.fb.group({
    gfrOffice:['',Validators.required],
    tableName:['',Validators.required],
    startDate:['',Validators.required],
    endDate:['',Validators.required],
    dayOfWeek:['',Validators.required],
    openHours:['',Validators.required],
    closedHours:['',Validators.required],
    closedFullday:['',Validators.required],

  });
  constructor(private fb:FormBuilder) { }

  ngOnInit() {
    this.setTime();
  }

  onSubmit() {
    console.log("Submitted",this.scheduleForm.value)
  }
  reset() {
   
  }
  setTime(isTimeValid?: boolean): void {
    let isValid = isTimeValid;
	
    for (let i = 1; i <= 12; i++) {
      for (let j = 0; j < 60; j = j + 30) {
        const time = (i) + ':' + (j < 10 ? ('0' + j) : j) + ' ' + this.median;
        if (i === 12 && j === 0) {
          this.median = this.median === 'AM' ? 'PM' : 'AM';
        }
        this.timeData.push(time);
        if (i === 12 && j === 30 && this.median === 'PM') {
          this.setTime(true);
        }
      }
    }
  }
 

 

}
