import { Component, OnInit } from '@angular/core';

import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit { 

  form: FormGroup;                    // {1}
  private formSubmitAttempt: boolean; 
  
  
  constructor(public auth:AuthService, private fb: FormBuilder, ) {  
   }
 
 

  ngOnInit() {
    this.form = this.fb.group({     // {5}
      userName: ['', Validators.required],
      password: ['', Validators.required]
    });
  }
  isFieldInvalid(field: string) { // {6}
  return (
    (!this.form.get(field).valid && this.form.get(field).touched) ||
    (this.form.get(field).untouched && this.formSubmitAttempt)
  );
}
onSubmit() {
  if (this.form.valid) {
    this.auth.login(this.form.value); // {7}
  }
  this.formSubmitAttempt = true;             // {8}
}
  /* login() : void {
    this.auth.login(this.user);

     if(this.username == 'admin' && this.password == 'admin'){
      
      this.router.navigate(["main"]); 
   }else {
    alert("Invalid credentials");
  }*/
  
}
