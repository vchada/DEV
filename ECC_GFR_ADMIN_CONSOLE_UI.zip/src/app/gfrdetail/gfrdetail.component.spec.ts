import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GfrdetailComponent } from './gfrdetail.component';

describe('GfrdetailComponent', () => {
  let component: GfrdetailComponent;
  let fixture: ComponentFixture<GfrdetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GfrdetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GfrdetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
