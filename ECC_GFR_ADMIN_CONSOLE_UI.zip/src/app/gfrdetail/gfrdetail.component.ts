import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { MatDialog, MatPaginator, MatSort } from '@angular/material';

import { DataSource } from '@angular/cdk/collections';
import { BehaviorSubject, fromEvent, merge, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { GfrdetailService } from '../services/gfrdetail.service';
import { GFRDetail } from '../models/GFRDetail';
import { GfrdetaileditComponent } from '../dialogs/gfrdetailedit/gfrdetailedit.component';
import { GfrdetailaddComponent } from '../dialogs/gfrdetailadd/gfrdetailadd.component';
import { PlatformLocation } from '@angular/common';
import { AuthService } from '../services/auth.service';
import { User } from '../models/User';
import { UploadComponent } from '../upload/upload.component';


@Component({
  selector: 'app-gfrdetail',
  templateUrl: './gfrdetail.component.html',
  styleUrls: ['./gfrdetail.component.css']
})
export class GfrdetailComponent implements OnInit {

  displayedColumns = [
    'gfrid',
    'gfrName',
    'gfrLocation',
    'gfrWelcomePrompt',
    'gfrOfficeHoursPrompt',
    'gfrOfficeCloseFlag',
    'dealershipAvailable',
    'spanishOption',
    'gfrState',
    'gfrAddressPrompt',
    'gfrOfficeHoursFlag',
    'timeZone',
    'dstExists',
    'gfrHuntSales',
    'gfrHuntService',
    'gfrSiteCode',
    'gfrHuntSpanish',
    'gfrCellNum',
    'gfrHuntDealership',
    'gfrCommercialFlag',
   /*  'createdUser',
    'createdDtTm',
    'lastModifiedUser',
    'lastModifiedDtTm', */
    'gfrHolidayList',
    'noMatchANIxferToSales',
    'gfrHuntSpanishService',
    'actions'
  ];
  exampleDatabase: GfrdetailService | null;
  dataSource: ExampleDataSource | null;
  index: number;
  gfrid: string;
  user:User;
  mask: any[] = ['+', '1', ' ', '(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  username: User;
  userrole: User;
  searchField: string;

  constructor(public httpClient: HttpClient,
    public dialog: MatDialog,
    public gfrDetailService: GfrdetailService,
    public authService: AuthService,
    location: PlatformLocation) {
    location.onPopState(() => {
      authService.logout();
    });

  }
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('filter') filter: ElementRef;
  ngOnInit() {
    this.authService.user.subscribe(result =>{
      this.user = result;
    })
    this.loadData();
  }
  clearSearchField() {
    this.searchField = '';
    this.loadData();
  }
  upload() {
    const dialogRef = this.dialog.open(UploadComponent,{
      width: '500px',
      data: {name: 'gfrdetail'}
    });
    dialogRef.afterClosed().subscribe(result =>  {
      this.loadData();
    });
  }

  addNew(gfrDetail: GFRDetail) {     
    const dialogRef = this.dialog.open(GfrdetailaddComponent, {    
      data: { gfrDetail: gfrDetail }
    });

    dialogRef.afterClosed().subscribe(result => {    
      if (result === 1) {
        // After dialog is closed we're doing frontend updates
        // For add we're just pushing a new row inside DataService
        this.exampleDatabase.dataChange.value.push(this.gfrDetailService.getDialogData());
        this.loadData();
      
      }
    });
  }
  startEdit(i: number,
    gfrid: string,
    gfrName: string,
    gfrLocation: string,
    gfrWelcomePrompt: string,
    gfrOfficeHoursPrompt: string,
    gfrOfficeCloseFlag: string,
    dealershipAvailable: string,
    spanishOption: string,
    gfrState: string,
    gfrAddressPrompt: string,
    gfrOfficeHoursFlag: string,
    timeZone: string,
    dstExists: string,
    gfrHuntSales: string,
    gfrHuntService: string,
    gfrSiteCode: string,
    gfrHuntSpanish: string,
    gfrCellNum: string,
    gfrHuntDealership: string,
    gfrCommercialFlag: string,
    gfrHolidayList: string,
    noMatchANIxferToSales: string,
    gfrHuntSpanishService:string) {
    this.gfrid = gfrid;
    // index row is used just for debugging proposes and can be removed
    this.index = i;
    
    console.log(this.index);
    
    const dialogRef = this.dialog.open(GfrdetaileditComponent, {
      data: {
        gfrid: gfrid,
        gfrName: gfrName,
        gfrLocation: gfrLocation,
        gfrWelcomePrompt: gfrWelcomePrompt,
        gfrOfficeHoursPrompt: gfrOfficeHoursPrompt,
        gfrOfficeCloseFlag: gfrOfficeCloseFlag,
        dealershipAvailable: dealershipAvailable,
        spanishOption: spanishOption,
        gfrState: gfrState,
        gfrAddressPrompt: gfrAddressPrompt,
        gfrOfficeHoursFlag: gfrOfficeHoursFlag,
        timeZone: timeZone,
        dstExists: dstExists,
        gfrHuntSales: gfrHuntSales,
        gfrHuntService: gfrHuntService,
        gfrSiteCode: gfrSiteCode,
        gfrHuntSpanish: gfrHuntSpanish,
        gfrCellNum: gfrCellNum,
        gfrHuntDealership: gfrHuntDealership,
        gfrCommercialFlag: gfrCommercialFlag,        
        gfrHolidayList: gfrHolidayList,
        noMatchANIxferToSales: noMatchANIxferToSales,
        gfrHuntSpanishService:gfrHuntSpanishService,
        lastModifiedUser:this.user.userName
      },


    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        // When using an edit things are little different, firstly we find record inside DataService by id
        const foundIndex = this.exampleDatabase.dataChange.value.findIndex(x => x.gfrid === this.gfrid);
        // Then you update that record using data from dialogData (values you enetered)
        this.exampleDatabase.dataChange.value[foundIndex] = this.gfrDetailService.getDialogData();
        // And lastly refresh table
        this.refreshTable();
        this.loadData();
      }
    });
  }
  public loadData() {
    this.exampleDatabase = new GfrdetailService(this.httpClient,this.authService);
    this.dataSource = new ExampleDataSource(this.exampleDatabase, this.paginator, this.sort);
    fromEvent(this.filter.nativeElement, 'keyup')
      // .debounceTime(150)
      // .distinctUntilChanged()
      .subscribe(() => {
        if (!this.dataSource) {
          return;
        }
        this.dataSource.filter = this.filter.nativeElement.value;
      });
  }
  private refreshTable() {
    // Refreshing table using paginator
    // Thanks yeager-j for tips
    // https://github.com/marinantonio/angular-mat-table-crud/issues/12
    this.paginator._changePageSize(this.paginator.pageSize);
  }
}



export class ExampleDataSource extends DataSource<GFRDetail> {
  _filterChange = new BehaviorSubject('');

  get filter(): string {
    return this._filterChange.value;
  }

  set filter(filter: string) {
    this._filterChange.next(filter);
  }

  filteredData: GFRDetail[] = [];
  renderedData: GFRDetail[] = [];

  constructor(public _exampleDatabase: GfrdetailService,
    public _paginator: MatPaginator,
    public _sort: MatSort) {
    super();
    // Reset to the first page when the user changes the filter.
    this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
  }

  /** Connect function called by the table to retrieve one stream containing the data to render. */
  connect(): Observable<GFRDetail[]> {
    // Listen for any changes in the base data, sorting, filtering, or pagination
    const displayDataChanges = [
      this._exampleDatabase.dataChange,
      this._sort.sortChange,
      this._filterChange,
      this._paginator.page
    ];

    this._exampleDatabase.getAllGFRDetails();


    return merge(...displayDataChanges).pipe(map(() => {
      // Filter data
      this.filteredData = this._exampleDatabase.data.slice().filter((gfrDetail: GFRDetail) => {
        const searchStr = (
             
           + gfrDetail.gfrid
           + gfrDetail.gfrWelcomePrompt
           + gfrDetail.spanishOption
           + gfrDetail.gfrState
           + gfrDetail.gfrSiteCode
           + gfrDetail.gfrOfficeHoursPrompt
           + gfrDetail.gfrOfficeHoursFlag
           + gfrDetail.gfrOfficeCloseFlag
           + gfrDetail.gfrLocation
           + gfrDetail.gfrName
           + gfrDetail.timeZone
           + gfrDetail.dealershipAvailable
           + gfrDetail.dstExists
           + gfrDetail.gfrAddressPrompt
           + gfrDetail.gfrHuntSpanish
           + gfrDetail.gfrCellNum
           + gfrDetail.gfrHuntDealership
           + gfrDetail.gfrCommercialFlag
           + gfrDetail.createdUser
           + gfrDetail.createdDtTm
           + gfrDetail.lastModifiedDtTm
           + gfrDetail.lastModifiedUser
           + gfrDetail.gfrHolidayList
           +gfrDetail.noMatchANIxferToSales 
           +gfrDetail.gfrHuntSpanishService).toLowerCase();
        return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
      });

      // Sort filtered data
      const sortedData = this.sortData(this.filteredData.slice());

      // Grab the page's slice of the filtered sorted data.
      const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
      this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
      return this.renderedData;
    }
    ));
  }

  disconnect() { }


  /** Returns a sorted copy of the database data. */
  sortData(data: GFRDetail[]): GFRDetail[] {
    if (!this._sort.active || this._sort.direction === '') {
      return data;
    }

    return data.sort((a, b) => {
      let propertyA: number | string = '';
      let propertyB: number | string = '';

      switch (this._sort.active) {
        case 'gfrid': [propertyA, propertyB] = [a.gfrid, b.gfrid]; break;
        case 'gfrName': [propertyA, propertyB] = [a.gfrName, b.gfrName]; break;
        case 'gfrLocation': [propertyA, propertyB] = [a.gfrLocation, b.gfrLocation]; break;
        case 'gfrWelcomePrompt': [propertyA, propertyB] = [a.gfrWelcomePrompt, b.gfrWelcomePrompt]; break;
        case 'gfrOfficeHoursPrompt': [propertyA, propertyB] = [a.gfrOfficeHoursPrompt, b.gfrOfficeHoursPrompt]; break;
        case 'gfrOfficeCloseFlag': [propertyA, propertyB] = [a.gfrOfficeCloseFlag, b.gfrOfficeCloseFlag]; break;
        case 'dealershipAvailable': [propertyA, propertyB] = [a.dealershipAvailable, b.dealershipAvailable]; break;
        case 'spanishOption': [propertyA, propertyB] = [a.spanishOption, b.spanishOption]; break;
        case 'gfrState': [propertyA, propertyB] = [a.gfrState, b.gfrState]; break;
        case 'gfrAddressPrompt': [propertyA, propertyB] = [a.gfrAddressPrompt, b.gfrAddressPrompt]; break;
        case 'gfrOfficeHoursFlag': [propertyA, propertyB] = [a.gfrOfficeHoursFlag, b.gfrOfficeHoursFlag]; break;
        case 'timeZone': [propertyA, propertyB] = [a.timeZone, b.timeZone]; break;
        case 'dstExists': [propertyA, propertyB] = [a.dstExists, b.dstExists]; break;
        case 'timeZone': [propertyA, propertyB] = [a.timeZone, b.timeZone]; break;
        case 'gfrHuntSales': [propertyA, propertyB] = [a.gfrHuntSales, b.gfrHuntSales]; break;
        case 'gfrHuntService': [propertyA, propertyB] = [a.gfrHuntService, b.gfrHuntService]; break;
        case 'gfrSiteCode': [propertyA, propertyB] = [a.gfrSiteCode, b.gfrSiteCode]; break;

        case 'gfrHuntSpanish': [propertyA, propertyB] = [a.gfrHuntSpanish, b.gfrHuntSpanish]; break;
        case 'gfrCellNum': [propertyA, propertyB] = [a.gfrCellNum, b.gfrCellNum]; break;
        case 'gfrHuntDealership': [propertyA, propertyB] = [a.gfrHuntDealership, b.gfrHuntDealership]; break;
        case 'gfrCommercialFlag': [propertyA, propertyB] = [a.gfrCommercialFlag, b.gfrCommercialFlag]; break;
        case 'createdUser': [propertyA, propertyB] = [a.createdUser, b.createdUser]; break;
        case 'createdDtTm': [propertyA, propertyB] = [a.createdDtTm, b.createdDtTm]; break;
        case 'lastModifiedUser': [propertyA, propertyB] = [a.lastModifiedUser, b.lastModifiedUser]; break;
        case 'lastModifiedDtTm': [propertyA, propertyB] = [a.lastModifiedDtTm, b.lastModifiedDtTm]; break;
        case 'gfrHolidayList': [propertyA, propertyB] = [a.gfrHolidayList, b.gfrHolidayList]; break;
        case 'noMatchANIxferToSales': [propertyA, propertyB] = [a.noMatchANIxferToSales, b.noMatchANIxferToSales]; break;
        case 'gfrHuntSpanishService': [propertyA, propertyB] = [a.gfrHuntSpanishService, b.gfrHuntSpanishService]; break;
      }

      const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
      const valueB = isNaN(+propertyB) ? propertyB : +propertyB;

      return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'asc' ? 1 : -1);
    });
  }
}
