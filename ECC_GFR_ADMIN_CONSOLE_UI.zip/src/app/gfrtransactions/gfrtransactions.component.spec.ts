import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GFRTransactionsComponent } from './gfrtransactions.component';

describe('GFRTransactionsComponent', () => {
  let component: GFRTransactionsComponent;
  let fixture: ComponentFixture<GFRTransactionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GFRTransactionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GFRTransactionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
