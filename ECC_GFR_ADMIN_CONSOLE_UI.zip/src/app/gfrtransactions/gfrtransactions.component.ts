import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { GFRTransactionsService } from '../services/gfrtransactions.service';
import { User } from '../models/User';
import { HttpClient } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { AuthService } from '../services/auth.service';
import { MatPaginator, MatSort, Sort } from '@angular/material';
import { fromEvent, BehaviorSubject, Observable, merge } from 'rxjs';
import { DataSource } from '@angular/cdk/table';
import { GFRTransactions } from '../models/GFRTransactions';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-gfrtransactions',
  templateUrl: './gfrtransactions.component.html',
  styleUrls: ['./gfrtransactions.component.css']
})
export class GFRTransactionsComponent implements OnInit {

  displayedColumns = ['gfrid', 'userName', 'tableName', 'columnName', 'modifiedDate', 'previousValue', 'currentValue', 'gfrAdminTransactionsID'];
  exampleDatabase: GFRTransactionsService | null;
  dataSource: ExampleDataSource | null;
  index: number;
  appTag: string;
  mask: any[] = ['+', '1', ' ', '(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  username: any;
  user: User;
  searchField: string;

  constructor(public httpClient: HttpClient,
    public dialog: MatDialog,
    public appTagService: GFRTransactionsService,
    private authService: AuthService) { }

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  
  @ViewChild('filter') filter: ElementRef;

  ngOnInit() {
    this.loadData();
    this.authService.user.subscribe(user => this.user = user)
    
    const sortState: Sort = {active: 'gfrAdminTransactionsID', direction: 'desc'};
this.sort.active = sortState.active;
this.sort.direction = sortState.direction;
this.sort.sortChange.emit(sortState);
  }

  refresh() {
    this.loadData();
  }
  clearSearchField() {
    this.searchField = '';
    this.loadData();
  }



  private refreshTable() {
    // Refreshing table using paginator
    // Thanks yeager-j for tips
    // https://github.com/marinantonio/angular-mat-table-crud/issues/12
    this.paginator._changePageSize(this.paginator.pageSize);
  }





  public loadData() {
    this.exampleDatabase = new GFRTransactionsService(this.httpClient, this.authService);
    this.dataSource = new ExampleDataSource(this.exampleDatabase, this.paginator, this.sort);
    fromEvent(this.filter.nativeElement, 'keyup')
      // .debounceTime(150)
      // .distinctUntilChanged()
      .subscribe(() => {
        if (!this.dataSource) {
          return;
        }
        this.dataSource.filter = this.filter.nativeElement.value;
      });
  }
}

export class ExampleDataSource extends DataSource<GFRTransactions> {
  _filterChange = new BehaviorSubject('');

  get filter(): string {
    return this._filterChange.value;
  }

  set filter(filter: string) {
    this._filterChange.next(filter);
  }

  filteredData: GFRTransactions[] = [];
  renderedData: GFRTransactions[] = [];

  constructor(public _exampleDatabase: GFRTransactionsService,
    public _paginator: MatPaginator,
    public _sort: MatSort) {
    super();
    // Reset to the first page when the user changes the filter.
    this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
  }

  /** Connect function called by the table to retrieve one stream containing the data to render. */
  connect(): Observable<GFRTransactions[]> {
    // Listen for any changes in the base data, sorting, filtering, or pagination
    const displayDataChanges = [
      this._exampleDatabase.dataChange,
      this._sort.sortChange,
      this._filterChange,
      this._paginator.page
    ];

    this._exampleDatabase.getAllGFRTransaction();


    return merge(...displayDataChanges).pipe(map(() => {
      // Filter data
      this.filteredData = this._exampleDatabase.data.slice().filter((gfrTransactions: GFRTransactions) => {
        const searchStr = (gfrTransactions.columnName + gfrTransactions.currentValue + gfrTransactions.gfrAdminTransactionsID + gfrTransactions.gfrid + gfrTransactions.modifiedDate + gfrTransactions.previousValue + gfrTransactions.tableName + gfrTransactions.userName).toLowerCase();
        return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
      });

      // Sort filtered data
      const sortedData = this.sortData(this.filteredData.slice());

      // Grab the page's slice of the filtered sorted data.
      const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
      this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
      return this.renderedData;
    }
    ));
  }

  disconnect() { }


  /** Returns a sorted copy of the database data. */
  sortData(data: GFRTransactions[]): GFRTransactions[] {
    if (!this._sort.active || this._sort.direction === '') {
      return data;
    }

    return data.sort((a, b) => {
      let propertyA: number | string = '';
      let propertyB: number | string = '';

      switch (this._sort.active) {
        /*    case 'gfrid': [propertyA, propertyB] = [a.gfrid, b.gfrid]; break;
           case 'userName': [propertyA, propertyB] = [a.userName, b.userName]; break;
           case 'tableName': [propertyA, propertyB] = [a.tableName, b.tableName]; break;
           case 'columnName': [propertyA, propertyB] = [a.columnName, b.columnName]; break;
           case 'modifiedDate': [propertyA, propertyB] = [a.modifiedDate, b.modifiedDate]; break;
           case 'previousValue': [propertyA, propertyB] = [a.previousValue, b.previousValue]; break;
           case 'currentValue': [propertyA, propertyB] = [a.currentValue, b.currentValue]; break; */
        case 'gfrAdminTransactionsID': [propertyA, propertyB] = [a.gfrAdminTransactionsID, b.gfrAdminTransactionsID]; break;

      }

      const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
      const valueB = isNaN(+propertyB) ? propertyB : +propertyB;

      return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'asc' ? 1 : -1);
    });
  }
}


