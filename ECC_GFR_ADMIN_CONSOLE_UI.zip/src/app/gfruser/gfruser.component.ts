import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { GfrCellPhoneOfficeHoursService } from '../services/gfr-cell-phone-office-hours.service';
import { merge, Observable, BehaviorSubject, fromEvent } from 'rxjs';
import { map } from 'rxjs/operators';
import { MatSort, MatPaginator, MatDialog } from '@angular/material';
import { DataSource } from '@angular/cdk/table';
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../services/auth.service';
import { User } from '../models/User';
import { GfrUserService } from '../services/gfr-user.service';
import { GFRUser } from '../models/GFRUser';
import { GfruseraddComponent } from '../dialogs/gfruseradd/gfruseradd.component';
import { GfrusereditComponent } from '../dialogs/gfruseredit/gfruseredit.component';
import { CommonResultDialogComponent } from '../dialogs/common-result-dialog/common-result-dialog.component';

@Component({
  selector: 'app-gfruser',
  templateUrl: './gfruser.component.html',
  styleUrls: ['./gfruser.component.css']
})
export class GFRUserComponent implements OnInit {
  displayedColumns = [
    'gfrId',
    'gfrName',
    'createdUser',
    'email',
    'createdDtTm',
    'lastModifiedUser',
    'lastModifiedDtTm',
    'userId',
    'isAdmin',
    'userName',
    'actions'
  ];

  gfrid: string;
  exampleDatabase: GfrUserService | null;
  dataSource: ExampleDataSource | null;
  user: Observable<User>;
  searchField: string;

  
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('filter') filter: ElementRef;

  constructor(private gfrUserService: GfrUserService,
    private authService: AuthService,
    public httpClient: HttpClient,
    public dialog: MatDialog) {

  }
  ngOnInit() {
    this.loadData();
  }
  
  clearSearchField() {
    this.searchField = '';
    this.loadData();
  }

  addNew(gfrUser?: GFRUser) {
    const dialogRef = this.dialog.open(GfruseraddComponent, {
      data: { gfrUser: gfrUser }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result && result.status === 'success') {
        this.loadData();
      }
    });
  }

  startEdit(i: number, row) {

    const dialogRef = this.dialog.open(GfrusereditComponent, {
      data: row
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result && result.status === 'success') {
        this.loadData();
      }
    });
  }

  private refreshTable() {
    this.paginator._changePageSize(this.paginator.pageSize);
  }

  public loadData() {
    this.exampleDatabase = new GfrUserService(this.httpClient, this.authService);
    this.dataSource = new ExampleDataSource(this.exampleDatabase, this.paginator, this.sort);
    fromEvent(this.filter.nativeElement, 'keyup')
      .subscribe(() => {
        if (!this.dataSource) {
          return;
        }
        this.dataSource.filter = this.filter.nativeElement.value;
      });
  }

  deleteItem(i, rowdata) {
    this.gfrUserService.deleteGfrUser(rowdata).subscribe((data) => {
        const dialogRef = this.dialog.open(CommonResultDialogComponent, {
          width: '450px',
          data: {
            headerText: 'Success',
            msgText: rowdata.userName + ' GFR User deleted successfully.'
          }
        });
    
        dialogRef.afterClosed().subscribe(result => {      
          this.loadData();
        });
    })
  }

}


export class ExampleDataSource extends DataSource<GFRUser> {
  _filterChange = new BehaviorSubject('');

  get filter(): string {
    return this._filterChange.value;
  }

  set filter(filter: string) {
    this._filterChange.next(filter);
  }

  filteredData: any[] = [];
  renderedData: GFRUser[] = [];

  constructor(public _exampleDatabase: GfrUserService,
    public _paginator: MatPaginator,
    public _sort: MatSort) {
    super();
    // Reset to the first page when the user changes the filter.
    this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
  }

  /** Connect function called by the table to retrieve one stream containing the data to render. */
  connect(): Observable<GFRUser[]> {
    // Listen for any changes in the base data, sorting, filtering, or pagination
    const displayDataChanges = [
      this._exampleDatabase.dataChange,
      this._sort.sortChange,
      this._filterChange,
      this._paginator.page
    ];

    //console.log(this._exampleDatabase.getAllIssues());
    this._exampleDatabase.getGFRUsers()

    return merge(...displayDataChanges).pipe(map(() => {
      // Filter data

      this.filteredData = this._exampleDatabase.data.slice().filter((gfrUser: any) => {
        const searchStr = (gfrUser.gfrId + gfrUser.gfrName + gfrUser.createdUser + gfrUser.createdDtTm + gfrUser.lastModifiedUser + gfrUser.lastModifiedDtTm + gfrUser.userId + gfrUser.isAdmin + gfrUser.userName).toLowerCase();
        return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
      });
      this._exampleDatabase.data;

      //   // Sort filtered data
      const sortedData = this.sortData(this.filteredData.slice());

      //   // Grab the page's slice of the filtered sorted data.
      const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
      this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
      return this.renderedData;
    }
    ));
  }

  disconnect() { }


  /** Returns a sorted copy of the database data. */
  sortData(data: GFRUser[]): GFRUser[] {
    if (!this._sort.active || this._sort.direction === '') {
      return data;
    }

    return data.sort((a, b) => {
      let propertyA: number | string = '';
      let propertyB: number | string = '';

      switch (this._sort.active) {
        case 'gfrId': [propertyA, propertyB] = [a.gfrId, b.gfrId]; break;
        case 'gfrName': [propertyA, propertyB] = [a.gfrName, b.gfrName]; break;
        case 'createdUser': [propertyA, propertyB] = [a.createdUser, b.createdUser]; break;
        case 'createdDtTm': [propertyA, propertyB] = [a.createdDtTm, b.createdDtTm]; break;
        case 'lastModifiedUser': [propertyA, propertyB] = [a.lastModifiedUser, b.lastModifiedUser]; break;
        case 'lastModifiedDtTm': [propertyA, propertyB] = [a.lastModifiedDtTm, b.lastModifiedDtTm]; break;
        case 'userId': [propertyA, propertyB] = [a.userId, b.userId]; break;
        case 'isAdmin': [propertyA, propertyB] = [a.isAdmin, b.isAdmin]; break;
        case 'userName': [propertyA, propertyB] = [a.userName, b.userName]; break;
      }

      const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
      const valueB = isNaN(+propertyB) ? propertyB : +propertyB;

      return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'asc' ? 1 : -1);
    });
  }
}



