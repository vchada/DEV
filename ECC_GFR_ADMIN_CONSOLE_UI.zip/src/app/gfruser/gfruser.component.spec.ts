import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GFRUserComponent } from './gfruser.component';

describe('GFRUserComponent', () => {
  let component: GFRUserComponent;
  let fixture: ComponentFixture<GFRUserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GFRUserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GFRUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
