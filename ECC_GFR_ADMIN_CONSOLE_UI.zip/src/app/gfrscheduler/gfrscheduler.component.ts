import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { GFRSchedulerService } from '../services/gfrscheduler.service';
import { User } from '../models/User';
import { HttpClient } from '@angular/common/http';
import { MatDialog, MatPaginator, MatSort } from '@angular/material';
import { AuthService } from '../services/auth.service';
import { ScheduleHours } from '../models/ScheduleHours';
import { fromEvent, BehaviorSubject, Observable, merge } from 'rxjs';
import { DataSource } from '@angular/cdk/table';
import { map } from 'rxjs/operators';
import { GFRScheduleAddComponent } from '../dialogs/gfrschedule-add/gfrschedule-add.component';
import { GfrscheduleEditComponent } from '../dialogs/gfrschedule-edit/gfrschedule-edit.component';

@Component({
  selector: 'app-gfrscheduler',
  templateUrl: './gfrscheduler.component.html',
  styleUrls: ['./gfrscheduler.component.css']
})
export class GFRSchedulerComponent implements OnInit {

  displayedColumns = ['gfr','tableName', 'effectiveDate','expiryDate','openHoursNew','closeHoursNew','openHoursOld','closeHoursOld','reqInitiatedUsr','reqCreatedDtTm','requestStatus','comments','gfrRequestId','actions'];
  exampleDatabase: GFRSchedulerService | null;
  dataSource: ExampleDataSource | null;
  index: number;
  appTag: string;
  mask: any[] = ['+', '1', ' ', '(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  username: any;
  user: User;
  searchField: string;
  gfrRequestId: string;

  constructor(public httpClient: HttpClient,
              public dialog: MatDialog,
              public gfrSchedulerService: GFRSchedulerService,
              private authService:AuthService) {}

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('filter') filter: ElementRef;

  ngOnInit() {
    this.loadData();
    this.authService.user.subscribe(user=> this.user=user)
  }

  refresh() {
    this.loadData();
  }
  clearSearchField() {
    this.searchField = '';
    this.loadData();
  }
delete(requestId:string) {
  this.gfrSchedulerService.delete(requestId);
  this.exampleDatabase.dataChange.value.push(this.gfrSchedulerService.getDialogData());
  this.refresh();
}
  addNew(scheduleHours: ScheduleHours) {
    const dialogRef = this.dialog.open(GFRScheduleAddComponent, {
      data: {scheduleHours: scheduleHours }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        // After dialog is closed we're doing frontend updates
        // For add we're just pushing a new row inside DataService
        this.exampleDatabase.dataChange.value.push(this.gfrSchedulerService.getDialogData());
        this.refreshTable();
        this.refresh();
      }
    });
  }

  startEdit(i: number,  gfr:string,tableName:string,openHoursNew:string,closeHoursNew:string,openHoursOld:string,closeHoursOld:string,effectiveDate:string,
    expiryDate:string,reqInitiatedUsr:string,reqCreatedDtTm:string,requestStatus:string,comments:string,gfrRequestId:string) {
     this.gfrRequestId = gfrRequestId;
    // index row is used just for debugging proposes and can be removed
    this.index = i;
    openHoursOld = openHoursNew;
    closeHoursOld = closeHoursNew;
    //console.log(this.index);
    //console.log("Effective Date ::",effectiveDate)
    const dialogRef = this.dialog.open(GfrscheduleEditComponent, {
    
      data: { gfr:gfr,tableName:tableName,openHoursNew:openHoursNew,closeHoursNew:closeHoursNew,openHoursOld:openHoursOld,closeHoursOld:closeHoursOld,effectiveDate:effectiveDate,
        expiryDate:expiryDate,reqInitiatedUsr:reqInitiatedUsr,reqCreatedDtTm:reqCreatedDtTm,requestStatus:requestStatus,comments:comments,gfrRequestId:gfrRequestId}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        // When using an edit things are little different, firstly we find record inside DataService by id
        const foundIndex = this.exampleDatabase.dataChange.value.findIndex(x => x.gfrRequestId === this.gfrRequestId);
        // Then you update that record using data from dialogData (values you enetered)
        this.exampleDatabase.dataChange.value[foundIndex] = this.gfrSchedulerService.getDialogData();
        // And lastly refresh table
        this.refreshTable();
        this.refresh();
      }
    });
  }
/*
  deleteItem(i: number, appTag: string, gfrTag: string,
             disamPrompt: string) {
    this.index = i;
    this.appTag = appTag;
    const dialogRef = this.dialog.open(DeleteDialogComponent, {
      data: {appTag: appTag, gfrTag: gfrTag, disamPrompt: disamPrompt}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        const foundIndex = this.exampleDatabase.dataChange.value.findIndex(x => x.appTag === this.appTag);
        // for delete we use splice in order to remove single object from DataService
        this.exampleDatabase.dataChange.value.splice(foundIndex, 1);
        this.refreshTable();
      }
    });
  }

*/
  private refreshTable() {
    // Refreshing table using paginator
    // Thanks yeager-j for tips
    // https://github.com/marinantonio/angular-mat-table-crud/issues/12
    this.paginator._changePageSize(this.paginator.pageSize);
  }


  /*   // If you don't need a filter or a pagination this can be simplified, you just use code from else block
    // OLD METHOD:
    // if there's a paginator active we're using it for refresh
    if (this.dataSource._paginator.hasNextPage()) {
      this.dataSource._paginator.nextPage();
      this.dataSource._paginator.previousPage();
      // in case we're on last page this if will tick
    } else if (this.dataSource._paginator.hasPreviousPage()) {
      this.dataSource._paginator.previousPage();
      this.dataSource._paginator.nextPage();
      // in all other cases including active filter we do it like this
    } else {
      this.dataSource.filter = '';
      this.dataSource.filter = this.filter.nativeElement.value;
    }*/



  public loadData() {
    this.exampleDatabase = new GFRSchedulerService(this.httpClient,this.authService);
    this.dataSource = new ExampleDataSource(this.exampleDatabase, this.paginator, this.sort);
    fromEvent(this.filter.nativeElement, 'keyup')
      // .debounceTime(150)
      // .distinctUntilChanged()
      .subscribe(() => {
        if (!this.dataSource) {
          return;
        }
        this.dataSource.filter = this.filter.nativeElement.value;
      });
  }
}

export class ExampleDataSource extends DataSource<ScheduleHours> {
  _filterChange = new BehaviorSubject('');

  get filter(): string {
    return this._filterChange.value;
  }

  set filter(filter: string) {
    this._filterChange.next(filter);
  }

  filteredData: ScheduleHours[] = [];
  renderedData: ScheduleHours[] = [];

  constructor(public _exampleDatabase: GFRSchedulerService,
              public _paginator: MatPaginator,
              public _sort: MatSort) {
    super();
    // Reset to the first page when the user changes the filter.
    this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
  }

  /** Connect function called by the table to retrieve one stream containing the data to render. */
  connect(): Observable<ScheduleHours[]> {
    // Listen for any changes in the base data, sorting, filtering, or pagination
    const displayDataChanges = [
      this._exampleDatabase.dataChange,
      this._sort.sortChange,
      this._filterChange,
      this._paginator.page
    ];

    this._exampleDatabase.getGFRSchedules();


    return merge(...displayDataChanges).pipe(map( () => {
        // Filter data
        this.filteredData = this._exampleDatabase.data.slice().filter((scheduleHours: ScheduleHours) => {
          const searchStr = (scheduleHours.closeHoursNew+ scheduleHours.currentValue+scheduleHours.effectiveDate+scheduleHours.expiryDate+
            scheduleHours.gfrRequestId+scheduleHours.reqCreatedDtTm+scheduleHours.reqInitiatedUsr+scheduleHours.requestStatus+
            scheduleHours.tableName +scheduleHours.openHoursNew+scheduleHours.fullDay+scheduleHours.gfr).toLowerCase();
          return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
        });

        // Sort filtered data
        const sortedData = this.sortData(this.filteredData.slice());

        // Grab the page's slice of the filtered sorted data.
        const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
        this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
        return this.renderedData;
      }
    ));
  }

  disconnect() {}


  /** Returns a sorted copy of the database data. */
  sortData(data: ScheduleHours[]): ScheduleHours[] {
    if (!this._sort.active || this._sort.direction === '') {
      return data;
    }

    return data.sort((a, b) => {
      let propertyA: number | string | Date = '';
      let propertyB: number | string  | Date= '';

      switch (this._sort.active) {

        case 'gfr': [propertyA, propertyB] = [a.gfr, b.gfr]; break;
        case 'gfrName': [propertyA, propertyB] = [a.gfrName, b.gfrName]; break;
        case 'gfrLocation': [propertyA, propertyB] = [a.gfrLocation, b.gfrLocation]; break;
        case 'tableName': [propertyA, propertyB] = [a.tableName, b.tableName]; break;
        case 'openHoursNew': [propertyA, propertyB] = [a.openHoursNew, b.openHoursNew]; break;
        case 'closeHoursNew': [propertyA, propertyB] = [a.closeHoursNew, b.closeHoursNew]; break;
        case 'fullDay': [propertyA, propertyB] = [a.fullDay, b.fullDay]; break;
       
        case 'effectiveDate': [propertyA, propertyB] = [a.effectiveDate, b.effectiveDate]; break;
        case 'expiryDate': [propertyA, propertyB] = [a.expiryDate, b.expiryDate]; break;
        case 'currentValue': [propertyA, propertyB] = [a.currentValue, b.currentValue]; break;
        case 'reqInitiatedUsr': [propertyA, propertyB] = [a.reqInitiatedUsr, b.reqInitiatedUsr]; break;
        case 'reqCreatedDtTm': [propertyA, propertyB] = [a.reqCreatedDtTm, b.reqCreatedDtTm]; break;
        case 'requestStatus': [propertyA, propertyB] = [a.requestStatus, b.requestStatus]; break;
        case 'gfrRequestId': [propertyA, propertyB] = [a.gfrRequestId, b.gfrRequestId]; break;
               
      }

      const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
      const valueB = isNaN(+propertyB) ? propertyB : +propertyB;

      return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'asc' ? 1 : -1);
    });
  }
}
