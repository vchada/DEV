import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GFRSchedulerComponent } from './gfrscheduler.component';

describe('GFRSchedulerComponent', () => {
  let component: GFRSchedulerComponent;
  let fixture: ComponentFixture<GFRSchedulerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GFRSchedulerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GFRSchedulerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
