import { Component, OnInit } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { MatDialog } from "@angular/material";
import { GfrUserService } from "../services/gfr-user.service";
import { SubmitFeedbackResultDialogComponent } from "./submit-feedback-result-dialog/submit-feedback-result-dialog.component";

@Component({
  selector: 'app-submit-feedback',
  templateUrl: './submit-feedback.component.html',
  styleUrls: ['./submit-feedback.component.css']
})
export class SubmitFeedbackComponent implements OnInit {

  feedbackType;
  showErrorMsg = false;
  submitted = false;
  submitFeedback = new FormGroup({
    feedback: new FormControl('', Validators.required),
    summary: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email]),
    name: new FormControl('', Validators.required)
  })

  constructor(private gfrUserService: GfrUserService, public dialog: MatDialog) {
  }

  ngOnInit() {
    this.submitFeedback.patchValue({
      email: this.gfrUserService.userData.mail,
      name: this.gfrUserService.userData.name
    })
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(SubmitFeedbackResultDialogComponent, {
      width: '450px',
    });

    dialogRef.afterClosed().subscribe(result => {      
      this.feedbackType = '';
      this.submitFeedback.patchValue({
        email: this.gfrUserService.userData.mail,
        name: this.gfrUserService.userData.name,
        feedback: '',
        summary: ''
      })
      this.submitted = false;
    });
  }

  submit() {
    this.submitted = true;
    if(!this.feedbackType) {
      this.showErrorMsg = true;
    } else {
      if(this.submitFeedback.valid) {
        let reqdata = {
          userId: this.gfrUserService.userData.userName,
          userName: this.submitFeedback.value.name,
          defectType: this.feedbackType,
          description: this.submitFeedback.value.summary + ' : ' + this.submitFeedback.value.feedback,
          userEmail: this.submitFeedback.value.email,
          status: 'open'
        }
        this.gfrUserService.createFeedback(reqdata).subscribe((value) => {
          this.openDialog();
        })
      }
    }
    
  }

  selctedTypeOfFeedback(type) {
    this.feedbackType = type;
    this.showErrorMsg = false;
  }
}