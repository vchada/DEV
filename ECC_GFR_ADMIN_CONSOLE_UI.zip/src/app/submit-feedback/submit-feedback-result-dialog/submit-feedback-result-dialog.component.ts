import { Component, OnInit } from "@angular/core";
import { MatDialogRef } from "@angular/material";

@Component({
  selector: 'app-submit-feedback-result-dialog',
  templateUrl: './submit-feedback-result-dialog.component.html',
  styleUrls: ['./submit-feedback-result-dialog.component.css']
})
export class SubmitFeedbackResultDialogComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<SubmitFeedbackResultDialogComponent>) {
  }

  ngOnInit() {
    
  }
  
  close() {
    this.dialogRef.close();
  }
}