import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubmitFeedbackResultDialogComponent } from './submit-feedback-result-dialog.component';

describe('SubmitFeedbackResultDialogComponent', () => {
  let component: SubmitFeedbackResultDialogComponent;
  let fixture: ComponentFixture<SubmitFeedbackResultDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubmitFeedbackResultDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubmitFeedbackResultDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
