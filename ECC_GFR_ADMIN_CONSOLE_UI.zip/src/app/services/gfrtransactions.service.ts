import { Injectable } from '@angular/core';
import { GFRTransactions } from '../models/GFRTransactions';
import { BehaviorSubject } from 'rxjs';
import { HttpHeaders, HttpClient, HttpErrorResponse } from '@angular/common/http';
import { AuthService } from './auth.service';
import { User } from '../models/User';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GFRTransactionsService {

  private readonly API_URL = environment.baseUrl + '/aspect/';

  dataChange: BehaviorSubject<GFRTransactions[]> = new BehaviorSubject<GFRTransactions[]>([]);
  // Temporarily stores data from dialogs
  dialogData: any;


  httpOptions = {
    headers: new HttpHeaders({
      'Cache-Control': 'no-cache, no-store, must-revalidate, post-check=0, pre-check=0',
      'Pragma': 'no-cache',
      'Expires': '0'
    })
  };
  constructor (private httpClient: HttpClient,private authService:AuthService) {
  }

  get data(): GFRTransactions[] {
    return this.dataChange.value;
  }

  getDialogData() {
    return this.dialogData;
  }

  /** CRUD METHODS */
  getAllGFRTransaction(): void {
    this.httpClient.get<GFRTransactions[]>(this.API_URL + 'getAllTransactions',this.httpOptions).subscribe(data => {
        this.dataChange.next(data);
        console.log(data);
      },
      (error: HttpErrorResponse) => {
      console.log (error.name + ' ' + error.message);
      });
  }

}
