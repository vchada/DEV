import { TestBed } from '@angular/core/testing';

import { GfrOfficeHoursDataService } from './gfr-office-hours-data.service';

describe('GfrOfficeHoursDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GfrOfficeHoursDataService = TestBed.get(GfrOfficeHoursDataService);
    expect(service).toBeTruthy();
  });
});
