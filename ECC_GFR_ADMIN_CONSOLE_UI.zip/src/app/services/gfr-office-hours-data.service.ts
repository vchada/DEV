import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { GfrOfficeHours } from '../models/GfrOfficeHours';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { AuthService } from './auth.service';
import { User } from '../models/User';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GfrOfficeHoursDataService {
  private readonly API_URL = environment.baseUrl + '/GFR';
  private GFR_URL: string;
  dataChange: BehaviorSubject<GfrOfficeHours[]> = new BehaviorSubject<GfrOfficeHours[]>([]);
  // Temporarily stores data from dialogs
  dialogData: any;
  private userName: string;
  role: string;
  gfrName: string;
  user: User;
  httpOptions = {
    headers: new HttpHeaders({
      'Cache-Control': 'no-cache, no-store, must-revalidate, post-check=0, pre-check=0',
      'Pragma': 'no-cache',
      'Expires': '0'
    })
  };
  constructor(private httpClient: HttpClient,
    private authService: AuthService) {
  }

  get data(): GfrOfficeHours[] {
    return this.dataChange.value;
  }

  getDialogData() {

    return this.dialogData;

  }

  /** CRUD METHODS */
  getGFROfficeHoursDetails(): void {
    this.authService.user.subscribe(user => {
      this.role = user.admin;
      this.userName = user.userName;
    });
    if (this.role) {
      this.GFR_URL = this.API_URL + '/getAllGFROfficeHoursByUserID/' + this.userName.toLowerCase().trim();
    } else {
      this.GFR_URL = this.API_URL + '/getAllGFROfficeHoursByUserID/' + this.userName.toLowerCase().trim();
    }

    this.httpClient.get<GfrOfficeHours[]>(this.GFR_URL,this.httpOptions).subscribe(data => {
      this.dataChange.next(data);
      console.log(data);
    },
      (error: HttpErrorResponse) => {
        console.log(error.name + ' ' + error.message);
      });
  }

  // DEMO ONLY, you can find working methods below
  // ADD, POST METHOD
  addItem(gfrofficeHours: GfrOfficeHours): void {
    this.authService.user.subscribe(user=> {
      this.user =user;
      gfrofficeHours.createdUser=this.user.userName;
    });
    this.httpClient.post(this.API_URL + '/createGfrOfficeHours', gfrofficeHours).subscribe(data => {
      this.dialogData = gfrofficeHours;
      // this.toasterService.showToaster('Successfully added', 3000);
    },
      (err: HttpErrorResponse) => {
        /* this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);*/
      });
  }

  // UPDATE, PUT METHOD
  updateItem(gfrOfficceHours: GfrOfficeHours): void {
    console.log("Update Data::",gfrOfficceHours)
    this.httpClient.put(this.API_URL + '/updateGfrOfficeHours', gfrOfficceHours).subscribe(data => {
      this.dialogData = gfrOfficceHours;
      // this.toasterService.showToaster('Successfully edited', 3000);
    },

      (err: HttpErrorResponse) => {
        // this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      }
    );
  }
}
