import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ScheduleHoursComponent } from '../schedule-hours/schedule-hours.component';
import { ScheduleHours } from '../models/ScheduleHours';
import { HttpHeaders, HttpClient, HttpErrorResponse } from '@angular/common/http';
import { User } from '../models/User';
import { AuthService } from './auth.service';
import { GFRInfo } from '../models/GFRInfo';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GFRSchedulerService {

  private readonly API_URL = environment.baseUrl + '/GFR';
  
  private GFR_URL: string;
  dataChange: BehaviorSubject<ScheduleHours[]> = new BehaviorSubject<ScheduleHours[]>([]);
   gfrInfo: BehaviorSubject<GFRInfo[]> = new BehaviorSubject<GFRInfo[]>([]);

  // Temporarily stores data from dialogs
  dialogData: any;
  private userName: string;
  role: string;
  gfrName: string;
  user: User;
  httpOptions = {
    headers: new HttpHeaders({
      'Cache-Control': 'no-cache, no-store, must-revalidate, post-check=0, pre-check=0',
      'Pragma': 'no-cache',
      'Expires': '0'
    })
  };
  constructor(private httpClient: HttpClient,
    private authService: AuthService) {
  }

  get gfr() {
    return this.gfrInfo.asObservable();
  }
  get data(): ScheduleHours[] {
    return this.dataChange.value;
  }

  getDialogData() {

    return this.dialogData;

  }

  /** CRUD METHODS */
  getGFRInfo(): void {
    this.authService.user.subscribe(user => {
      this.role = user.admin;
      this.userName = user.userName;
    });

      this.GFR_URL = this.API_URL + '/getGFRInfoByUserID/' + this.userName.toLowerCase().trim();


    this.httpClient.get<GFRInfo[]>(this.GFR_URL,this.httpOptions).subscribe(data => {
      this.gfrInfo.next(data);
      console.log(data);
    },
      (error: HttpErrorResponse) => {
        console.log(error.name + ' ' + error.message);
      });
  }
  getGFRSchedules(): void {
    this.authService.user.subscribe(user => {
      this.role = user.admin;
      this.userName = user.userName;
    });
    if (this.role) {
      this.GFR_URL = this.API_URL + '/GetAllOfficeHourSchedules'
    } else {
      this.GFR_URL = this.API_URL + '/getAllGFROfficeHoursSchedulesByUserID/' + this.userName;
    }

    this.httpClient.get<ScheduleHours[]>(this.GFR_URL,this.httpOptions).subscribe(data => {
      this.dataChange.next(data);
      console.log(data);
    },
      (error: HttpErrorResponse) => {
        console.log(error.name + ' ' + error.message);
      });
  }

  // DEMO ONLY, you can find working methods below
  // ADD, POST METHOD
  addItem(scheduleHours: ScheduleHours): void {
    this.authService.user.subscribe(user=> {
      this.user =user;
      scheduleHours.reqInitiatedUsr=this.user.userName;
    });
    this.httpClient.post(this.API_URL + '/createGfrOfficeHoursSchedule', scheduleHours).subscribe(data => {
      this.dialogData = data;
      // this.toasterService.showToaster('Successfully added', 3000);
    },
      (err: HttpErrorResponse) => {
        /* this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);*/
      });
  }

  // UPDATE, PUT METHOD
  updateItem(scheduleHours: ScheduleHours): void {
    console.log("Update Data::",scheduleHours)
    this.httpClient.put(this.API_URL + '/updateGfrOfficeHoursSchedules', scheduleHours).subscribe(data => {
      this.dialogData = data;
      // this.toasterService.showToaster('Successfully edited', 3000);
    },

      (err: HttpErrorResponse) => {
        // this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      }
    );
  }
  delete(requestId:string): void {
    console.log("Delete Data::",requestId)
    this.httpClient.delete(this.API_URL + '/deleteGfrOfficeHoursSchedules/'+requestId,this.httpOptions).subscribe(data => {
      this.dialogData = data;
      // this.toasterService.showToaster('Successfully edited', 3000);
    },

      (err: HttpErrorResponse) => {
        // this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      }
    );
  }
}
