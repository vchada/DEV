import { TestBed } from '@angular/core/testing';

import { GfrPhoneMappingService } from './gfr-phone-mapping.service';

describe('GfrPhoneMappingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GfrPhoneMappingService = TestBed.get(GfrPhoneMappingService);
    expect(service).toBeTruthy();
  });
});
