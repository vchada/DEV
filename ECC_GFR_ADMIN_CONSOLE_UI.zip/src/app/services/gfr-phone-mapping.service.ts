import { Injectable } from '@angular/core';
import { GFRPhoneMapping } from '../models/GFRPhoneMapping';
import { HttpErrorResponse, HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { AuthService } from './auth.service';
import { User } from '../models/User';
import { environment } from '../../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class GfrPhoneMappingService {

  private readonly API_URL =  environment.baseUrl + '/GFR';

  dataChange: BehaviorSubject<GFRPhoneMapping[]> = new BehaviorSubject<GFRPhoneMapping[]>([]);
  // Temporarily stores data from dialogs
  dialogData: any;
  gfrName: any;
  role: any;
  user: User;
  httpOptions = {
    headers: new HttpHeaders({
      'Cache-Control': 'no-cache, no-store, must-revalidate, post-check=0, pre-check=0',
      'Pragma': 'no-cache',
      'Expires': '0'
    })
  };
  constructor (private httpClient: HttpClient,private authService:AuthService) {
  }

  get data(): GFRPhoneMapping[] {
    return this.dataChange.value;
  }

  getDialogData() {

    return this.dialogData;

  }

  /** CRUD METHODS */
  getGFRPhoneMappingDetails(): void {
    this.httpClient.get<GFRPhoneMapping[]>(this.API_URL + '/GetAllPhoneMappings',this.httpOptions).subscribe(data => {
        this.dataChange.next(data);
        console.log("GFRphonemapping::",data);

      },
      (error: HttpErrorResponse) => {
      console.log (error.name + ' ' + error.message);
      });
  }

  // DEMO ONLY, you can find working methods below
  // ADD, POST METHOD
  addItem(phoneMap: GFRPhoneMapping): void {
    this.authService.user.subscribe(user=> {
      this.user =user;
      phoneMap.createdUser=this.user.userName;
    });
    this.httpClient.post(this.API_URL + '/createGfrPhoneMapping', phoneMap).subscribe(data => {
        this.dialogData = phoneMap;
        // this.toasterService.showToaster('Successfully added', 3000);
      },
      (err: HttpErrorResponse) => {
        // this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      });
  }

  // UPDATE, PUT METHOD
  updateItem(gfrphoneMap: GFRPhoneMapping): void {
    this.httpClient.put(this.API_URL + '/updateGfrPhoneMapping', gfrphoneMap).subscribe(data => {
        this.dialogData = gfrphoneMap;
        // this.toasterService.showToaster('Successfully edited', 3000);
      },

      (err: HttpErrorResponse) => {
        // this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      }
    );
  }

}
