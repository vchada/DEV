import { TestBed } from '@angular/core/testing';

import { GfrUserService } from './gfr-user.service';

describe('GfrUserService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GfrUserService = TestBed.get(GfrUserService);
    expect(service).toBeTruthy();
  });
});
