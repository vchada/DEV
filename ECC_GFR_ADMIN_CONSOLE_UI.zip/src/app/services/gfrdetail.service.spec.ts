import { TestBed } from '@angular/core/testing';

import { GfrdetailService } from './gfrdetail.service';

describe('GfrdetailService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GfrdetailService = TestBed.get(GfrdetailService);
    expect(service).toBeTruthy();
  });
});
