import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { User } from '../models/User';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Link } from '../header/header.component';
import { NgxSpinnerService } from 'ngx-spinner';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private loggedIn = new BehaviorSubject<boolean>(false); // {1}
  userAdmin: BehaviorSubject<User> = new BehaviorSubject<User>(new User());
  userData: User;
  private authUrl: string = environment.baseUrl + '/aspect/authenticateUser';
  private verifyUserUrl: string = environment.baseUrl + '/GFR/isAdmin/';
  error: any;

  adminLinks: Link[] = [
    { value: 'apptagrouting', viewValue: 'GFR AppTag Routing' },
    { value: 'gfrcellhours', viewValue: 'GFR CellPhone Office Hours' },
    { value: 'gfrdetail', viewValue: 'GFR Detail' },
    { value: 'gfrofficehours', viewValue: 'GFR Office Hours' },
    { value: 'gfrphonemapping', viewValue: 'GFR Phone Mapping' },
    { value: 'gfrtransactions', viewValue: 'GFR Transactions' },
    { value: 'scheduleHours', viewValue: 'GFR Office Hours Scheduler' }
  ];
  private adminTable: BehaviorSubject<Link[]> = new BehaviorSubject<Link[]>(this.adminLinks);
  gfrLinks: Link[] = [
    { value: 'gfrcellhours', viewValue: 'GFR CellPhone Office Hours' },
    { value: 'gfrofficehours', viewValue: 'GFR Office Hours' },
    { value: 'scheduleHours', viewValue: 'GFR Office Hours Scheduler' },
  ];
  private gfrTable: BehaviorSubject<Link[]> = new BehaviorSubject<Link[]>(this.gfrLinks);

  get gfr() {
    return this.gfrTable.asObservable();
  }
  get admin() {
    return this.adminTable.asObservable();
  }
  get isLoggedIn() {
    return this.loggedIn.asObservable(); // {2}
  }
  get user(): any {
    return this.userAdmin.asObservable();
  }

  constructor(
    private router: Router,
    private http: HttpClient,
    private spinner: NgxSpinnerService
  ) { }

  /*  getUserDetails(usr: User) {
     this.http.get<User>(this.ApiUrl + "//authenticateUser/" + usr.userName + "/" + usr.password)
       .pipe(catchError(this.handleError<User>('getUser')))
       .subscribe(user => {
         this.user = user;
         console.log(this.user);
         if (user) {
           if (user.password == null && user.gfrName == usr.gfrName) {
             this.loggedIn.next(true);
             this.userInfo.next(user);
             console.log("in login")
             this.router.navigate(['gfrcellhours']);
           }
         } else {
           alert("Incorrect username or password.");
         }

       })

   } */
  login(user: User) {
    // console.log("Entered :: ", user.userName)
    this.spinner.show();
    // console.log("passs :: ", user.password)
    // this.authUrl = 'https://localhost:5656/aspect/authenticateUser';
    return this.http.post<User>(this.authUrl, user, { headers: {'contentType': 'application/json'}})
      .pipe(catchError(this.handleError<any>('get Authencation')))
      .subscribe(user => {
        this.userData = user;
        /* if(this.userData.userName === null){
            this.router.navigate(['serviceError'])
        } else */ if (this.userData && this.userData.isvalid === true) {
         //this.userData.admin = true;
          // this.userData.gfrID = '999';
          this.loggedIn.next(true);
          console.log("User logged successfully", this.userData)
          //this.userData.admin = false;
          this.userAdmin.next(this.userData);
          this.router.navigate(['gfrcellhours'])
        } else {
          alert('Invalid Username or Password')
        }
        this.spinner.hide();
      })
  }
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead
      this.error = error;
      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  verifyUser(userId) {
    return this.http.get<User>(this.verifyUserUrl + userId)
      .pipe(catchError(this.handleError<any>('Verify User')))
  }

  logout() {                            // {4}
    this.loggedIn.next(false);
    this.router.navigate(['login']);
  }
}
