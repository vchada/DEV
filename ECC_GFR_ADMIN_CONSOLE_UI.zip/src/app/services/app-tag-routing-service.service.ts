import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpEventType, HttpEvent } from '@angular/common/http';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { AppTagRouting } from '../models/AppTagRouting';
import { AuthService } from './auth.service';
import { User } from '../models/User';
import { environment } from '../../environments/environment';
import { map, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AppTagRoutingServiceService {
  private readonly API_URL = environment.baseUrl + '/GFR';

  dataChange: BehaviorSubject<AppTagRouting[]> = new BehaviorSubject<AppTagRouting[]>([]);
  // Temporarily stores data from dialogs
  dialogData: any;
  role: any;
  gfrName: string;
  user: User;
  responseBody:string;
  httpOptions = {
    headers: new HttpHeaders({
      'Cache-Control': 'no-cache, no-store, must-revalidate, post-check=0, pre-check=0',
      'Pragma': 'no-cache',
      'Expires': '0'
    })
  };
  constructor(private httpClient: HttpClient, private authService: AuthService) {
  }


  get data(): AppTagRouting[] {
    return this.dataChange.value;
  }

  getDialogData() {
    return this.dialogData;
  }

  /** CRUD METHODS */
  getAllAppTagRoutings(): void {
    this.httpClient.get<AppTagRouting[]>(this.API_URL + '/GetAllAppTagRoutings', this.httpOptions).subscribe(data => {
      this.dataChange.next(data);
      console.log(data);
    },
      (error: HttpErrorResponse) => {
        console.log(error.name + ' ' + error.message);
      });
  }
/*   upload(fd:FormData) {
    return this.httpClient.post<any>(this.API_URL+'/uploadFile', fd, {
      reportProgress: true,
      observe: 'events'
    }).pipe(
      map(event => this.getEventMessage(event, fd)),
      catchError(this.handleError)
    );
  }
  private getEventMessage(event: HttpEvent<any>, formData) {

    switch (event.type) {
      case HttpEventType.UploadProgress:
        return this.fileUploadProgress(event);
		break;
      case HttpEventType.Response:
        return this.apiResponse(event);
		break;
      default:
        return `File "${formData.get('profile').name}" surprising upload event: ${event.type}.`;
    }
  }
  private fileUploadProgress(event) {
    const percentDone = Math.round(100 * event.loaded / event.total);
    return { status: 'progress', message: percentDone };
  }

  private apiResponse(event) {
    return event;
  }
  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError('Something bad happened. Please try again later.');
  } */

  uploadFile(fd: FormData) {
    this.authService.user.subscribe(user =>{
      this.user = user;
      fd.append('username',this.user.userName);
      //console.log(this.user.userName)
    })
    //fd.append('username','sairam')
    //console.log("FD",fd)
    return this.httpClient.post(this.API_URL + '/uploadFile', fd, {
      reportProgress: true,
      observe: 'events'
    })

  }
  // DEMO ONLY, you can find working methods below
  // ADD, POST METHOD
  addItem(appTagRouting: AppTagRouting): void {
    this.authService.user.subscribe(user => {
      this.user = user;
      appTagRouting.createdUser = this.user.userName;
    });
    this.httpClient.post(this.API_URL + '/createGfrAppTagRouting', appTagRouting).subscribe(data => {
      this.dialogData = appTagRouting;
      /*this.toasterService.showToaster('Successfully added', 3000);*/
      /*  },
        (err: HttpErrorResponse) => {
          // this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);*/
    });
  }

  // UPDATE, PUT METHOD
  updateItem(appTagRouting: AppTagRouting): void {
    this.httpClient.put(this.API_URL + '/updateGfrAppTagRouting', appTagRouting).subscribe(data => {
      this.dialogData = appTagRouting;
      // this.toasterService.showToaster('Successfully edited', 3000);
    },

      (err: HttpErrorResponse) => {
        // this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      }
    );
  }
  /*
    deleteItem(gfrDetail: GFRDetail): void {
      this.httpClient.delete(this.API_URL + '/deleteContact' + gfrDetail).subscribe(data => {
          this.dialogData = gfrDetail;
          // this.toasterService.showToaster('Successfully deleted', 3000);
        },
        (err: HttpErrorResponse) => {
          // this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
        }
      );
    } */
}
