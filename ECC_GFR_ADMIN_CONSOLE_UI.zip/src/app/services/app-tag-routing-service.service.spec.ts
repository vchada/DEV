import { TestBed } from '@angular/core/testing';

import { AppTagRoutingServiceService } from './app-tag-routing-service.service';

describe('AppTagRoutingServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AppTagRoutingServiceService = TestBed.get(AppTagRoutingServiceService);
    expect(service).toBeTruthy();
  });
});
