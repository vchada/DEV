import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { GFRCellPhoneOfficeHours } from '../models/GFRCellPhoneOfficeHours';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { AuthService } from './auth.service';
import { User } from '../models/User';
import { environment } from '../../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class GfrCellPhoneOfficeHoursService {

 private readonly API_URL = environment.baseUrl + '/GFR';
  private GFR_URL: string;
  httpOptions = {
    headers: new HttpHeaders({
      'Cache-Control': 'no-cache, no-store, must-revalidate, post-check=0, pre-check=0',
      'Pragma': 'no-cache',
      'Expires': '0'
    })
  };

  dataChange: BehaviorSubject<GFRCellPhoneOfficeHours[]> = new BehaviorSubject<GFRCellPhoneOfficeHours[]>([]);
  // Temporarily stores data from dialogs
  dialogData: any;

  user: User;


  constructor(private httpClient: HttpClient, private authService: AuthService) {
  }

  get data(): GFRCellPhoneOfficeHours[] {
    return this.dataChange.value;
  }
  private userName: string;
  private role: string;
  getDialogData() {

    return this.dialogData;

  }

  /** CRUD METHODS */
  getGFRCellPhoneHoursDetails(): void {
    this.authService.user.subscribe(user => {
      this.role = user.admin;
      console.log('log role', this.role)
      this.userName = user.userName;
    });
    if (this.role) {
      this.GFR_URL = this.API_URL + '/getAllGFRCellPhoneOfficeHoursByUserID/' + this.userName.toLowerCase().trim();
    } else {
      this.GFR_URL = this.API_URL + '/getAllGFRCellPhoneOfficeHoursByUserID/' + this.userName.toLowerCase().trim();
    }

    this.httpClient.get<GFRCellPhoneOfficeHours[]>(this.GFR_URL, this.httpOptions).subscribe(data => {
      this.dataChange.next(data);
      console.log(data);

    },
      (error: HttpErrorResponse) => {
        console.log(error.name + ' ' + error.message);
      });
  }


  // DEMO ONLY, you can find working methods below
  // ADD, POST METHOD
  addItem(gfrcoh: GFRCellPhoneOfficeHours): void {
    this.authService.user.subscribe(user => {
      this.user = user;
      gfrcoh.createdUser = this.user.userName;
    });

    this.httpClient.post(this.API_URL + '/createGfrCellPhoneOfficeHours', gfrcoh).subscribe(data => {
      this.dialogData = gfrcoh;
      //this.toasterService.showToaster('Successfully added', 3000);
    },
      (err: HttpErrorResponse) => {
        // this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      });
  }

  // UPDATE, PUT METHOD
  updateItem(gfrCellPhoneHours: GFRCellPhoneOfficeHours): void {
    this.httpClient.put(this.API_URL + '/updateGfrCellPhoneOfficeHours', gfrCellPhoneHours).subscribe(data => {
      this.dialogData = gfrCellPhoneHours;
      console.log("updatable data:", data);
      // this.toasterService.showToaster('Successfully edited', 3000);
    },

      (err: HttpErrorResponse) => {
        // this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      }
    );
  }
}
