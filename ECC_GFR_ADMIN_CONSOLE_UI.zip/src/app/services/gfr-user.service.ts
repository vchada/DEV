import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { GFRCellPhoneOfficeHours } from '../models/GFRCellPhoneOfficeHours';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { AuthService } from './auth.service';
import { User } from '../models/User';
import { environment } from '../../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class GfrUserService {


private readonly API_URL = environment.baseUrl;
  private GFR_URL: string;
  httpOptions = {
    headers: new HttpHeaders({
      'Cache-Control': 'no-cache, no-store, must-revalidate, post-check=0, pre-check=0',
      'Pragma': 'no-cache',
      'Expires': '0'
    })
  };

  dataChange: BehaviorSubject<GFRCellPhoneOfficeHours[]> = new BehaviorSubject<GFRCellPhoneOfficeHours[]>([]);
  // Temporarily stores data from dialogs
  dialogData: any;

  user: User;
  userData;

  constructor(private httpClient: HttpClient, private authService: AuthService) {
    this.authService.user.subscribe(user =>{
      this.userData = user;
    });
  }

  get data(): GFRCellPhoneOfficeHours[] {
    return this.dataChange.value;
  }
  private userName: string;
  private role: string;
  getDialogData() {

    return this.dialogData;

  }

  /** CRUD METHODS */
  getGFRUsers(): void {
    this.authService.user.subscribe(user => {
      this.role = user.admin;
      console.log('log role', this.role)
      this.userName = user.userName;
    });
    if (this.role) {
      this.GFR_URL = environment.baseUrl + '/GFR/GetAllGFRUsers';
    } else {
      this.GFR_URL = environment.baseUrl + '/GFR/GetAllGFRUsers';
    }

    this.httpClient.get<GFRCellPhoneOfficeHours[]>(this.GFR_URL, this.httpOptions).subscribe(data => {
      this.dataChange.next(data);
      console.log(data);

    },
      (error: HttpErrorResponse) => {
        console.log(error.name + ' ' + error.message);
      });
  }


  // ADD, POST METHOD
  createGfrUser(req) {
    return this.httpClient.post(this.API_URL + '/GFR/createGfrUser', req)
  }

  // ADD, POST METHOD
  validateGfrUserId(req) {
    return this.httpClient.get(this.API_URL + '/GFR/GetUserDetails/' + req);
  }

  // UPDATE, PUT METHOD
  editGfrUser(req) {
    return this.httpClient.put(this.API_URL + '/GFR/updateGfrUser', req);
  }

  // UPDATE, PUT METHOD
  deleteGfrUser(req) {
    this.httpOptions['body'] = req;
    return this.httpClient.delete(this.API_URL + '/GFR/deleteGfrUser', this.httpOptions);
  }

   // ADD, POST METHOD
   createFeedback(req) {
    return this.httpClient.post(this.API_URL + '/GFR/postFeedback', req);
  }
}
