
export class GfrOfficeHours {
    gfrid:string;
    mondayOpen: string;
    mondayClose : string;
    tuesdayOpen : string;
    tuesdayClose: string;
    wednesdayOpen : string;
    wednesdayClose :string;
    thursdayOpen : string;
    thursdayClose : string;
    fridayOpen : string;
    fridayClose : string;
    saturdayOpen: string;
    saturdayClose : string;
    sundayOpen : string;
    sundayClose : string;

    gfrName:string;
    gfrLocation:string;
    comments:string;
    
    createdUser: string;
    lastModifiedUser: string;
    lastModifiedDtTm: string;
    createdDtTm: string;
}
