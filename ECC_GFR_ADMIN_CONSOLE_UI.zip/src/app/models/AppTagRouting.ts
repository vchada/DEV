export class AppTagRouting {
    appTag: string;
    gfrTag: string;
    disamPrompt: string;
    createdUser: string;
    createdDtTm: string;
    lastModifiedUser: string;
    lastModifiedDtTm: string;
}