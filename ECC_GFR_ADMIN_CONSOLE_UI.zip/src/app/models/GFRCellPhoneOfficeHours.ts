export class GFRCellPhoneOfficeHours {
    gfrid: string;
    mondayOpen: string;
    mondayClose: string;
    tuesdayOpen: string;
    tuesdayClose: string;
    wednesdayOpen: string;
    wednesdayClose: string;
    thursdayOpen: string;
    thursdayClose: string;
    fridayOpen: string;
    fridayClose: string;
    saturdayOpen: string;
    saturdayClose: string;
    sundayOpen: string;
    sundayClose: string;
    
    gfrName:string;
    gfrLocation:string;
    comments:string;
    
    createdUser: string;
    createdDtTm: string;
    lastModifiedUser: string;
    lastModifiedDtTm: string;
}