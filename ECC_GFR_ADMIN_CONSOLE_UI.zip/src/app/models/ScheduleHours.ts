export class ScheduleHours {
    gfr:string;
    gfrName:string;
    gfrLocation:string;
    tableName: string;    
    effectiveDate: Date;
    expiryDate: string;
    openHoursNew:string;
    closeHoursNew:string;
    closeHoursOld:string;
    openHoursOld:string;
    comments:String;
    fullDay:string;
    currentValue: string;
    reqInitiatedUsr: string;
    reqCreatedDtTm: string;
    requestStatus: string;
    gfrRequestId: string;
    closedFullday: string;
}
