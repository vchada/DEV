
export class User {
  userName:string;
  mail:string;
  name:string;
  cn:string;
  isvalid:boolean;
  password:string;
  admin:boolean;
  gfrID:string;
}