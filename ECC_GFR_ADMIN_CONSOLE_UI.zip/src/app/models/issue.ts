export class Issue {
  companyName: string;
  letter: string;
  companyInfo: string;
  phoneNumber: string;
  policyNumberFormat: string;
  email: string;
}
