
export class GFRInfo {

   // gfrID:string;
    gfrName:string;
    gfrLocation:string;
  gfr:string;

}