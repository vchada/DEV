export class GFRUser {
    gfrId: string;
    gfrName: string;
    createdUser: string;
    createdDtTm: string;
    lastModifiedUser: string;
    lastModifiedDtTm: string;
    userId: string;
    isAdmin: string;
    userName: string;
}