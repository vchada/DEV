export class GFRTransactions {
    gfrid: string;
    userName: string;
    tableName: string;
    columnName: string;
    modifiedDate: string;
    previousValue: string;
    currentValue: string;
    gfrAdminTransactionsID: string;
}