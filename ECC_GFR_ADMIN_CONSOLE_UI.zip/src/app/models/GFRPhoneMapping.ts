
export class GFRPhoneMapping {
    masterId: string;
    gfrid: string;
    phoneNumber: string;
    
    createdUser: string;
    lastModifiedUser: string;
    createdDtTm: string;
    lastModifiedDtTm: string;
    gfrDrNum: string;
}
