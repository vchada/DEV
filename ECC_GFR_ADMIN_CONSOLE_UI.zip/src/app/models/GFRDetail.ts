export class GFRDetail {
     gfrid:string;
     gfrName:string;
     gfrLocation:string;
     gfrWelcomePrompt:string;
     gfrOfficeHoursPrompt:string;
     gfrOfficeCloseFlag:string;
     dealershipAvailable:string;
     spanishOption:string;
     gfrState:string;
     gfrAddressPrompt:string;
     gfrOfficeHoursFlag:string;
     timeZone:string;
     dstExists:string;
     gfrHuntSales:string;
     gfrHuntService:string;
     gfrSiteCode:string; 

     gfrHuntSpanish: string;
     gfrCellNum: string;
     gfrHuntDealership: string;
     gfrCommercialFlag: string;
     createdUser: string;
     createdDtTm: string;
     lastModifiedUser: string;
     lastModifiedDtTm: string;
     gfrHolidayList:string;
     noMatchANIxferToSales:string;
    
     gfrHuntSpanishService:string;


}
