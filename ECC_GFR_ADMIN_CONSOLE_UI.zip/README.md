# GFR Admin Console UI 
Designed using Angular Material , intended to be used by Business Analysts and GFR Offices to edit delete schedules for GFR Offices.
Connects to GFR Dataservices that performs CRUD operations on SQL Server


#Building Application for DEV Environment

ng build -c = dev

#Building Application for PRE-PROD Environment

ng build -c = load

#Building Application for PROD Environment

ng build -c =production