import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react-swc'
import { createHtmlPlugin } from "vite-plugin-html";
import pluginPurgeCss from "vite-plugin-purgecss-updated-v5";

import config from './application.config.json' assert { type: 'json' };

// https://vitejs.dev/config/
export default defineConfig({
  base: config["routePath"][0] === "/" ? config["routePath"] : `/${config["routePath"]}`,
  build: {
    outDir: `dist${config["routePath"][0] === "/" ? config["routePath"] : `/${config["routePath"]}`}`,
    emptyOutDir: true,
    minify: "terser",
    terserOptions: {
      parse: {
        ecma: 5,
      },
      compress: {
        ecma: 5,
        comparisons: false,
        inline: 2,
        dead_code: true,
      },
      mangle: {
        safari10: true,
      },
      output: {
        ecma: 5,
        comments: "all",
        ascii_only: true,
      },
    }
  },
  server: {
    open: true,
    port: 3000,
    hmr: true,
    watch: {
      usePolling: true
    }
  },
  plugins: [
    react(),
    createHtmlPlugin({
      entry: "/src/main.tsx",
      template: "index.html",
      inject: {
        data: {
          title: config["title"],
          description: config["description"],
          routePath: config["routePath"],
        },
        tags: [
          {
            injectTo: 'body-prepend',
            tag: 'div',
            attrs: {
              id: 'tag',
            },
          },
        ],
      },
      minify: {
        removeComments: true,
        collapseWhitespace: true,
        removeRedundantAttributes: true,
        useShortDoctype: true,
        removeEmptyAttributes: true,
        removeStyleLinkTypeAttributes: true,
        keepClosingSlash: true,
        minifyJS: true,
        minifyCSS: true,
        minifyURLs: true,
      },
    }),
    pluginPurgeCss()
  ],
})
