import React, { useEffect, useRef, useState } from 'react';
import { Button } from '@mui/material';
import { MRT_ToggleGlobalFilterButton, type MRT_TableInstance, MRT_GlobalFilterTextField } from 'material-react-table';
import GearMenu from '../Filter/GearMenu';
import FilterMenu from '../Filter/FilterMenu';
import FilterMenuTag from '../Filter/FilterMenuTag';
import { MdRefresh } from 'react-icons/md';

interface HOOToolbarProps {
	table: MRT_TableInstance<any>;
	context: any;
	importEnabled: boolean;
	setLoadingData: any;
	handleEdit: any;
}

export interface FilterTagProps {
	columnId: string;
	columnName: string;
	filterValue: string;
}

const Toolbar: React.FC<HOOToolbarProps> = ({ table, context, importEnabled, setLoadingData, handleEdit }) => {
	const {
		dataDialog,
		selectedHOORows,
		selectedSubType,
		modifiedRows
	} = context;
	const { setDialogViewEditHOO, setDialogDeleteHOO, setDialogAddClosedPeriodHOO } = dataDialog;

	const [isSeeMore, setIsSeeMore] = useState<boolean>(false);
	const [isOverflowing, setIsOverflowing] = useState<boolean>(false);
	const tagsContainerRef = useRef<HTMLDivElement>(null);

	const listOfFilterMenuTags: FilterTagProps[] = table.getLeafHeaders().filter((header) => header.column.getFilterValue() !== undefined)
		.map((header): FilterTagProps => {
			const { column } = header;
			return { columnId: header.id, columnName: column.columnDef.header, filterValue: column.getFilterValue() as string };
		})
		.flatMap((filterTag) => {
			const { columnId, columnName, filterValue } = filterTag
			return filterValue ? (Array.isArray(filterValue) ? filterValue.map((value) => ({ columnId, columnName, filterValue: value })) : filterTag) : []
		});

	// console.log('listOfFilterMenuTags', listOfFilterMenuTags);

	useEffect(() => {
		const checkOverflow = () => {
			setIsOverflowing(listOfFilterMenuTags.length > 3);
		};

		checkOverflow();
	}, [listOfFilterMenuTags]);

	const handleRemoveFilterTag = (filterTag: FilterTagProps) => {
		table.getLeafHeaders().map((header) => {
			if (header.id === filterTag.columnId) {
				const filterValues = header.column.getFilterValue() as string;

				if (Array.isArray(filterValues)) {
					filterValues.map((value, index) => {
						if (value === filterTag.filterValue) {
							filterValues.splice(index, 1);
							header.column.setFilterValue(filterValues);
						}
					});
				} else {
					header.column.setFilterValue(undefined);
				}
			}
		});
	}

	const handleClearAllButton = () => {
		table.getLeafHeaders().map((header) => {
			header.column.setFilterValue(undefined);
		});
	};

	const openViewEditHOODialog = () => {
		setDialogViewEditHOO(true);
	};

	const openAddHOOClosedPeriodDialog = () => {
		setDialogAddClosedPeriodHOO(true);
	};

	const openDeleteHOODialog = () => {
		setDialogDeleteHOO(true);
	};

	return (
		<div className='flex w-full p-4'>
			<div className='flex flex-row flex-grow items-center'>
				{/** ----------------------- Create Filter Tags here ----------------------- */}
				<div ref={tagsContainerRef} className={`flex flex-row flex-wrap items-center content-center overflow-hidden`} >
					<div className='flex flex-row flex-wrap items-center py-1' id='filterTags'>
						<FilterMenu table={table} />
						{
							(isOverflowing && !isSeeMore) ? listOfFilterMenuTags.slice(0, 3).map((filterTag) => {
								const { filterValue } = filterTag;
								return filterValue && <FilterMenuTag filterTag={filterTag} handleRemoveFilterTag={handleRemoveFilterTag} />;
							}) :
								listOfFilterMenuTags.map((filterTag) => {
									const { filterValue } = filterTag;
									return filterValue && <FilterMenuTag filterTag={filterTag} handleRemoveFilterTag={handleRemoveFilterTag} />;
								})
						}
						{isOverflowing && (
							<button className='text-sm text-nowrap text-custom-secondary-blue font-roboto px-1' onClick={() => setIsSeeMore(!isSeeMore)}>
								{isSeeMore ? 'SEE LESS' : 'SEE MORE'}
							</button>
						)}
						{
							(listOfFilterMenuTags.length > 0) && <div className={'flex flex-row'}>
								<button className="text-sm text-nowrap text-custom-secondary-blue font-roboto pr-1 px-1" type='button' onClick={handleClearAllButton}>
									CLEAR ALL
								</button>
							</div>}
					</div>
					{/* </div> */}
				</div>
			</div>
			<div className='flex flex-row flex-none justify-items-end self-start'>
				<div className='flex flex-row px-1'>
					<Button onClick={() => setLoadingData(true)}> <MdRefresh size={25}/> </Button>
				</div>
				<div className='flex flex-row px-1'>
					<MRT_GlobalFilterTextField table={table} />
				</div>
				<div className='flex flex-row px-1'>
					<MRT_ToggleGlobalFilterButton table={table} />
				</div>
				<div className=''>
					<div className=''>
						<div hidden={selectedSubType == 'All'} className='flex-wrap px-1 content-center justify-end'>
							<div className='flex justify-end'>
								<div className='justify-end px-1'>
									<Button disabled={selectedHOORows.length == 0} variant="outlined" color="primary" size="small" style={{ 'height': '33px' }} onClick={() => {
										openViewEditHOODialog();
									}}>{`EDIT (${selectedHOORows.length}) ENTRIES`}</Button>
								</div>
								<div className='justify-end px-1'>
									<Button disabled={selectedHOORows.length == 0} variant="outlined" color="error" size="small" style={{ 'height': '33px' }} onClick={() => {
										openDeleteHOODialog();
									}}>{`DELETE (${selectedHOORows.length}) ENTRIES`}</Button>
								</div>
								<div className='justify-end px-1'>
									<Button disabled={selectedHOORows.length != 0} style={{ 'height': '33px' }} variant="contained" color="primary" size="medium" onClick={() => {
										openAddHOOClosedPeriodDialog();
									}}>ADD NEW CLOSED PERIOD</Button>
								</div>
							</div>
						</div>
						<div hidden={modifiedRows.length == 0} className='flex-wrap px-1 content-center justify-end'>
							<div className='flex justify-end'>
								<div className='justify-end px-1'>
									<Button style={{ 'height': '33px' }} variant="contained" color="primary" size="medium" onClick={() => {
										handleEdit(modifiedRows);
									}}>{`SAVE (${modifiedRows.length}) CHANGES`}</Button>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div className='flex flex-row flex-wrap content-around'>
					<div>
						<GearMenu table={table} context={context} importEnabled={importEnabled} />
					</div>
				</div>
			</div>
		</div>
	);
}

export default Toolbar;
