

import React from "react";
import { Tooltip } from "@mui/material";
import ImportIcon from "../Icons/ImportIcon";
import GearMenuIcon from "../Icons/GearMenuIcons";

interface ImportButtonProps {
	title?: string;
	setGearAnchorEl : any;
	setOpen : any;
}

const ImportButton: React.FC<ImportButtonProps> = ({ title, setGearAnchorEl, setOpen }) => {
	// const [open, setOpen] = React.useState(false);

	const handleShowImportModal = () => {
		setGearAnchorEl(null)
		setOpen(true);
	}

	return (
		<>
			<button className="flex flex-grow px-4 py-2" type='button' onClick={handleShowImportModal} >
				<div className="flex justify-start content-center p-2">
					<Tooltip title={title}>
						<span className="flex flex-row">
							<GearMenuIcon>
								<ImportIcon />
							</GearMenuIcon>
							<p className="text-base content-center pr-10">{title}</p>
						</span>
					</Tooltip>
					{/* {open && <div></div>} */}
				</div>
			</button>
		</>
	);
}

export default ImportButton;
