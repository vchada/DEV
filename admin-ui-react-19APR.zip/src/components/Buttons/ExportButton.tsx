import React from "react";
import { Tooltip } from "@mui/material";
import ExportIcon from "../Icons/ExportIcon";
import GearMenuIcon from "../Icons/GearMenuIcons";

interface ExportButtonProps {
	title?: string;
	setGearAnchorEl: any;
	setOpen: any;
}

const ExportButton: React.FC<ExportButtonProps> = ({ title, setGearAnchorEl, setOpen }) => {
	// const [open, setOpen] = React.useState<boolean>(false);

	const handleShowExportModal = () => {
		setGearAnchorEl(null)
		setOpen(true);
	}

	return (
		<>
			<button className="flex flex-grow px-4 py-2" type='button' onClick={handleShowExportModal} >
				<div className="flex justify-start content-between p-2">
					<Tooltip title={title}>
						<span className="flex flex-row">
							<GearMenuIcon>
								<ExportIcon />
							</GearMenuIcon>
							<p className="text-base content-center pr-10">{title}</p>
						</span>
					</Tooltip>
					{/* {open && <div></div>} */}
				</div>
			</button>
		</>
	);
}

export default ExportButton;
