import { Button, Stack, Tooltip } from '@mui/material';
import { CSVLink } from 'react-csv';
import ExcelImg from '../../assets/imgs/excel.png'
import PDFImg from '../../assets/imgs/pdf.png'
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { MRT_TableInstance } from 'material-react-table';

interface ExportTableProps {
    columns: any;
    headers: string[];
	data: any[];
	filename: string;
    context: any;
    table: MRT_TableInstance<any>;
}

export const ExportTableDialog = ({columns, headers, data, filename, context} : ExportTableProps) => {
    // const handleAction = () => {
    //     handleAction()
    //     return;
    // };

    const handleExportRows = () => {
        const doc = new jsPDF();
        const tableHeaders = columns.map((c: any) => c.header);

        autoTable(doc, {
            head: [tableHeaders],
            body: data,
        });

        doc.save(filename + '.pdf');
    };

    return (
<>
        {data.length > 0 && <div className='flex flex-col gap-4 p-8 '>
            <header className='w-[100%] h-12 flex justify-start gap-3 align-center'>
                <h2 className='font-bold'>Export Table</h2>
            </header>
            <p>
                Select a file format for this export.
            </p>

            <div className=''>
                <div className='w-[100%] h-[122px] flex justify-center space-x-14'>
                    <Tooltip title={'Export to PDF'}>
                        <Button
                            
                            //export all rows as seen on the screen (respects pagination, sorting, filtering, etc.)
                            onClick={() => handleExportRows()}
                        >
                            <div>
                            <img className='mb-[5px]' src={PDFImg} alt="Excel" width={'40px'} height={'40px'} />
                            <p className='text-[14px] font-[650]'>PDF</p>
                            </div>
                            
                        </Button>
                    </Tooltip>
                    <Tooltip title={'Export to Excel'}>
                        <Button>
                            <div>
                            <CSVLink headers={headers} data={data}
                                filename={filename + '.csv'}
                            ><img src={ExcelImg} alt="Excel" width={'85px'} height={'60px'} /></CSVLink>
                            <p className='text-[14px] font-[650] normal-case'>Excel (.csv)</p>
                            </div>
                            
                        </Button>
                    </Tooltip>
                </div>
                <div></div>
            </div>

            <footer className='flex justify-center w-[100%] align-center gap-3 pt-4'>
                <Stack spacing={1} direction={'row'} justifyContent={'flex-end'}>
                    <Button onClick={() => { context.dataDialog.setExportDialog(false) }}>
                    <p className='text-[14px] font-[650] normal-case'>CLOSE</p>
                    </Button>

                </Stack>
            </footer>
        </div>}

        {/*if no data is present, show a message */}
        {data.length == 0 && <div className='flex flex-col gap-4 p-[32px]'>
            <header className='w-[100%] h-12 flex justify-start gap-3 align-center'>
                <h2 className='font-bold'>Export Table</h2>
            </header>
            <p>
                Select a file format for this export.
            </p>

            <div className=''>
                <div className='w-[100%] h-[122px] flex justify-center space-x-14'>
                    <Tooltip title={'Export to PDF'}>
                        <Button
                            
                            //export all rows as seen on the screen (respects pagination, sorting, filtering, etc.)
                            onClick={() => handleExportRows()}
                        >
                            <div>
                            <img className='mb-[5px]' src={PDFImg} alt="Excel" width={'40px'} height={'40px'} />
                            <p className='text-[14px] font-[650]'>PDF</p>
                            </div>
                            
                        </Button>
                    </Tooltip>
                    <Tooltip title={'Export to Excel'}>
                        <Button>
                            <div>
                            <CSVLink headers={headers} data={data}
                                filename={filename + '.csv'}
                            ><img src={ExcelImg} alt="Excel" width={'85px'} height={'60px'} /></CSVLink>
                            <p className='text-[14px] font-[650] normal-case'>Excel (.csv)</p>
                            </div>
                            
                        </Button>
                    </Tooltip>
                </div>
                <div></div>
            </div>

            <footer className='flex justify-center w-[100%] align-center gap-3 pt-4'>
                <Stack spacing={1} direction={'row'} justifyContent={'flex-end'}>
                    <Button onClick={() => { context.dataDialog.setExportDialog(false) }}>
                    <p className='text-[14px] font-[650] normal-case'>CLOSE</p>
                    </Button>

                </Stack>
            </footer>
        </div>}
        </>
    );
};
