import React from "react";

interface ToggleDensityIconProps {
	size?: number;
	color?: string;
}

const ToggleDensityIcon: React.FC<ToggleDensityIconProps> = ({ size = 24, color = 'black' }) => {
	return (
		<svg width={size} height={size} viewBox="0 0 24 24" fill={color} xmlns="http://www.w3.org/2000/svg">
			<path d="M21 8H3V4H21V8ZM21 10H3V14H21V10ZM21 16H3V20H21V16Z" fill={color} fillOpacity="0.56" />
		</svg>
	);
}

export default ToggleDensityIcon;
