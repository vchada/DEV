import React from 'react';

interface CloseIconProps {
  size?: number;
  color?: string;
}

const CloseIcon: React.FC<CloseIconProps> = ({ size = 24, color = 'black' }) => {
  return (
    <svg width={size} height={size} viewBox="2 0 26 26" fill={color} xmlns="http://www.w3.org/2000/svg">
      <path d="M0.736328 0H24.7363C26.9455 0 28.7363 1.79086 28.7363 4V22C28.7363 24.2091 26.9455 26 24.7363 26H0.736328V0Z" fill="#EDEDED" />
      <path d="M19.9863 8.8075L18.9288 7.75L14.7363 11.9425L10.5438 7.75L9.48633 8.8075L13.6788 13L9.48633 17.1925L10.5438 18.25L14.7363 14.0575L18.9288 18.25L19.9863 17.1925L15.7938 13L19.9863 8.8075Z" fill="#616161" />
    </svg>
  );
};

export default CloseIcon;
