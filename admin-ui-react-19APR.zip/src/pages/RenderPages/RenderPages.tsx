import { Navigation } from '../../components/Navigation/Navigation';
import { ContainerRenderPages } from './styled';
import Table from './Table';

export const RenderPages = () => {

  return (
    <ContainerRenderPages suppressHydrationWarning={true}>
      <Navigation/>
      <Table />
    </ContainerRenderPages>
  );
};
