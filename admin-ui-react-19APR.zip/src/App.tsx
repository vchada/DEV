import 'react-toastify/dist/ReactToastify.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { injectStyle } from "react-toastify/dist/inject-style";

import Home from "./routes/home"
import Feedback from "./routes/feedback";
import Gfrcellhours from "./routes/gfrcellhours"
import Gfrdetails from "./routes/gfrdetails";
import Login from "./routes/login"


function App() {

  injectStyle();


  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/feedback" element={<Feedback />} />
          <Route path="/gfrcellhours" element={<Gfrcellhours />} />
          <Route path="/gfrdetails" element={<Gfrdetails />} />
          <Route path="/login" element={<Login />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;

