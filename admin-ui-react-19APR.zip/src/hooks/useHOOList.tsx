import { useMutation } from 'react-query';
import { addHoursOfOperation } from '../services/addHoursOfOperation';

import { updateHoursOfOperation } from '../services/updateHoursOfOperation';



interface dataUpdateProps {
  loginId: string;
  name: string;
  payload: any;
}



export const useHOOLists = () => {

  const { mutate: mutateUpdateHOO } = useMutation({
    mutationFn: async (dataUpdateSchedule: dataUpdateProps) => {
      return await updateHoursOfOperation(dataUpdateSchedule);
    },
  });

  const { mutate: mutateAddHOO } = useMutation({
    mutationFn: async (dataUpdateSchedule: dataUpdateProps) => {
      return await addHoursOfOperation(dataUpdateSchedule);
    },
  });





  return {
    mutateUpdateHOO,
    mutateAddHOO
  };
};
