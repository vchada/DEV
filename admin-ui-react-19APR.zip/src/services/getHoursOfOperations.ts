import { hoursOfOperationAPI } from './api';

export async function getHoursOfOperation(determinator: string) {
  try {
    const { data } = await hoursOfOperationAPI.get('/api/v1/custom-hours-of-operations/' + determinator);
    return data;
  } catch (err: any) {
    console.log('Error: ', err)
    return new Error(err?.response?.data?.message);
  }
}

export async function getAllHoursOfOperation() {
  console.log(`${'https://1ke97zdw5b.execute-api.us-east-1.amazonaws.com'}`);

  try {
    const { data } = await hoursOfOperationAPI.get(`${'https://1ke97zdw5b.execute-api.us-east-1.amazonaws.com'}/api/v1/custom-hours-of-operations/All`);
    return data;
  } catch (err: any) {
    console.log('Error: ', err)
    return new Error(err?.response?.data?.message);
  }
}

export async function getFederalHoursOfOperation() {
  try {
    const { data } = await hoursOfOperationAPI.get(`${'https://1ke97zdw5b.execute-api.us-east-1.amazonaws.com'}/api/v1/custom-hours-of-operations/Federal`);
    return data;
  } catch (err: any) {
    console.log('Error: ', err)
    return new Error(err?.response?.data?.message);
  }
}

export async function getStateHoursOfOperation() {
  try {
    const { data } = await hoursOfOperationAPI.get(`${'https://1ke97zdw5b.execute-api.us-east-1.amazonaws.com'}/api/v1/custom-hours-of-operations/State`);
    return data;
  } catch (err: any) {
    console.log('Error: ', err)
    return new Error(err?.response?.data?.message);
  }
}

export async function getAdhocHoursOfOperation() {
  try {
    const { data } = await hoursOfOperationAPI.get(`${'https://1ke97zdw5b.execute-api.us-east-1.amazonaws.com'}/api/v1/custom-hours-of-operations/Adhoc`);
    return data;
  } catch (err: any) {
    console.log('Error: ', err)
    return new Error(err?.response?.data?.message);
  }
}
