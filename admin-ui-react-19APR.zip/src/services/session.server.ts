type User = { userId: string; userName: string };


export async function createUserSession({
  userId, userName
}: {
  userId: string;
  userName?: string;
}) {
  sessionStorage.setItem(userId, JSON.stringify({userId, userName}))
  localStorage.setItem('userId', userId)
}


const getUserSession = (userId: string) => {
  return sessionStorage.getItem(userId);
};


export function getUserId() {
  const userIdAtt: string | null = localStorage.getItem('userId')
  if(userIdAtt) {
    return getUserSession(userIdAtt);
  } else {
    return undefined;
  }
}


