/** @type {import("./Types/xlsx")} */
declare global
{
  interface Window
  {
    VITE_BASE_URL: string;
    VITE_BASE_URL_STATE_PRIORITY: string;
    VITE_BASE_URL_HOURS_OF_OPERATION: string;
    VITE_BASE_URL_FEEDBACK: string;
    VITE_BASE_URL_LOGIN: string;
    VITE_ENV: string;
    VITE_CCP_REGION: string;
    VITE_CCP_URL: string;
    VITE_CCP_LOGIN_URL: string;
    XLSX: xlsx;
  }
}

export {};
