window.VITE_BASE_URL='https://o5sg2sozq2.execute-api.us-east-1.amazonaws.com/sbx';
window.VITE_BASE_URL_STATE_PRIORITY = 'https://b3rrj59gi7.execute-api.us-east-1.amazonaws.com/sbx';
window.VITE_BASE_URL_HOURS_OF_OPERATION = 'https://1ke97zdw5b.execute-api.us-east-1.amazonaws.com/sbx';
window.VITE_ENV='IN1';
window.VITE_CCP_REGION='us-east-1';
window.VITE_CCP_URL= 'https://gwe1-telecom-dv1-conn-001.my.connect.aws/ccp-v2';
window.VITE_CCP_LOGIN_URL= 'https://launcher.myapps.microsoft.com/api/signin/7071b979-492a-4b9b-ad79-858d91c41084?tenantId=7389d8c0-3607-465c-a69f-7d4426502912';
window.VITE_CCP_LOGOUT_URL= 'https://login.microsoftonline.com/7389d8c0-3607-465c-a69f-7d4426502912/oauth2/v2.0/logout?post_logout_redirect_uri=https://gwe1-telecom-dv1-conn-001.my.connect.aws/ccp-v2';
window.VITE_CCP_CLIENT_ID= '03ec2238-c3d3-4a36-8a6b-d4a1468f89b3';


window.VITE_BASE_URL_FETCH_GFR_DETAIL = 'https://jsonplaceholder.typicode.com/posts'
window.VITE_BASE_URL_ADD_GFR_DETAIL = 'https://jsonplaceholder.typicode.com/posts'
window.VITE_BASE_URL_UPDATE_GFR_DETAIL = 'https://jsonplaceholder.typicode.com/posts'
window.VITE_BASE_URL_FETCH_GFR_PHONE_MAPPING = 'https://jsonplaceholder.typicode.com/posts'
window.VITE_BASE_URL_ADD_GFR_PHONE_MAPPING = 'https://jsonplaceholder.typicode.com/posts'
window.VITE_BASE_URL_UPDATE_GFR_PHONE_MAPPING = 'https://jsonplaceholder.typicode.com/posts'
window.VITE_BASE_URL_FETCH_GFR_OFFICE_HOURS = 'https://jsonplaceholder.typicode.com/posts'
window.VITE_BASE_URL_ADD_GFR_OFFICE_HOURS = 'https://jsonplaceholder.typicode.com/posts'
window.VITE_BASE_URL_UPDATE_GFR_OFFICE_HOURS = 'https://jsonplaceholder.typicode.com/posts'
window.VITE_BASE_URL_FETCH_GFR_OFFICE_HOUR_SCHEDULER = 'https://jsonplaceholder.typicode.com/posts'
window.VITE_BASE_URL_ADD_GFR_OFFICE_HOUR_SCHEDULER = 'https://jsonplaceholder.typicode.com/posts'
window.VITE_BASE_URL_UPDATE_GFR_OFFICE_HOUR_SCHEDULER = 'https://jsonplaceholder.typicode.com/posts'

window.VITE_BASE_URL_FETCH_GFR_APP_TAG_ROUTING = 'https://jsonplaceholder.typicode.com/posts'
window.VITE_BASE_URL_ADD_GFR_APP_TAG_ROUTING = 'https://jsonplaceholder.typicode.com/posts'
window.VITE_BASE_URL_UPDATE_GFR_APP_TAG_ROUTING = 'https://jsonplaceholder.typicode.com/posts'

window.VITE_BASE_URL_FETCH_GFR_USERS = 'https://jsonplaceholder.typicode.com/posts'
window.VITE_BASE_URL_ADD_GFR_USERS = 'https://jsonplaceholder.typicode.com/posts'
window.VITE_BASE_URL_UPDATE_GFR_USERS = 'https://jsonplaceholder.typicode.com/posts'
