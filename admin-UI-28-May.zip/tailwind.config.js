/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{html,js,ts,tsx,jsx}"
  ],
  theme: {
    fontFamily: {
      'roboto': ['Roboto', 'sans-serif'],
    },
    extend: {
      colors: {
        'custom-primary-blue': '#005CCC',
        'custom-secondary-blue': '#2196F3'
      },
    },
  },
  plugins: [],
}

