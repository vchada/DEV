export type GfrAppTagRouting = {
  gea_id: string;
  disam_prompt: string;
  app_tag: string;
  gea_tag: string;
  last_modified_user: string;
  last_modified_dt_tm: string;
  created_user: string;
  created_dt_tm: string;
};

export const gfrAppTagRoutingDummydata: GfrAppTagRouting[] = [
  {
    disam_prompt: 'N',
    app_tag: 'AutoRenewPolicy',
    gea_tag: 'Service',
    last_modified_dt_tm: '',
    created_user: '',
    last_modified_user: '',
    gea_id: '5704',
    created_dt_tm: '',
  },
  {
    disam_prompt: 'N',
    app_tag: 'ServiceATV',
    gea_tag: 'Service',
    last_modified_dt_tm: '',
    created_user: '',
    last_modified_user: '',
    gea_id: '5705',
    created_dt_tm: '',
  },
];
