import { LoadingContainer } from './styled';
import CircularProgress from '@mui/material/CircularProgress';

export const LoadingComponent = () => {
  return (
    <LoadingContainer>
      <CircularProgress />
    </LoadingContainer>
  );
};
