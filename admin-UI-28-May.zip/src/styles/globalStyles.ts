// globalStyles.js
import { createGlobalStyle } from 'styled-components';

export const GlobalStyle = createGlobalStyle`
:root {
  --white: #FFFFFF;
  --black: #141414;
  --blue-100: #dcdced;
  --blue-200: #b8bbdb;
  --blue-300: #959ac9;
  --blue-400: #717bb7;
  --blue-450: #005CCC;
  --blue-500: #005290;
  --blue-600: #0F4293;
  --blue-700: #141a31;
  --gray-50: #F0F4FB;
  --gray-100: #e0e0e0;
  --gray-200: #6c6c6c;
  --gray-300: #525252;
  --gray-400: #444444;
  --gray-500: rgb(34, 34, 34);;
  --green-500: #46da44;
  --red: #b6091a;  
}
`;
