import { getUserInfo } from "../services/session.server";
import { useNavigate } from "react-router";
import type * as Route from "./+types.home";
import { useEffect } from "react";


export default function Index({}: Route.ComponentProps) {
  const navigate = useNavigate();
  useEffect(() => {
      const userId = getUserInfo();
      if (userId) {
        navigate("/gfrDetails")
      } else {
        navigate("/login")
      }
    });
}
