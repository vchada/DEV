import { getUserInfo } from "../services/session.server";
import { redirect } from "react-router";
import { RenderPages } from "../pages/RenderPages/RenderPages"
import type { Route } from "./+types/home";

export async function loader({ request }: Route.LoaderArgs) {
  // Check if the user is already logged in
  const userId = await getUserInfo();
  if (!userId) {
    throw redirect("/login");
  } else {
    return { userId };
  }
}

export default function Index({ }: Route.ComponentProps) {
  return (
    <div>
      <RenderPages tablename='gfrDetails'/>
    </div>
  );
}
