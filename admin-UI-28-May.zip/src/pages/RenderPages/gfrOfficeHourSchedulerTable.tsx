import { useMemo, useState } from 'react';
import {
  MRT_EditActionButtons,
  MaterialReactTable,
  type MRT_ColumnDef,
  type MRT_TableOptions,
  useMaterialReactTable,
} from 'material-react-table';
import {
  Box,
  Button,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  QueryClient,
  QueryClientProvider,
  useMutation,
  useQuery,
  useQueryClient,
} from '@tanstack/react-query';
import {
  type GfrOfficeHourScheduler,
  gfrOfficeHourSchedulerDummydata,
} from '../../assets/dummy-data/gfrOfficeHourSchedulerTableDummyData';
import EditIcon from '@mui/icons-material/Edit';
import { addGfrOfficeHourScheduler, fetchGfrOfficeHourScheduler, updateGfrOfficeHourScheduler } from '../../services/api';
import { getUserInfo } from '../../services/session.server';

const Example = (name: string) => {
  const [validationErrors, setValidationErrors] = useState<
    Record<string, string | undefined>
  >({});

  const columns = useMemo<MRT_ColumnDef<GfrOfficeHourScheduler>[]>(
    () => [
      {
        accessorKey: 'gea_id',
        header: 'gea_id',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: true,
          error: !!validationErrors?.gea_id,
          helperText: validationErrors?.gea_id,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              gea_id: undefined,
            }),
        },
      },
      {
        accessorKey: 'gea',
        header: 'GEA Name',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: true,
          error: !!validationErrors?.gea,
          helperText: validationErrors?.gea,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              gea: undefined,
            }),
        },
      },
      {
        accessorKey: 'close_hours_new',
        header: 'Close Hour New',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        },
      },
      {
        accessorKey: 'close_hours_old',
        header: 'Close Hour Old',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        },
      },
      {
        accessorKey: 'open_hours_new',
        header: 'Open Hour New',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        },
      },
      {
        accessorKey: 'open_hours_old',
        header: 'Open Hour Old',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        },
      },
      {
        accessorKey: 'gea_request_id',
        header: 'Request ID',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        },
      },
      {
        accessorKey: 'table_name',
        header: 'Table Name',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        },
      },
      {
        accessorKey: 'comments',
        header: 'Comments',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        },
      },
      {
        accessorKey: 'full_day',
        header: 'Full Day',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        },
      },
      {
        accessorKey: 'expiry_date',
        header: 'Expiry Date',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        },
      },
      {
        accessorKey: 'req_initiated_user',
        header: 'Request Initiated User',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        },
      },
      {
        accessorKey: 'request_status',
        header: 'Request Status',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        },
      },
      {
        accessorKey: 'effective_date',
        header: 'Effective Date',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        },
      },
    ],
    [validationErrors],
  );

  //call CREATE hook
  const { mutateAsync: createUser, isPending: isCreatingUser } = useCreateUser();
  //call READ hook
  const {
    data: fetchedUsers = [],
    isError: isLoadingUsersError,
    isFetching: isFetchingUsers,
    isLoading: isLoadingUsers,
  } = useGetUsers();
  //call UPDATE hook
  const { mutateAsync: updateUser, isPending: isUpdatingUser } = useUpdateUser();

  //CREATE action
  const handleCreateUser: MRT_TableOptions<GfrOfficeHourScheduler>['onCreatingRowSave'] = async ({
    values,
    table,
  }) => {
    const newValidationErrors = validateUser(values);
    if (Object.values(newValidationErrors).some((error) => error)) {
      setValidationErrors(newValidationErrors);
      return;
    }
    setValidationErrors({});
    await createUser(values);
    table.setCreatingRow(null); //exit creating mode
  };

  //UPDATE action
  const handleSaveUser: MRT_TableOptions<GfrOfficeHourScheduler>['onEditingRowSave'] = async ({
    values,
    table,
  }) => {
    const newValidationErrors = validateUser(values);
    if (Object.values(newValidationErrors).some((error) => error)) {
      setValidationErrors(newValidationErrors);
      return;
    }
    setValidationErrors({});
    await updateUser(values);
    table.setEditingRow(null); //exit editing mode
  };

  const userInfo = getUserInfo();

  const table = useMaterialReactTable({
    columns,
    data: fetchedUsers,
    createDisplayMode: 'modal', //default ('row', and 'custom' are also available)
    editDisplayMode: 'modal', //default ('row', 'cell', 'table', and 'custom' are also available)
    enableEditing: userInfo.admin ? true : false,
    enableTopToolbar: userInfo.admin ? true : false,
    getRowId: (row) => row.gea_id,
    muiToolbarAlertBannerProps: isLoadingUsersError
      ? {
          color: 'error',
          children: 'Error loading data',
        }
      : undefined,
    muiTableContainerProps: {
      sx: {
        minHeight: '500px',
      },
    },
    onCreatingRowCancel: () => setValidationErrors({}),
    onCreatingRowSave: handleCreateUser,
    onEditingRowCancel: () => setValidationErrors({}),
    onEditingRowSave: handleSaveUser,
    //optionally customize modal content
    renderCreateRowDialogContent: ({ table, row, internalEditComponents }) => (
      <>
        <DialogTitle variant="h5">Create New Office Hour Scheduler</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {internalEditComponents} {/* or render custom edit components here */}
        </DialogContent>
        <DialogActions>
          <MRT_EditActionButtons variant="text" table={table} row={row} />
        </DialogActions>
      </>
    ),
    //optionally customize modal content
    renderEditRowDialogContent: ({ table, row, internalEditComponents }) => (
      <>
        <DialogTitle variant="h5">Edit User</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {internalEditComponents} {/* or render custom edit components here */}
        </DialogContent>
        <DialogActions>
          <MRT_EditActionButtons variant="text" table={table} row={row} />
        </DialogActions>
      </>
    ),
    renderRowActions: ({ row, table }) => (
      <Box sx={{ display: 'flex', gap: '1rem' }}>
        <Tooltip title="Edit">
          <IconButton onClick={() => table.setEditingRow(row)}>
            <EditIcon />
          </IconButton>
        </Tooltip>
      </Box>
    ),
    renderTopToolbarCustomActions: ({ table }) => (
      <Button
        variant="contained"
        onClick={() => {
          table.setCreatingRow(true); //simplest way to open the create row modal with no default values
          //or you can pass in a row object to set default values with the `createRow` helper function
          // table.setCreatingRow(
          //   createRow(table, {
          //     //optionally pass in default values for the new row, useful for nested data or other complex scenarios
          //   }),
          // );
        }}
      >
        Create New Office Hour Scheduler
      </Button>
    ),
    state: {
      isLoading: isLoadingUsers,
      isSaving: isCreatingUser || isUpdatingUser,
      showAlertBanner: isLoadingUsersError,
      showProgressBars: isFetchingUsers,
    },
    positionActionsColumn: 'last',
  });

  return <MaterialReactTable table={table} />;
};

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div style={{ margin: '0 100px' }}>
        <Example />
      </div>
    </QueryClientProvider>
  );
}

const validateRequired = (value: string) => !!value.length;

function validateUser(user: GfrOfficeHourScheduler) {
  return {
    gea: !validateRequired(user.gea) ? 'GEA Name is Required' : '',
    gea_id: !validateRequired(user.gea_id) ? 'ID is Required' : ''
  };
}

//READ hook (get users from api)
function useGetUsers() {
  return useQuery<any[]>({
    queryKey: ['users'],
    queryFn: async () => {
      
      let response: any;
      await fetchGfrOfficeHourScheduler.get('/').then((res: any) => {
        response = res.data;
      });

      // ToDO - Need to comment below one line
      response = gfrOfficeHourSchedulerDummydata;
      const userInfo = await getUserInfo();
      if (userInfo && userInfo.gfrID && userInfo.gfrID !== '0' && response.length > 0) {
        response = response.filter((item: any) => {
          return item.gea_id === userInfo.gfrID;
        });
      }

      return Promise.resolve(response);
    },
    refetchOnWindowFocus: false,
  });
}




//CREATE hook (post new user to api)
function useCreateUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (user: GfrOfficeHourScheduler) => {
      
      // await new Promise((resolve) => setTimeout(resolve, 1000)); //fake api call
      let reqBody: any = {
        "gea_id": user.gea_id,
        "gea": user.gea,
        "close_hours_new": user.close_hours_new,
        "open_hours_old": user.open_hours_old,
        "gea_request_id": user.gea_request_id,
        "close_hours_old": user.close_hours_old,
        "table_name": user.table_name,
        "comments": user.comments,
        "full_day": user.full_day,
        "req_created_dt_tm": user.req_created_dt_tm,
        "expiry_date": user.expiry_date,
        "req_initiated_user": user.req_initiated_user,
        "open_hours_new": user.open_hours_new,
        "request_status": user.request_status,
        "effective_date": user.effective_date,
      }

      let response: any;
      await addGfrOfficeHourScheduler.post('/', reqBody).then((res: any) => {
        response = res.data;
      });

      return Promise.resolve();
    },
    //client side optimistic update
    onMutate: (GfrOfficeHourScheduler: GfrOfficeHourScheduler) => {
      queryClient.setQueryData(
        ['users'],
        (prevUsers: any) =>
          [
            ...prevUsers,
            {
              ...GfrOfficeHourScheduler,
            },
          ] as GfrOfficeHourScheduler[],
      );
    },
    // onSettled: () => queryClient.invalidateQueries({ queryKey: ['users'] }), //refetch users after mutation, disabled for demo
  });
}

//UPDATE hook (put user in api)
function useUpdateUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (user: GfrOfficeHourScheduler) => {

      // await new Promise((resolve) => setTimeout(resolve, 1000)); //fake api call
      let reqBody: any = {
        "gea_id": user.gea_id,
        "gea": user.gea,
        "close_hours_new": user.close_hours_new,
        "open_hours_old": user.open_hours_old,
        "gea_request_id": user.gea_request_id,
        "close_hours_old": user.close_hours_old,
        "table_name": user.table_name,
        "comments": user.comments,
        "full_day": user.full_day,
        "req_created_dt_tm": user.req_created_dt_tm,
        "expiry_date": user.expiry_date,
        "req_initiated_user": user.req_initiated_user,
        "open_hours_new": user.open_hours_new,
        "request_status": user.request_status,
        "effective_date": user.effective_date,
      }
      let response: any;
      await updateGfrOfficeHourScheduler.post('/', reqBody).then((res: any) => {
        response = res.data;
      });
      return Promise.resolve();
    },
    //client side optimistic update
    onMutate: (GfrOfficeHourScheduler: GfrOfficeHourScheduler) => {
      queryClient.setQueryData(['users'], (prevUsers: any) =>
        prevUsers?.map((prevUser: GfrOfficeHourScheduler) =>
          prevUser.gea_id === GfrOfficeHourScheduler.gea_id ? GfrOfficeHourScheduler : prevUser,
        ),
      );
    },
    // onSettled: () => queryClient.invalidateQueries({ queryKey: ['users'] }), //refetch users after mutation, disabled for demo
  });
}
